@interface ABMultiCellAccessibility : __ABMultiCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;
- (BOOL)isAccessibilityElement;
- (BOOL)_accessibilityCanDeleteTableViewCell;
- (BOOL)_accessibilityAlwaysReturnsChild;

@end
