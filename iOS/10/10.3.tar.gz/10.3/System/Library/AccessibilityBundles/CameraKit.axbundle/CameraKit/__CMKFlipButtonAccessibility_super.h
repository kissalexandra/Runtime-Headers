@interface __CMKFlipButtonAccessibility_super : UIAccessibilitySafeCategory

@end
