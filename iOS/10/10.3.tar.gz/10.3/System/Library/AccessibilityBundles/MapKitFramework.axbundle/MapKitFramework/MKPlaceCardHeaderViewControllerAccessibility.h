@interface MKPlaceCardHeaderViewControllerAccessibility : __MKPlaceCardHeaderViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)placeCardHeaderViewDot;
- (void)_updateDirectionsButton;
- (void)_setUpComponents;
- (id)labelForAttributedString:(id)a0;

@end
