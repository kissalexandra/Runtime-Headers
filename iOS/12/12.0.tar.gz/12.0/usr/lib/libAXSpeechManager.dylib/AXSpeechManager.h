@class TTSSpeechSynthesizer, NSArray, NSString, AXSpeechThread, NSNumber, NSMutableArray;

@interface AXSpeechManager : NSObject <TTSSpeechSynthesizerDelegate> {
    NSMutableArray *_speechQueue;
    TTSSpeechSynthesizer *_synthesizer;
    AXSpeechThread *_runThread;
    unsigned int _audioQueueFlags;
    BOOL _isSpeaking;
}

@property (retain, nonatomic) NSNumber *originalSpeechRateForJobOverride;
@property (nonatomic) BOOL isPaused;
@property (nonatomic) BOOL speechEnabled;
@property (readonly, nonatomic) BOOL showControlCenterControls;
@property (readonly, nonatomic) BOOL isSpeaking;
@property (nonatomic) unsigned int audioQueueFlags;
@property (retain, nonatomic) NSArray *outputChannels;
@property (copy, nonatomic) id /* block */ requestWillStart;
@property (nonatomic) BOOL supportsAccurateWordCallbacks;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)availableLanguageCodes;
+ (struct URegularExpression { } *)createRegularExpressionFromString:(id)a0;
+ (id)matchedRangesForString:(id)a0 withRegularExpression:(struct URegularExpression { } *)a1;
+ (id)_resetAvailableVoices;
+ (id)spellOutMarkupString:(id)a0 string:(id)a1;
+ (id)pauseMarkupString:(id)a0;
+ (id)remapLanguageCode:(id)a0;
+ (void)test_actionStartTap:(id /* block */)a0;
+ (void)test_setUnitTestMode:(BOOL)a0;
+ (void)test_setAvailableVoices:(id)a0;
+ (id)currentLanguageCode;
+ (id)availableVoices;

- (BOOL)isSpeaking;
- (void)speechSynthesizer:(id)a0 didStartSpeakingRequest:(id)a1;
- (void)speechSynthesizer:(id)a0 didPauseSpeakingRequest:(id)a1;
- (void)speechSynthesizer:(id)a0 didContinueSpeakingRequest:(id)a1;
- (void)speechSynthesizer:(id)a0 willSpeakRangeOfSpeechString:(struct _NSRange { unsigned long long x0; unsigned long long x1; })a1 forRequest:(id)a2;
- (void)speechSynthesizer:(id)a0 didFinishSpeakingRequest:(id)a1 successfully:(BOOL)a2 withError:(id)a3;
- (void)_updateUserSubstitutions;
- (void)_startNextSpeechJob;
- (id)_phonemeSubstitutionsForAction:(id)a0;
- (void)clearSpeechQueue;
- (void)_clearSpeechQueue;
- (void)_dispatchSpeechAction:(id)a0;
- (void)_pauseSpeaking:(id)a0;
- (void)_continueSpeaking;
- (void)_stopSpeaking:(id)a0;
- (void)_isSpeaking:(id)a0;
- (void)_speechJobFinished:(BOOL)a0 action:(id)a1;
- (void)__speechJobFinished:(id)a0;
- (id)voiceIdentifierUsedForLanguage:(id)a0;
- (void)dispatchSpeechAction:(id)a0;
- (void)continueSpeaking;
- (void)pauseSpeaking:(int)a0;
- (void)stopSpeaking:(int)a0;
- (void)_tearDown;
- (void)tearDown;
- (void)stopSpeaking;
- (void)_initialize;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
