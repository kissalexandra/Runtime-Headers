@interface MPUMediaRemoteViewControllerAccessibility : __MPUMediaRemoteViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)_accessibilityIsPlaying;

@end
