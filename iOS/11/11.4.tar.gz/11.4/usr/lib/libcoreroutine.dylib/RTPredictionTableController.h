@class NSString, RTPersistenceManager, NSObject, RTMetricManager;
@protocol OS_dispatch_queue;

@interface RTPredictionTableController : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) NSString *predictionTableName;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) RTMetricManager *metricManager;

- (id)init;
- (void).cxx_destruct;
- (id)initWithPredictionTableName:(id)a0 persistenceManager:(id)a1 metricManager:(id)a2;
- (id)_fetchPredictionTable:(id)a0 error:(id *)a1;
- (void)createPredictionTable:(id /* block */)a0;
- (void)_createPredictionTableWithContext:(id)a0 handler:(id /* block */)a1;
- (void)deletePredictionTable:(id /* block */)a0;
- (void)_deletePredictionTableWithContext:(id)a0 save:(BOOL)a1 handler:(id /* block */)a2;
- (id)_evaluateAddonsAndFilterPredictionsForObject:(id)a0 predictionTable:(id)a1;
- (id)_createFeatureAddonsFromConditionsMO:(id)a0;
- (id)_combinedFilterPredicateFromAddons:(id)a0;
- (void)addResults:(id)a0 featureAddons:(id)a1;
- (void)_addResults:(id)a0 featureAddons:(id)a1 predictionTable:(id)a2;
- (void)dumpPredictionTable:(id /* block */)a0;
- (void)_dumpPredictionTable:(id)a0;
- (void)fetchPredictionTablePropertyListRepresentationWithHandler:(id /* block */)a0;
- (void)_predictionTableMetricWithHandler:(id /* block */)a0;
- (id)_predictionTableMetricOfPredictionTable:(id)a0;
- (void)predictionTableMetricWithHandler:(id /* block */)a0;
- (void)logRecommendedApps;
- (void)_logRecommendedApps:(id)a0;

@end
