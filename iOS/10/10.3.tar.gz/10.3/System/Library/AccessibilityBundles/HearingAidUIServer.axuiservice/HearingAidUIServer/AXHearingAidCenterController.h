@class AXHearingAidDisplayController, AXDispatchTimer, UIView, AXRemoteHearingAidDevice, UINavigationBar, NSMutableDictionary, _UIBackdropView, UITableView, NSString;

@interface AXHearingAidCenterController : UIViewController <UITableViewDataSource, UITableViewDelegate, AXHearingVolumeCellDelegate> {
    BOOL _bluetoothAvailable;
}

@property (retain, nonatomic) _UIBackdropView *backdropView;
@property (retain, nonatomic) _UIBackdropView *tableViewBackdrop;
@property (retain, nonatomic) NSMutableDictionary *separatorViews;
@property (retain, nonatomic) AXDispatchTimer *volumeUpdateHysteresis;
@property (nonatomic) UINavigationBar *navBar;
@property (nonatomic) AXHearingAidDisplayController *parentController;
@property (retain, nonatomic) UIView *contentView;
@property (retain, nonatomic) AXRemoteHearingAidDevice *device;
@property (retain, nonatomic) UITableView *tableView;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void)dealloc;
- (void)tableView:(id)a0 willDisplayCell:(id)a1 forRowAtIndexPath:(id)a2;
- (void)tableView:(id)a0 willDisplayHeaderView:(id)a1 forSection:(long long)a2;
- (void)tableView:(id)a0 willDisplayFooterView:(id)a1 forSection:(long long)a2;
- (void)tableView:(id)a0 didEndDisplayingCell:(id)a1 forRowAtIndexPath:(id)a2;
- (double)tableView:(id)a0 heightForRowAtIndexPath:(id)a1;
- (double)tableView:(id)a0 heightForHeaderInSection:(long long)a1;
- (double)tableView:(id)a0 heightForFooterInSection:(long long)a1;
- (id)tableView:(id)a0 viewForHeaderInSection:(long long)a1;
- (id)tableView:(id)a0 viewForFooterInSection:(long long)a1;
- (void)tableView:(id)a0 didSelectRowAtIndexPath:(id)a1;
- (long long)tableView:(id)a0 numberOfRowsInSection:(long long)a1;
- (id)tableView:(id)a0 cellForRowAtIndexPath:(id)a1;
- (long long)numberOfSectionsInTableView:(id)a0;
- (id)title;
- (void)viewWillAppear:(BOOL)a0;
- (void)viewDidDisappear:(BOOL)a0;
- (void)viewDidLoad;
- (void)updateView;
- (BOOL)accessibilityPerformEscape;
- (void)_doneAction:(id)a0;
- (void)bluetoothAvailabilityDidChange:(id)a0;
- (void)audioRouteDidChange:(id)a0;
- (void)updateViewForProperties:(id)a0;
- (void)hearingVolumeDidChange:(id)a0;
- (void)updateSlidersInSection:(int)a0;
- (void)updateSeparatorForCell:(id)a0 atIndexPath:(id)a1;
- (void)setClearBackground:(id)a0;
- (id)reuseIdentifierForIndexPath:(id)a0;
- (BOOL)shouldDisplayMasterVolume;
- (id)_programsForSection:(long long)a0;
- (BOOL)shouldOnlyShowIndividualVolumesForProperty:(unsigned long long)a0;
- (BOOL)_numSelectedStreamingPrograms;
- (void)_updateProgramSection:(long long)a0;

@end
