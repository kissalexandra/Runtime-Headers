@interface MFHeaderLabelViewAccessibility : __MFHeaderLabelViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityHint;
- (BOOL)isAccessibilityElement;
- (BOOL)_accessibilityIsScannerElement;

@end
