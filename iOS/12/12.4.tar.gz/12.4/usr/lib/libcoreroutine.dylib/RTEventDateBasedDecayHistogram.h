@class NSNumber, NSString, NSMutableOrderedSet;

@interface RTEventDateBasedDecayHistogram : RTEventWeightedHistogram <RTEventHistogram>

@property (retain, nonatomic) NSMutableOrderedSet *dateSet;
@property (retain, nonatomic) NSNumber *decayRate;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)dateSetForEventArray:(id)a0;
+ (void)resetDateSet:(id)a0 forEventArray:(id)a1;
+ (BOOL)supportsSecureCoding;

- (void)addEvent:(id)a0 weight:(double)a1;
- (double)decayTimeExponent:(id)a0;
- (id)initWithDateSet:(id)a0 decayRate:(id)a1;
- (id)initWithDecayRate:(id)a0;
- (id)initWithEventArray:(id)a0 decayRate:(id)a1;
- (void)resetWithEventArray:(id)a0;
- (id)init;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (void)reset;
- (void)clear;

@end
