@interface ABPersonContainerViewAccessibility : __ABPersonContainerViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)setContentSwitchingTabs:(id)a0;
- (void)_accessibilityLoadAccessibilityInformation;

@end
