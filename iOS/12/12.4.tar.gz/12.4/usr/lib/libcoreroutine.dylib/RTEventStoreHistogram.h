@class RTEventDateBasedDecayHistogram, RTDefaultsManager, RTMediaRemote, RTEntropyFilter, NSMutableSet, NSMutableArray, NSString;

@interface RTEventStoreHistogram : RTEventStore <RTEventStore, NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (retain, nonatomic) RTMediaRemote *mediaRemote;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) NSMutableArray *events;
@property (retain, nonatomic) RTEventDateBasedDecayHistogram *processedEventModel;
@property (retain, nonatomic) RTEntropyFilter *entropyFilter;
@property (nonatomic) double confidence;
@property (nonatomic) double globalLaunchThreshold;
@property (retain, nonatomic) NSMutableSet *bundleIdentifiersSupportingPriming;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)addEvent:(id)a0;
- (void)addEvents:(id)a0;
- (void)setupThreshold;
- (double)calculateModelConfidenceWithBundleId:(id)a0;
- (void)fetchAllPredictionsWithHandler:(id /* block */)a0;
- (void)clearAllEvents;
- (void)removeEvent:(id)a0;
- (void)removeEvents:(id)a0;
- (unsigned long long)countOfEvents;
- (void)_processEventsWithGlobalAppLaunchCountedSet:(id)a0 handler:(id /* block */)a1;
- (double)getConfidence;
- (id)initWithApplicableEventClasses:(id)a0 decayRate:(double)a1 mediaRemote:(id)a2 defaultsManager:(id)a3;
- (void)addAppLaunchEvent:(id)a0;
- (id)init;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (void)invalidate;

@end
