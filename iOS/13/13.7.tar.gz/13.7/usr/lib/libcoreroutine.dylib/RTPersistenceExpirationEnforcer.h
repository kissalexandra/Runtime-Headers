@interface RTPersistenceExpirationEnforcer : NSObject

- (id)init;
- (id)collectRecordIDsByTypeExpiredBeforeDate:(id)a0 ownedByThisDevice:(BOOL)a1 context:(id)a2 error:(id *)a3;
- (BOOL)removeRecordsOwnedByOtherDevicesExpiredBeforeDate:(id)a0 allowPropagation:(BOOL)a1 context:(id)a2 error:(id *)a3;
- (BOOL)removeExpiredRecordsBeforeDate:(id)a0 context:(id)a1 error:(id *)a2;
- (id)entitiesWithDeviceAndExpirationProperty:(id)a0 ownedByThisDevice:(BOOL)a1;
- (BOOL)removeExpiredRecordsWithObjectIDs:(id)a0 context:(id)a1 error:(id *)a2;
- (BOOL)repairInvalidExpirationDatesWithContext:(id)a0 error:(id *)a1;
- (BOOL)removeRecordsOwnedByThisDeviceExpiredBeforeDate:(id)a0 context:(id)a1 error:(id *)a2;

@end
