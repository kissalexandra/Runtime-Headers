@interface RTKeepAliveTransaction : RTTransaction

- (void)dealloc;
- (id)initForObject:(id)a0 description:(id)a1;

@end
