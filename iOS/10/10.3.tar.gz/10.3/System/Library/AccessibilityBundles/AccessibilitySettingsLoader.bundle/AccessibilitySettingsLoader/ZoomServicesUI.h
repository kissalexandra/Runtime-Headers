@interface ZoomServicesUI : NSObject

@property (nonatomic, getter=isRegisteredForAppNotifications) BOOL registeredForAppNotifications;

+ (void)enableZoomServices;
+ (void)disableZoomServices;

- (id)init;
- (void)dealloc;
- (Class)_accessibilityBundlePrincipalClass;
- (void)_handleKeyboardWillShowNotification:(id)a0;
- (void)_handleKeyboardWillHideNotification:(id)a0;
- (void)_handleZoomEnabledStatusDidChangeNotification:(id)a0;
- (void)_updateForCurrentZoomStatus;
- (void)_unregisterForAppNotifications;
- (void)_installZoomUISafeCategoriesIfNeeded;
- (void)_registerForAppNotifications;
- (void)_handleRegisterZoomConflictNotification:(id)a0;
- (void)_handleZoomFocusDidChangeNotification:(id)a0;
- (void)_handleFirstResponderDidChangeNotification:(id)a0;
- (void)_handleAlertWillAppearNotification:(id)a0;
- (void)_handleLockButtonWasPressedNotification:(id)a0;
- (void)_handleAppSwitcherWillBeginRevealNotification:(id)a0;
- (void)_handleAppDidBecomeActiveNotification:(id)a0;
- (void)_handleAppDidEnterBackgroundNotification:(id)a0;
- (struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })_keyboardFrameInScreenCoordinates;

@end
