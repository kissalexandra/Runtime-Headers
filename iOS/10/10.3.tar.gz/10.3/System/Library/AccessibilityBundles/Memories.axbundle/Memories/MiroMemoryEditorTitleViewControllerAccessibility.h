@interface MiroMemoryEditorTitleViewControllerAccessibility : __MiroMemoryEditorTitleViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)tableView:(id)a0 cellForRowAtIndexPath:(id)a1;
- (void)_accessibilityLoadAccessibilityInformation;

@end
