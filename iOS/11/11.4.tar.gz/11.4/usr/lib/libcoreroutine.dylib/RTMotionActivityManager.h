@class RTPlatform;

@interface RTMotionActivityManager : RTNotifier

@property (readonly, nonatomic) RTPlatform *platform;

+ (id)allocWithZone:(struct _NSZone { } *)a0;
+ (BOOL)supportsNotificationName:(id)a0;
+ (id)motionActivityConfidenceToString:(unsigned long long)a0;
+ (id)motionActivityTypeToString:(unsigned long long)a0;
+ (id)motionActivityVehicleConnectedStateToString:(unsigned long long)a0;
+ (id)motionSettledStateToString:(unsigned long long)a0;
+ (void)removeActivities:(id)a0 stoppedBeforeDate:(id)a1;
+ (double)ratioOfMotionActivityType:(unsigned long long)a0 forActivities:(id)a1 startDate:(id)a2 endDate:(id)a3;

- (id)init;
- (void).cxx_destruct;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_shutdown;
- (id)initWithPlatform:(id)a0;
- (void)fetchMotionActivitiesFromStartDate:(id)a0 toEndDate:(id)a1 withHandler:(id /* block */)a2;
- (void)_fetchMotionActivitiesFromStartDate:(id)a0 toEndDate:(id)a1 withHandler:(id /* block */)a2;
- (void)fetchRTMotionActivitiesFromStartDate:(id)a0 toEndDate:(id)a1 withHandler:(id /* block */)a2;
- (void)_fetchRTMotionActivitiesFromStartDate:(id)a0 toEndDate:(id)a1 withHandler:(id /* block */)a2;

@end
