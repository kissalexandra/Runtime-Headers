@class NSString, NSObject;
@protocol OS_dispatch_data, OS_nw_dictionary;

@interface NWConcrete_nw_inbound_message : NSObject <OS_nw_inbound_message> {
    NSObject<OS_dispatch_data> *content;
    NSObject<OS_nw_dictionary> *values;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void).cxx_destruct;
- (void)dealloc;
- (id)initWithContent:(id)a0;

@end
