@class NSDictionary;

@interface AppletConfigurationData : NSObject {
    NSDictionary *internal;
}

+ (BOOL)setConfiguration:(id)a0 error:(id *)a1;
+ (struct os_state_data_s { unsigned int x0; union { unsigned int x0 : 32; unsigned int x1; } x1; struct os_state_data_decoder_s { char x0[64]; char x1[64]; } x2; char x3[64]; unsigned char x4[0]; } *)dumpState;
+ (void)registerStateHandler;
+ (id)extraDebugScriptForModule:(id)a0;
+ (BOOL)isValidConfigData:(id)a0 error:(id *)a1;
+ (id)GetStaticConfigurationData;
+ (id)getInstance;
+ (id)dataHash;
+ (id)scriptForModule:(id)a0;
+ (id)plasticCardScriptForModule:(id)a0;

- (id)init;

@end
