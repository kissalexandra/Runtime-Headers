@class NSMutableDictionary;

@interface RTMicroLocationCache : NSObject

@property (retain, nonatomic) NSMutableDictionary *cache;

- (id)microLocationForResult:(id)a0;
- (id)addMicroLocationForIdentifier:(id)a0;
- (id)init;
- (void).cxx_destruct;
- (void)clear;

@end
