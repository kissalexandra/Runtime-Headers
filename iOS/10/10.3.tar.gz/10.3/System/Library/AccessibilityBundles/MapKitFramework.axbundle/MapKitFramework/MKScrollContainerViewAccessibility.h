@interface MKScrollContainerViewAccessibility : __MKScrollContainerViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (BOOL)_accessibilityAllowsSiblingsWhenOvergrown;

@end
