@interface __CAMIrisButtonAccessibility_super : UIAccessibilitySafeCategory

@end
