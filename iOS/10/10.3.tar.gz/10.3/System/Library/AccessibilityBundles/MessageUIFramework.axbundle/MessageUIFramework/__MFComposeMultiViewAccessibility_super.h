@interface __MFComposeMultiViewAccessibility_super : UIAccessibilitySafeCategory

@end
