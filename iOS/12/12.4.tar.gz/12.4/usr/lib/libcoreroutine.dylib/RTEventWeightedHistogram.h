@class NSString, NSMutableDictionary;

@interface RTEventWeightedHistogram : RTEventHistogramBase <RTEventHistogram>

@property (retain, nonatomic) NSMutableDictionary *weightedEventModel;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (BOOL)supportsSecureCoding;

- (void)addEvent:(id)a0;
- (void)addEventId:(id)a0;
- (id)allEventIds;
- (double)weightForEventId:(id)a0;
- (void)addEvent:(id)a0 weight:(double)a1;
- (void)addEventId:(id)a0 weight:(double)a1;
- (void)scaleWeights:(double)a0;
- (id)init;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (void)clear;

@end
