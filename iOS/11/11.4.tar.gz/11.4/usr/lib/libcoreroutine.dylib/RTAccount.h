@class NSString, NSArray;

@interface RTAccount : NSObject

@property (retain, nonatomic) NSString *dsid;
@property (retain, nonatomic) NSString *firstName;
@property (retain, nonatomic) NSString *lastName;
@property (nonatomic) BOOL primaryEmailVerified;
@property (retain, nonatomic) NSString *appleID;
@property (retain, nonatomic) NSString *altDSID;
@property (retain, nonatomic) NSString *primaryEmail;
@property (retain, nonatomic) NSString *appleIDAlias;
@property (retain, nonatomic) NSArray *appleIDAliases;

+ (id)allocWithZone:(struct _NSZone { } *)a0;

- (id)init;
- (void).cxx_destruct;
- (id)description;
- (id)initWithACAccount:(id)a0;
- (id)appleIDs;

@end
