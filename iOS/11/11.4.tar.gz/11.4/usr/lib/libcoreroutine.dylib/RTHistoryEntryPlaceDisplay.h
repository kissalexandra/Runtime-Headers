@class RTMapItem, NSDate;

@interface RTHistoryEntryPlaceDisplay : NSObject

@property (readonly, nonatomic) NSDate *usageDate;
@property (readonly, nonatomic) RTMapItem *mapItem;

- (id)init;
- (void).cxx_destruct;
- (id)description;
- (id)initWithUsageDate:(id)a0 mapItem:(id)a1;

@end
