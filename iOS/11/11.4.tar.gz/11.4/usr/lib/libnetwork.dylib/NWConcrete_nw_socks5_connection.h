@class NSString, NSObject;
@protocol OS_nw_connection, OS_dispatch_queue;

@interface NWConcrete_nw_socks5_connection : NSObject <OS_nw_socks5_connection> {
    unsigned long long sc_id;
    NWConcrete_nw_socks5_connection *sc_internally_retained_object;
    NSObject<OS_nw_connection> *sc_in_connection;
    NSObject<OS_dispatch_queue> *sc_queue;
    id /* block */ sc_cancel;
    unsigned char sc_state;
    unsigned char sc_out_address_type;
    union { char *byte_pointer; struct in_addr *ipv4_addr; struct in6_addr *ipv6_addr; char *domain; } sc_out_address;
    unsigned short sc_shoes_request_length_hbo;
    unsigned char sc_out_address_domain_length;
    NSObject<OS_nw_connection> *sc_out_connection;
    unsigned char sc_out_connection_failed_or_sent_write_close : 1;
    unsigned char sc_in_connection_failed_or_sent_write_close : 1;
    unsigned char sc_out_disable_proxy : 1;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)initWithConnection:(id)a0 queue:(id)a1 shoes:(BOOL)a2 disableProxy:(BOOL)a3;
- (void).cxx_destruct;
- (void)dealloc;

@end
