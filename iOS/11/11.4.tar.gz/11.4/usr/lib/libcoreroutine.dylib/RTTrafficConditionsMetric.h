@class AWDCoreRoutineTrafficConditions, RTLocationOfInterest;

@interface RTTrafficConditionsMetric : NSObject

@property (readonly, nonatomic) RTLocationOfInterest *locationOfInterest;
@property (readonly, nonatomic) AWDCoreRoutineTrafficConditions *metric;

- (id)init;
- (void).cxx_destruct;
- (id)description;
- (id)initWithPLOIETA:(id)a0;
- (void)updatePrecisionRecallWithVisitedLocation:(id)a0;

@end
