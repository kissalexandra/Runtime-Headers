@interface __ABMultiCellAccessibility_super : UIAccessibilitySafeCategory

@end
