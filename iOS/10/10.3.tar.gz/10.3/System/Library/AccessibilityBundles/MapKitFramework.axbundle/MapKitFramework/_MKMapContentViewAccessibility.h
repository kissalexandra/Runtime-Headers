@interface _MKMapContentViewAccessibility : ___MKMapContentViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)_accessibilityNativeFocusPreferredElementIsValid;
- (BOOL)_accessibilityShouldIgnoreSoundForFailedMoveAttempt;

@end
