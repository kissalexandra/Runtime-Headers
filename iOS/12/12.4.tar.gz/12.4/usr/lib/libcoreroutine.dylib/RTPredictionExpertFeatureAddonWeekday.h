@interface RTPredictionExpertFeatureAddonWeekday : RTPredictionExpertFeatureAddon

@property (readonly, nonatomic) long long targetDays;

- (id)initWithTargetDays:(long long)a0;
- (long long)addonType;
- (id)weekdayStringFromMask:(long long)a0;
- (id)description;

@end
