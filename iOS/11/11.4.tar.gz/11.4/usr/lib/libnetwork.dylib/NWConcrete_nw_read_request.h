@class NSString, NSObject;
@protocol OS_dispatch_source, OS_dispatch_data, OS_nw_array;

@interface NWConcrete_nw_read_request : NSObject <OS_nw_read_request> {
    NWConcrete_nw_read_request *next;
    id /* block */ data_completion;
    id /* block */ data_multiple_completion;
    id /* block */ data_timeout_completion;
    id /* block */ buffer_completion;
    id /* block */ message_completion;
    int variant;
    BOOL complete;
    unsigned long long min;
    unsigned long long max;
    unsigned long long progress;
    long long timeout_nanos;
    id /* block */ timeout_block;
    NSObject<OS_dispatch_source> *timeout_source;
    BOOL timeout_timer_fired;
    char *buffer;
    BOOL buffer_used_for_reading;
    NSObject<OS_dispatch_data> *data;
    NSObject<OS_dispatch_data> *pattern;
    const void *pattern_bytes;
    unsigned long long pattern_length;
    NSObject<OS_nw_array> *read_array;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
