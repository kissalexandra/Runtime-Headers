@class NSString;

@interface AXCameraMetadataDelegate_CAMERA_UI : NSObject <AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureMetadataOutputObjectsDelegate>

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)dealloc;
- (void)_accessibilityHandleMetadataOutput:(id)a0;
- (BOOL)markDetectionInProgress;
- (void)performDetectionsWithSampleBuffer:(struct opaqueCMSampleBuffer { } *)a0;
- (void)_handleFaceOutput:(id)a0;
- (void)markDetectionFinished;
- (void)updateAccessibleFaceElementsWithFaces:(id)a0;
- (void)captureOutput:(id)a0 didOutputSampleBuffer:(struct opaqueCMSampleBuffer { } *)a1 fromConnection:(id)a2;
- (void)captureOutput:(id)a0 didOutputMetadataObjects:(id)a1 fromConnection:(id)a2;

@end
