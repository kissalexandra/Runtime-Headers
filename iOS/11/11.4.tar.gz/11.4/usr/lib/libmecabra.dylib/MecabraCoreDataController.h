@class NSString, NSArray, NSManagedObjectModel, NSURL, NSPersistentStoreCoordinator, NSEntityDescription, NSManagedObjectContext;

@interface MecabraCoreDataController : NSObject {
    NSString *_localURLLastPartOfName;
}

@property (retain, nonatomic) NSURL *localURL;
@property (retain, nonatomic) NSArray *storedElementsForMerge;
@property (readonly, nonatomic) NSEntityDescription *entityDescription;
@property (readonly, nonatomic) NSURL *localStoreURL;
@property (readonly, nonatomic) NSURL *localInfoPlistURL;
@property (retain, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (retain, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (retain, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (retain, nonatomic) NSURL *storeURL;
@property (retain, nonatomic) NSString *type;

+ (void)resetDatabaseWithType:(id)a0 URL:(id)a1;

- (void)logMessage:(id)a0;
- (void)dealloc;
- (void)addEntry:(id)a0;
- (id)searchResultsWithValueDictionary:(id)a0 managedObjectContext:(id)a1 sortDescriptors:(id)a2;
- (id)entityDescriptionForContext:(id)a0;
- (BOOL)dictionaryEntryHasAllRequiredKeys:(id)a0;
- (id)dictionaryValueFromManagedObject:(id)a0;
- (void)logEntry:(id)a0 operationType:(id)a1 extraInformation:(id)a2;
- (void)deleteAllMatchingEntries:(id)a0;
- (void)prepareURLForDatabaseFile:(id)a0;
- (id)removeDuplicatesForEntry:(id)a0 uniquingKeys:(id)a1 sortDescriptors:(id)a2 restrictToNumberOfElements:(unsigned long long)a3 identifierKey:(id)a4;
- (id)searchResultsWithValueDictionary:(id)a0;
- (id)searchResultsWithValueDictionary:(id)a0 sortDescriptors:(id)a1;
- (void)deleteAllElements;
- (void)setValue:(id)a0 forKey:(id)a1 entry:(id)a2;
- (void)setDatabaseProperty:(id)a0 forKey:(id)a1;
- (id)databasePropertyForKey:(id)a0;
- (id)dictionaryValuesFromManagedObjects:(id)a0;
- (void)setValuesForEntry:(id)a0 uniquingKeys:(id)a1;
- (id)initWithType:(id)a0 URL:(id)a1;
- (id)newPersistentStoreWithURL:(id)a0 ubiquityContainerIdentifier:(id)a1 managedObjectModel:(id)a2;
- (void)sendRemoteNotification;
- (BOOL)shouldSyncDatabase;
- (id)locallyPresentUbiquitousFiles;
- (BOOL)stripUbiquitousInformationFromStore:(id)a0;
- (id)entriesFromStrippedStoreURL:(id)a0;
- (id)coreDataUbiquityFolderURLforStore:(id)a0;
- (id)entriesToMerge;
- (void)clearStoredMergeEntries;
- (void)save;
- (BOOL)isLogging;
- (id)databaseName;
- (void)deleteEntry:(id)a0;

@end
