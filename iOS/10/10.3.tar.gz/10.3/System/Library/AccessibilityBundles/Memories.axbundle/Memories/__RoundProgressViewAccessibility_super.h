@interface __RoundProgressViewAccessibility_super : UIAccessibilitySafeCategory

@end
