@class RTInvocationDispatcher, NSMutableDictionary, NSSet, LSApplicationWorkspace, RTMediaRemote, NSString;

@interface RTApplicationManager : RTService <LSApplicationWorkspaceObserverProtocol>

@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (nonatomic) BOOL ready;
@property (retain, nonatomic) LSApplicationWorkspace *applicationWorkspace;
@property (retain, nonatomic) NSMutableDictionary *appProxies;
@property (retain, nonatomic) NSSet *bundlesSupportingPriming;
@property (retain, nonatomic) RTMediaRemote *mediaRemote;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)_unregisterForNotifications;
- (void)_setup;
- (void)applicationsDidInstall:(id)a0;
- (void)applicationsDidUninstall:(id)a0;
- (void)_registerForNotifications;
- (void)_purge;
- (void)_shutdown;
- (id)initWithMediaRemote:(id)a0;
- (BOOL)allowBundleIdentifierForMagicalMoments:(id)a0;
- (BOOL)allowBundleIdentifierForInstalledHeroApp:(id)a0;
- (BOOL)allowBundleIdentifierForUninstalledHeroApp:(id)a0;
- (id)applicationProxyForBundleIdentifier:(id)a0;
- (id)initWithApplicationWorkspace:(id)a0 mediaRemote:(id)a1;
- (void)onPrimingBundleUpdate:(id)a0;
- (id)_createProxyForBundleIdentifier:(id)a0;
- (long long)_capabilitiesForBundleIdentifier:(id)a0;
- (id)_proxyForBundleIdentifier:(id)a0;
- (void)_onPrimingBundleUpdate:(id)a0;
- (void)_applicationsDidInstall:(id)a0;
- (void)_applicationsDidUninstall:(id)a0;
- (void)_removeProxyForBundleIdentifier:(id)a0;
- (id)init;
- (void).cxx_destruct;
- (void)purge;

@end
