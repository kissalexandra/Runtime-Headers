@interface __MKUIViewAccessibility_super : UIAccessibilitySafeCategory

@end
