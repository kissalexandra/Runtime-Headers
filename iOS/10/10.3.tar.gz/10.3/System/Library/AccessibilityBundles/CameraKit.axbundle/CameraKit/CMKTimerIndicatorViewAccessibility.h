@interface CMKTimerIndicatorViewAccessibility : __CMKTimerIndicatorViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)decrement;

@end
