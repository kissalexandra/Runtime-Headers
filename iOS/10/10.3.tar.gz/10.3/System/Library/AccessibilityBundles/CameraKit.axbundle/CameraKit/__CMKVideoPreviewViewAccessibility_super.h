@interface __CMKVideoPreviewViewAccessibility_super : UIAccessibilitySafeCategory

@end
