@interface MPUTransportControlMediaRemoteControllerAccessibility : __MPUTransportControlMediaRemoteControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)setNowPlayingInfo:(id)a0;

@end
