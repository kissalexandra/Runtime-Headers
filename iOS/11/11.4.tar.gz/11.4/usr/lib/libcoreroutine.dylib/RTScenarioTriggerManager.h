@class RTBluetoothManager, RTStarkManager, RTPlatform, RTVisitManager, RTDeviceLocationPredictor, RTMotionActivityManager, RTWiFiFootprintMonitor, RTLearnedLocationManager;

@interface RTScenarioTriggerManager : RTNotifier

@property (nonatomic) unsigned long long connectedToCarSignalCount;
@property (nonatomic) unsigned long long interestedInCarKitConnectionState;
@property (nonatomic) unsigned long long interestedInConstantFootprint;
@property (nonatomic) unsigned long long interestedInSettledState;
@property (nonatomic) unsigned long long interestedInStarkConnectionState;
@property (nonatomic) unsigned long long interestedInVisits;
@property (nonatomic) long long carKitConnectionState;
@property (retain, nonatomic) RTBluetoothManager *bluetoothManager;
@property (retain, nonatomic) RTDeviceLocationPredictor *deviceLocationPredictor;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTMotionActivityManager *motionActivityManager;
@property (nonatomic) unsigned long long motionSettledState;
@property (retain, nonatomic) RTPlatform *platform;
@property (nonatomic) unsigned long long settledState;
@property (nonatomic) unsigned long long monitoredScenarioTriggerTypes;
@property (nonatomic) long long starkConnectionState;
@property (retain, nonatomic) RTStarkManager *starkManager;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) RTWiFiFootprintMonitor *wifiFootprintMonitor;
@property (nonatomic) long long wiFiFootprintState;

+ (id)settledStateName:(unsigned long long)a0;
+ (id)scenarioTriggerTypeToNotificationName:(unsigned long long)a0;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_onVisitManagerNotification:(id)a0;
- (void)onVisitManagerNotification:(id)a0;
- (void)_startMonitoringScenarioTriggerOfType:(unsigned long long)a0;
- (id)initWithDeviceLocationPredictor:(id)a0 learnedLocationManager:(id)a1 visitManager:(id)a2 motionActivityManager:(id)a3 wifiFootprintMonitor:(id)a4 bluetoothManager:(id)a5 starkManager:(id)a6 platform:(id)a7;
- (void)_evaluateSettledState;
- (void)_stopMonitoringScenarioTriggerOfType:(unsigned long long)a0;
- (unsigned long long)_notificationNameToScenarioTriggerType:(id)a0;
- (void)_checkForFirstTimeInCityWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForFirstTimeInNeighborhoodWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForFirstTimeAtLocationWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForLastTimeAtLocationWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForAtFamiliarLocationWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForArrivedEarlyWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForStayedLateWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForHeadedToHomeWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForHeadedToWorkWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_handleVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_handleVisit:(id)a0;
- (void)_onMotionActivityManagerNotification:(id)a0;
- (void)onMotionActivityManagerNotification:(id)a0;
- (void)_onWiFiFootprintStateNotification:(id)a0;
- (void)onWiFiFootprintStateNotification:(id)a0;
- (void)_onBluetoothManagerNotification:(id)a0;
- (void)onBluetoothManagerNotification:(id)a0;
- (void)_checkForConnectedToCarAfterCarKitConnectionStateChangedFrom:(long long)a0 to:(long long)a1;
- (void)_onStarkManagerNotification:(id)a0;
- (void)onStarkManagerNotification:(id)a0;
- (void)_checkForConnectedToCarAfterStarkConnectionStateChangedFrom:(long long)a0 to:(long long)a1;
- (void)postScenarioTriggerNotification:(id)a0;
- (void)_postScenarioTriggerNotification:(id)a0;
- (void)onPostScenarioTriggerNotificationFromDefaults;
- (void)simulateScenarioTrigger:(id)a0 handler:(id /* block */)a1;

@end
