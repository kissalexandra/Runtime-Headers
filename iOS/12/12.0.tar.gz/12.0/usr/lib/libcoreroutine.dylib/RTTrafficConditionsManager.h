@class RTDeviceLocationPredictor, RTPLOIETA, RTMotionActivityManager, NSObject, RTMapServiceManager, RTDefaultsManager, RTMapsSupportManager, RTMetricManager, RTPlatform, NSDate, NSMutableArray, RTStarkManager, RTPersistentTimer, RTLocationManager, RTAuthorizationManager, RTVisitManager;
@protocol OS_dispatch_queue;

@interface RTTrafficConditionsManager : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTMotionActivityManager *motionActivityManager;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTDeviceLocationPredictor *deviceLocationPredictor;
@property (retain, nonatomic) RTStarkManager *starkManager;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (retain, nonatomic) RTMapsSupportManager *mapsSupportManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTPlatform *platform;
@property (nonatomic) unsigned long long vehicleConnectedState;
@property (retain, nonatomic) RTPLOIETA *ploiEta;
@property (retain, nonatomic) NSDate *showTrafficConditionsDate;
@property (retain, nonatomic) RTPersistentTimer *showTrafficConditionsTimer;
@property (retain, nonatomic) NSMutableArray *trafficConditionsMetrics;

+ (BOOL)mapsAuthorized;

- (void)_setup;
- (void)submitMetric:(id)a0;
- (void)onVisitManagerNotification:(id)a0;
- (void)_onVisitManagerNotification:(id)a0;
- (id)initWithDefaultsManager:(id)a0 motionActivityManager:(id)a1 visitManager:(id)a2 locationManager:(id)a3 authorizationManager:(id)a4 deviceLocationPredictor:(id)a5 starkManager:(id)a6 mapServiceManager:(id)a7 mapsSupportManager:(id)a8 metricManager:(id)a9 platform:(id)a10;
- (void)_handleVisit:(id)a0;
- (void)_clearTrafficConditions;
- (void)setShowTrafficConditionsTimer;
- (void)onMotionActivityNotification:(id)a0;
- (void)_showTrafficConditions;
- (void)_updateTrafficConditions;
- (void)_onMotionActivityNotification:(id)a0;
- (void)fetchPLOIETAFrom:(id)a0 to:(id)a1 withHandler:(id /* block */)a2;
- (void)fetchPLOIETAWithHandler:(id /* block */)a0;
- (void)submitMetrics;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
