@interface MFComposeHeaderViewAccessibility : __MFComposeHeaderViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)_accessibilityOverridesInvisibility;

@end
