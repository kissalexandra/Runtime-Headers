@interface ZoomUI_SpringBoardOverride : __ZoomUI_SpringBoardOverride_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (double)_accessibilityActivationAnimationStartDelay;
- (double)_accessibilityDeactivationAnimationStartDelay;
- (void)_accessibilityActivationAnimationWillBegin;
- (void)_accessibilityDeactivationAnimationWillBegin;

@end
