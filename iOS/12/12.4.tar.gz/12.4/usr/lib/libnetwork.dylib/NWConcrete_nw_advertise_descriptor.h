@class NSString;

@interface NWConcrete_nw_advertise_descriptor : NSObject <OS_nw_advertise_descriptor> {
    char *_name;
    char *_type;
    char *_domain;
    char *_txtRecord;
    unsigned long long _txtLength;
    unsigned char _no_auto_rename : 1;
    unsigned char __pad_bits : 7;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)initWithName:(const char *)a0 type:(const char *)a1 domain:(const char *)a2;
- (void)dealloc;

@end
