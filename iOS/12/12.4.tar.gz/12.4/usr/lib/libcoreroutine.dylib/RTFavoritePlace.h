@class NSString, RTMapItem;

@interface RTFavoritePlace : NSObject

@property (readonly, nonatomic) NSString *title;
@property (readonly, nonatomic) RTMapItem *mapItem;

- (id)initWithTitle:(id)a0 mapItem:(id)a1;
- (id)init;
- (void).cxx_destruct;
- (id)description;

@end
