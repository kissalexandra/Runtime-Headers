@interface MKAnnotationCalloutControllerAccessibility : __MKAnnotationCalloutControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

@end
