@class NSSet, RTPredictionItemMO, RTPredictionTableMO;

@interface RTPredictionTableEntryMO : NSManagedObject

@property (retain, nonatomic) NSSet *conditions;
@property (retain, nonatomic) RTPredictionItemMO *item;
@property (retain, nonatomic) RTPredictionTableMO *predictionTable;

+ (id)managedObjectWithItem:(id)a0 conditions:(id)a1 inManagedObjectContext:(id)a2;

@end
