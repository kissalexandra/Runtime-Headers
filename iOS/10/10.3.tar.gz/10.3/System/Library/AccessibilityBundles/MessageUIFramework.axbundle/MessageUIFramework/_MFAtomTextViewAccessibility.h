@interface _MFAtomTextViewAccessibility : ___MFAtomTextViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;
- (struct CGPoint { double x0; double x1; })accessibilityActivationPoint;
- (unsigned long long)accessibilityTraits;
- (BOOL)_accessibilityOverridesInvisibility;

@end
