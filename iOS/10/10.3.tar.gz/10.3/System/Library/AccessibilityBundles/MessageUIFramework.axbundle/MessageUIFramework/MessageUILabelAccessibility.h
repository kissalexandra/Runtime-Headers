@interface MessageUILabelAccessibility : __MessageUILabelAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;
- (BOOL)isAccessibilityElement;
- (BOOL)_accessibilityIsScannerElement;

@end
