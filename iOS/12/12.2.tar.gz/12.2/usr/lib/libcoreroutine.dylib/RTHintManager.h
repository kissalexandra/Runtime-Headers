@class NSObject, RTNavigationManager, RTPlatform, RTBatteryManager, RTMetricManager, NSString, RTReachabilityManager, RTPersistenceManager, RTLearnedLocationManager, RTWalletManager, RTCameraManager, RTLocationManager, RTBluetoothManager;
@protocol OS_dispatch_queue;

@interface RTHintManager : NSObject <RTPurgable>

@property (retain, nonatomic) RTBluetoothManager *bluetoothManager;
@property (retain, nonatomic) RTBatteryManager *batteryManager;
@property (retain, nonatomic) RTCameraManager *cameraManager;
@property (retain, nonatomic) RTNavigationManager *navigationManager;
@property (retain, nonatomic) RTReachabilityManager *reachabilityManager;
@property (retain, nonatomic) RTWalletManager *walletManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)boundingBoxPredicateForLocation:(id)a0;

- (void)_unregisterForNotifications;
- (void)shutdown;
- (void)_registerForNotifications;
- (id)initWithBluetoothManager:(id)a0 batteryManager:(id)a1 navigationManager:(id)a2 reachabilityManager:(id)a3 walletManager:(id)a4 locationManager:(id)a5 metricManager:(id)a6 learnedLocationManager:(id)a7 persistenceManager:(id)a8 cameraManager:(id)a9 platform:(id)a10;
- (void)purgeManager:(id)a0 performPurgeOfType:(long long)a1 completion:(id /* block */)a2;
- (void)fetchIsHintNearLocation:(id)a0 withHandler:(id /* block */)a1;
- (void)fetchHintStatsNearLocation:(id)a0 handler:(id /* block */)a1;
- (void)onBluetoothNotification:(id)a0;
- (void)onBatteryNotification:(id)a0;
- (void)onNavigationNotification:(id)a0;
- (void)onReachabilityChange:(id)a0;
- (void)onCameraNotification:(id)a0;
- (void)onWalletNotification:(id)a0;
- (void)_submitHintFromSource:(long long)a0 location:(id)a1;
- (void)_submitHintFromSource:(long long)a0 location:(id)a1 managedObjectContext:(id)a2;
- (void)_fetchHintStatsNearLocation:(id)a0 managedObjectContext:(id)a1 handler:(id /* block */)a2;
- (void)_clearHintsPredating:(id)a0 managedObjectContext:(id)a1 handler:(id /* block */)a2;
- (void)_clearHintsPredating:(id)a0 handler:(id /* block */)a1;
- (void)_onBluetoothNotification:(id)a0;
- (void)_submitHintFromSource:(long long)a0;
- (void)_onBatteryNotification:(id)a0;
- (void)_onNavigationNotification:(id)a0;
- (void)_onReachabilityChange:(id)a0;
- (void)_onCameraNotification:(id)a0;
- (void)_onWalletNotification:(id)a0;
- (id)init;
- (void).cxx_destruct;

@end
