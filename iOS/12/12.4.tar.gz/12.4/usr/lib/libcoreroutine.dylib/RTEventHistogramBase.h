@class NSString;

@interface RTEventHistogramBase : NSObject <RTEventHistogram, NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)addEvent:(id)a0;
- (void)addEvents:(id)a0;
- (id)top;
- (void)addEventId:(id)a0;
- (id)allSortedEventIdsWithComparator:(id /* block */)a0;
- (id)allEventIds;
- (double)weightForEventId:(id)a0;
- (id)topN:(unsigned long long)a0 usingComparator:(id /* block */)a1;
- (id)allSortedByWeightEventIds;
- (void)addEventIds:(id)a0;
- (void)addEvent:(id)a0 weight:(double)a1;
- (void)addEventId:(id)a0 weight:(double)a1;
- (id)topN:(unsigned long long)a0;
- (id)topUsingComparator:(id /* block */)a0;
- (id)init;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void)reset;
- (void)clear;

@end
