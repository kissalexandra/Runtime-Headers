@interface AXHearingGapCell : UITableViewCell

+ (id)gapCell;

@end
