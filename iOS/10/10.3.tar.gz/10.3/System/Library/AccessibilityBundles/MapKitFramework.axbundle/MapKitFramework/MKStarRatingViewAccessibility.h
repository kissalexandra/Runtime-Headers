@interface MKStarRatingViewAccessibility : __MKStarRatingViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (id)ratingAsAttributedString:(double)a0 baseFont:(id)a1 style:(long long)a2;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (BOOL)isAccessibilityElement;

@end
