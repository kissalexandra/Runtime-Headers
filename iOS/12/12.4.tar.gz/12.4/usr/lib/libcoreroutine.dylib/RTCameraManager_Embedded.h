@class RTDarwinNotificationHelper;

@interface RTCameraManager_Embedded : RTCameraManager

@property (readonly, nonatomic) RTDarwinNotificationHelper *notificationHelper;

- (void)_shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)handleCameraPowerNotification:(id)a0;
- (void)_handleCameraPowerNotification:(id)a0;
- (id)init;
- (void)dealloc;
- (void).cxx_destruct;

@end
