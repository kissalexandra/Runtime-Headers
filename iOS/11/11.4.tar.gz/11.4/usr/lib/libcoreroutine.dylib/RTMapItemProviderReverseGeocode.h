@class NSString, RTMapServiceManager;

@interface RTMapItemProviderReverseGeocode : NSObject <RTMapItemProvider>

@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void).cxx_destruct;
- (id)mapItemsWithinDistance:(double)a0 location:(id)a1 startDate:(id)a2 endDate:(id)a3 error:(id *)a4;
- (id)initWithMapServiceManager:(id)a0;

@end
