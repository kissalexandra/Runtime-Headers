@interface CAMTopBarAccessibility : __CAMTopBarAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)shouldGroupAccessibilityChildren;
- (BOOL)_accessibilityOnlyComparesByXAxis;
- (void)collapseMenuButton:(id)a0 animated:(BOOL)a1;
- (void)expandMenuButton:(id)a0 animated:(BOOL)a1;

@end
