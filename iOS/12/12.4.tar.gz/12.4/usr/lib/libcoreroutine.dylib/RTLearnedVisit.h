@class NSString, NSUUID, RTLearnedLocation, NSDate;

@interface RTLearnedVisit : NSObject <RTCoreDataTransformable>

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;
@property (nonatomic) double placeConfidence;
@property (nonatomic) unsigned long long placeSource;
@property (readonly, nonatomic) NSUUID *identifier;
@property (readonly, nonatomic) RTLearnedLocation *location;
@property (readonly, nonatomic) NSDate *entryDate;
@property (readonly, nonatomic) NSDate *exitDate;
@property (readonly, nonatomic) NSDate *creationDate;
@property (readonly, nonatomic) NSDate *expirationDate;

- (id)managedObjectWithContext:(id)a0;
- (id)initWithIdentifier:(id)a0 location:(id)a1 entryDate:(id)a2 exitDate:(id)a3 creationDate:(id)a4 expirationDate:(id)a5;
- (id)initWithIdentifier:(id)a0 location:(id)a1 entryDate:(id)a2 exitDate:(id)a3 creationDate:(id)a4 expirationDate:(id)a5 placeConfidence:(double)a6 placeSource:(unsigned long long)a7;
- (id)initWithVisit:(id)a0 locationOfInterest:(id)a1 creationDate:(id)a2 expirationDate:(id)a3;
- (id)initWithVisitMO:(id)a0;
- (id)initWithLocationOfInterestVisitMO:(id)a0;
- (id)init;
- (BOOL)isEqual:(id)a0;
- (void).cxx_destruct;

@end
