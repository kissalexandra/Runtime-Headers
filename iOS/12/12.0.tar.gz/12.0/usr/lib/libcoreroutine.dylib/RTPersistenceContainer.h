@class NSString, NSPersistentStoreCoordinator, NSArray, NSObject;
@protocol OS_dispatch_queue;

@interface RTPersistenceContainer : NSObject {
    NSArray *_configurations;
}

@property (retain) NSObject<OS_dispatch_queue> *contextRequestsQueue;
@property BOOL serveContexts;
@property BOOL setupFailed;
@property (retain) NSPersistentStoreCoordinator *coordinator;
@property (readonly) NSString *name;
@property (readonly) BOOL storesNeedSetup;

- (id)waitForPersistenceContext;
- (id)initWithName:(id)a0 model:(id)a1 configurations:(id)a2;
- (BOOL)_validateConfigurations:(id)a0;
- (id)_persistenceContext;
- (void)suspendPersistenceStores;
- (void)resumePersistenceStores;
- (id)tearDownPersistenceStack;
- (void)setupPersistenceStores;
- (BOOL)updateContainerConfigurations:(id)a0;
- (void)persistenceContextWithHandler:(id /* block */)a0;
- (id)persistenceContext;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
