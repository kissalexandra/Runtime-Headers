@class NSString;

@interface RTApplicationProxy : NSObject

@property (copy, nonatomic) NSString *bundleIdentifier;
@property (copy, nonatomic) NSString *localizedName;
@property (nonatomic) long long capabilities;
@property (nonatomic) BOOL installed;
@property (nonatomic) BOOL restricted;

- (void).cxx_destruct;
- (id)description;
- (id)initWithBundleIdentifier:(id)a0 applicationProxy:(id)a1 capabilities:(long long)a2;

@end
