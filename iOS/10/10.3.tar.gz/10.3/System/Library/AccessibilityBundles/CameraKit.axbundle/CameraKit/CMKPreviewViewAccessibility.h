@interface CMKPreviewViewAccessibility : __CMKPreviewViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;
- (struct CGPoint { double x0; double x1; })accessibilityActivationPoint;
- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;
- (void)_showFocusAtPoint:(struct CGPoint { double x0; double x1; })a0 startAnimating:(BOOL)a1;
- (BOOL)_axShowingEffects;
- (BOOL)_axIsFocusLocked;
- (void)_accessibilityZoomIn:(BOOL)a0;
- (void)_accessibilityLoadAccessibilityInformation;
- (id)accessibilityContainerElements;
- (BOOL)_accessibilityAllowsSiblingsWhenOvergrown;
- (void)accessibilityZoomInAtPoint:(struct CGPoint { double x0; double x1; })a0;
- (void)accessibilityZoomOutAtPoint:(struct CGPoint { double x0; double x1; })a0;

@end
