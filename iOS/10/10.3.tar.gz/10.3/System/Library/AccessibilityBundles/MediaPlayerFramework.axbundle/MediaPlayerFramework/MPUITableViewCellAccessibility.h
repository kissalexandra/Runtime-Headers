@interface MPUITableViewCellAccessibility : __MPUITableViewCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (unsigned long long)accessibilityTraits;

@end
