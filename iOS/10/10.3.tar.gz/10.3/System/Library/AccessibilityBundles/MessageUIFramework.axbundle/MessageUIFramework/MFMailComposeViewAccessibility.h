@interface MFMailComposeViewAccessibility : __MFMailComposeViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)scrollViewDidScroll:(id)a0;
- (void)didMoveToSuperview;
- (BOOL)shouldGroupAccessibilityChildren;
- (void)setFromAddressPickerVisible:(BOOL)a0 animated:(BOOL)a1;
- (id)_searchResultsTable;
- (BOOL)presentSearchResults:(id)a0;
- (void)_accessibilityLoadAccessibilityInformation;
- (long long)_accessibilityCompareElement:(id)a0 toElement:(id)a1;
- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0 options:(unsigned long long)a1;

@end
