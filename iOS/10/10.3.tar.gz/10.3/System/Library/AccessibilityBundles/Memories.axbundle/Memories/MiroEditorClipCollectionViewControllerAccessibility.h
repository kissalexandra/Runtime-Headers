@interface MiroEditorClipCollectionViewControllerAccessibility : __MiroEditorClipCollectionViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityScroll:(long long)a0;

@end
