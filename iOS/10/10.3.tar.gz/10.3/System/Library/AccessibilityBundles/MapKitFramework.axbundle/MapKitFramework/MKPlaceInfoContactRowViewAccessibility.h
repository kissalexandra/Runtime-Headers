@interface MKPlaceInfoContactRowViewAccessibility : __MKPlaceInfoContactRowViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0;
- (BOOL)isAccessibilityElement;
- (id)accessibilityElements;
- (void)setLabeledValue:(id)a0;
- (void)_accessibilityLoadAccessibilityInformation;

@end
