@class RTMicroLocation, RTAuthorizationManager, RTVisitManager, RTInvocationDispatcher, RTLearnedLocationManager, NSObject, RTLocationManager, RTLocationOfInterest;
@protocol OS_dispatch_queue;

@interface RTLocationTagger : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (nonatomic) BOOL ready;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (nonatomic) BOOL realtimeLocationTaggingAllowed;
@property (nonatomic) BOOL historicLocationTaggingAllowed;
@property (nonatomic) double maximumEventLocationTaggingTimeInterval;
@property (retain, nonatomic) RTMicroLocation *currentMicroLocation;
@property (retain, nonatomic) RTLocationOfInterest *currentLocationOfInterest;

- (id)init;
- (void).cxx_destruct;
- (void)_unregisterForNotifications;
- (void)_registerForNotifications;
- (void)shutdown;
- (id)initWithAuthorizationManager:(id)a0 locationManager:(id)a1 learnedLocationManager:(id)a2 visitManager:(id)a3;
- (void)_fetchLowConfidenceVisitIncident:(id /* block */)a0;
- (void)_handleLowConfidenceVisitIncident:(id)a0;
- (void)_armLocationTagger;
- (void)_disarmLocationTagger;
- (void)onVisitManagerAvailable:(id)a0;
- (void)onMicroLocationUpdate:(id)a0;
- (void)onMagicalMomentsLocationUsageUpdate:(id)a0;
- (void)onRoutineEnabledUpdate:(id)a0;
- (void)onLowConfidenceVisitNotification:(id)a0;
- (BOOL)tagObjectWithLocation:(id)a0 error:(id *)a1;
- (void)tagObjectWithLocation:(id)a0 handler:(id /* block */)a1;
- (void)_performTagWithObject:(id)a0;
- (BOOL)_validateObject:(id)a0;
- (void)realtimeLocationTaggingAllowed:(id /* block */)a0;
- (void)historicalLocationTaggingAllowed:(id /* block */)a0;
- (void)tagObject:(id)a0 withLocationVisitEvents:(id)a1;
- (void)tagObject:(id)a0 withMicroLocationEvents:(id)a1 minimumProbability:(double)a2;

@end
