@class NSString;

@interface NWConcrete_nw_activity : NSObject <OS_nw_activity> {
    unsigned char token[16];
    unsigned long long investigation_identifier;
    unsigned long long start_time;
    unsigned long long end_time;
    NWConcrete_nw_activity *parent;
    unsigned int label;
    unsigned int domain;
    int reporting_strategy;
    int completion_reason;
    struct atomic_flag { _Atomic BOOL _Value; } activated;
    struct atomic_flag { _Atomic BOOL _Value; } completed;
    unsigned char is_retry : 1;
    unsigned char is_lightweight : 1;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)initWithDomain:(unsigned int)a0 label:(unsigned int)a1;
- (id)initWithToken:(unsigned char[16])a0;
- (id)initWithOriginal:(id)a0;
- (void).cxx_destruct;
- (void)dealloc;

@end
