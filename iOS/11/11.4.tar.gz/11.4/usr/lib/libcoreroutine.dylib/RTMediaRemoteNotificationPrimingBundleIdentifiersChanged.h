@class NSSet;

@interface RTMediaRemoteNotificationPrimingBundleIdentifiersChanged : RTNotification

@property (readonly, copy, nonatomic) NSSet *bundleIdentifiers;

- (void).cxx_destruct;
- (id)initWithBundleIdentifiers:(id)a0;

@end
