@class NSArray;

@interface RTLocationManagerNotificationMicroLocations : RTNotification

@property (readonly, nonatomic) NSArray *microLocations;

- (id)initWithMicroLocations:(id)a0;
- (void).cxx_destruct;

@end
