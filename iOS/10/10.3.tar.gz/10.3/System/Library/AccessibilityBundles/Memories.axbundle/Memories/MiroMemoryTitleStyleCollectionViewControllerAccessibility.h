@interface MiroMemoryTitleStyleCollectionViewControllerAccessibility : __MiroMemoryTitleStyleCollectionViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)collectionView:(id)a0 cellForItemAtIndexPath:(id)a1;
- (id)_axTitleStyleNameForMoodDict:(id)a0;

@end
