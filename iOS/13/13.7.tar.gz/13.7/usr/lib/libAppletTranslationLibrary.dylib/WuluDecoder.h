@interface WuluDecoder : NSObject <ATLStatefulDecoder> {
    unsigned long long decoderState;
    BOOL debug;
}

+ (id)getInstance;

- (id)init;
- (void)cleanup;
- (id)getState:(id)a0;
- (id)getAppletStateAndHistory:(id)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 withError:(id *)a4;
- (id)getAppletStateAndHistory:(id)a0 withError:(id *)a1;
- (void)setTimer:(id)a0 history:(id)a1 error:(id *)a2;
- (id)getHistory:(id)a0 error:(id *)a1;
- (id)adjustHistory:(id)a0;
- (void)adjustState:(id)a0 latestTransaction:(id)a1 ctx:(id)a2;
- (void)removeEnRouteForSingleTapBusGuangdong:(id)a0 history:(id)a1 cityCode:(id)a2;
- (void)setMetroEntryWithLocalLog:(id)a0 ctx:(id)a1;
- (BOOL)isMetroEntry:(id)a0 cityCode:(id)a1 setting:(id)a2 error:(id *)a3;
- (void)removeDoubleMetroTapGuangdong:(id)a0 history:(id)a1 cityCode:(id)a2;
- (void)addFakeBusTxnGuangdong:(id)a0 history:(id)a1 cityCode:(id)a2;
- (unsigned short)convertWalletSNtoAppletSN:(id)a0;
- (unsigned int)convertAppletSNtoWalletSN:(unsigned short)a0 txnTypeIdentifier:(unsigned int)a1;
- (id)findNextCappPuchaseEntry:(id)a0 history:(id)a1;
- (id)parseFile18:(id)a0;
- (void)parseTransit:(id)a0 file1E:(id)a1 file1A:(id)a2 ctx:(id)a3 into:(id)a4;
- (id)resolveTransitModality:(unsigned char)a0;
- (void)parseTransitApollo:(id)a0 file1E:(id)a1 file1A:(id)a2 into:(id)a3;
- (void)parseTransitKepler:(id)a0 file1E:(id)a1 file1A:(id)a2 into:(id)a3;
- (void)parseTransitPioneer:(id)a0 file1E:(id)a1 file1A:(id)a2 into:(id)a3;
- (void)parseTransitGalileo:(id)a0 file1E:(id)a1 file1A:(id)a2 into:(id)a3;
- (void)parseTransitSettingBased:(id)a0 file1E:(id)a1 file1A:(id)a2 ctx:(id)a3 into:(id)a4;
- (id)getStationCode:(id)a0 codeSetting:(id)a1 cityCode:(id)a2;
- (id)parseStartEvent:(id)a0 withApplet:(id)a1 withError:(id *)a2;
- (id)parseEndEvent:(id)a0 withApplet:(id)a1 withError:(id *)a2;
- (id)parseHCIEvent:(id)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 withTransceiver:(id)a4 withError:(id *)a5;
- (id)GetAppletProperties:(id)a0 withPackage:(id)a1 withModule:(id)a2 withTransceiver:(id)a3 withError:(id *)a4;
- (id)processEndOfTransaction:(id)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 withError:(id *)a4;

@end
