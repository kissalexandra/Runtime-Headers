@class NSString;

@interface RTContactPostalAddress : RTAddress

@property (readonly, copy, nonatomic) NSString *contactsIdentifier;
@property (readonly, nonatomic) unsigned long long labelType;

+ (id)labelTypeToString:(unsigned long long)a0;

- (id)init;
- (id)description;
- (void).cxx_destruct;
- (id)dictionaryRepresentation;
- (id)initWithIdentifier:(id)a0 subThoroughfare:(id)a1 thoroughfare:(id)a2 subLocality:(id)a3 locality:(id)a4 subAdministrativeArea:(id)a5 administrativeArea:(id)a6 administrativeAreaCode:(id)a7 postalCode:(id)a8 country:(id)a9 countryCode:(id)a10 inlandWater:(id)a11 ocean:(id)a12 areasOfInterest:(id)a13 isIsland:(BOOL)a14 creationDate:(id)a15 expirationDate:(id)a16 iso3166CountryCode:(id)a17 iso3166SubdivisionCode:(id)a18;
- (id)geoDictionaryRepresentation;
- (id)initWithIdentifier:(id)a0 subThoroughfare:(id)a1 thoroughfare:(id)a2 subLocality:(id)a3 locality:(id)a4 subAdministrativeArea:(id)a5 administrativeArea:(id)a6 administrativeAreaCode:(id)a7 postalCode:(id)a8 country:(id)a9 countryCode:(id)a10 inlandWater:(id)a11 ocean:(id)a12 areasOfInterest:(id)a13 isIsland:(BOOL)a14 creationDate:(id)a15 expirationDate:(id)a16 contactsIdentifier:(id)a17 labelType:(unsigned long long)a18 iso3166CountryCode:(id)a19 iso3166SubdivisionCode:(id)a20;
- (id)initWithIdentifier:(id)a0 lableType:(unsigned long long)a1 geoDictionary:(id)a2;

@end
