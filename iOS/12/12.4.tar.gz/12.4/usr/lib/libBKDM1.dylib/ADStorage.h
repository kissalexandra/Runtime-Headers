@class NSMutableArray;

@interface ADStorage : NSObject {
    NSMutableArray *_eventList;
}

+ (id)storage;

- (void)addEvent:(id)a0;
- (void)pushToAggregateDictionary:(long long)a0 useCase:(int)a1 prearmedApplePay:(BOOL)a2;
- (id)init;
- (void)dealloc;
- (void)clear;

@end
