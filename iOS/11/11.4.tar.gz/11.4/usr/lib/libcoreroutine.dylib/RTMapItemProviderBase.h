@class RTDistanceCalculator;

@interface RTMapItemProviderBase : NSObject

@property (readonly, nonatomic) RTDistanceCalculator *distanceCalculator;

- (id)init;
- (void).cxx_destruct;
- (id)initWithDistanceCalculator:(id)a0;
- (id)filter:(id)a0 byDistance:(double)a1 fromLocation:(id)a2 andAppendSource:(unsigned long long)a3 error:(id *)a4;
- (id)filter:(id)a0 byDistance:(double)a1 fromLocation:(id)a2 error:(id *)a3;

@end
