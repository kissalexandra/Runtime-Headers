@interface OS_nw_protocol_coretls : OS_object

- (void)_dispose;

@end
