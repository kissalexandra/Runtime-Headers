@class NSNumber, RTRouteMO, NSDate;

@interface RTRouteLocationMO : NSManagedObject

@property (copy, nonatomic) NSNumber *latitude;
@property (copy, nonatomic) NSNumber *longitude;
@property (copy, nonatomic) NSNumber *uncertainty;
@property (copy, nonatomic) NSDate *date;
@property (copy, nonatomic) NSNumber *referenceFrame;
@property (retain, nonatomic) RTRouteMO *route;

+ (id)fetchRequest;
+ (id)managedObjectWithLocation:(id)a0 inManagedObjectContext:(id)a1;

@end
