@interface OS_nw_interface : OS_object

- (id)description;
- (void)_dispose;

@end
