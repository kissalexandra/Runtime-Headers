@class CMMotionActivity;

@interface RTStateTransitionActivityHistogramElement : NSObject <NSCopying>

@property (retain, nonatomic) CMMotionActivity *activity;
@property (nonatomic) double interval;

- (id)initWithActivity:(id)a0;
- (id)copyWithZone:(struct _NSZone { } *)a0;
- (void).cxx_destruct;

@end
