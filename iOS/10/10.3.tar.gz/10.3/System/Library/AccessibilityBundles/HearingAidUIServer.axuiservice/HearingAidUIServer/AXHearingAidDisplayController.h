@class AXHearingAidCenterController, HearingAidUIServer, UIPopoverPresentationController, NSString, UIStatusBar;

@interface AXHearingAidDisplayController : UIViewController <UIPopoverControllerDelegate, UIPopoverPresentationControllerDelegate, AXHearingAidStatusBarDelegate> {
    BOOL _isLiveListening;
}

@property (retain, nonatomic) AXHearingAidCenterController *detailController;
@property (retain, nonatomic) UIPopoverPresentationController *ipadPopoverController;
@property (nonatomic) HearingAidUIServer *parentController;
@property (retain, nonatomic) UIStatusBar *statusBar;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (BOOL)_shouldForwardViewWillTransitionToSize;

- (void)dealloc;
- (void)viewDidAppear:(BOOL)a0;
- (void)viewWillTransitionToSize:(struct CGSize { double x0; double x1; })a0 withTransitionCoordinator:(id)a1;
- (void)popoverPresentationControllerDidDismissPopover:(id)a0;
- (void)popoverPresentationController:(id)a0 willRepositionPopoverToRect:(inout struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; } *)a1 inView:(inout id *)a2;
- (void)dismissWithCompletion:(id /* block */)a0;
- (void)statusBar:(id)a0 didUpdateHeight:(double)a1;
- (void)_updateContentSizeWithStatusBarHeight:(double)a0;

@end
