@interface MPUSkipLimitViewAccessibility : __MPUSkipLimitViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)revealSkipInformationMomentarily;

@end
