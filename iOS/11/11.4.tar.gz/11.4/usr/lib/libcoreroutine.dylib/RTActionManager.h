@class NSObject, RTLearnedLocationOfInterest, RTLearnedLocationManager, RTDeviceLocationPredictor, RTVisitManager, RTEventManager, RTLocationManager;
@protocol OS_dispatch_queue;

@interface RTActionManager : NSObject {
    RTLearnedLocationOfInterest *_currentLocationOfInterest;
}

@property (retain, nonatomic) RTDeviceLocationPredictor *deviceLocationPredictor;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTEventManager *eventManager;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;

- (id)init;
- (void).cxx_destruct;
- (void)_handleLowConfidenceVisitIncident:(id)a0;
- (void)onLowConfidenceVisitNotification:(id)a0;
- (id)initWithDeviceLocationPredictor:(id)a0 learnedLocationManager:(id)a1 locationManager:(id)a2 eventManager:(id)a3 visitManager:(id)a4;
- (void)fetchPredictedConditionsForAction:(id)a0 dateInterval:(id)a1 handler:(id /* block */)a2;
- (void)_fetchPredictedConditionsForAction:(id)a0 dateInterval:(id)a1 handler:(id /* block */)a2;
- (void)_fetchPredictedConditionsForActionWithCalendarRestriction:(id)a0 dateInterval:(id)a1 handler:(id /* block */)a2;
- (void)_fetchPredictedConditionsForActionWithLocationRestriction:(id)a0 dateInterval:(id)a1 handler:(id /* block */)a2;
- (void)startMonitoringPredictedConditionsForAction:(id)a0 handler:(id /* block */)a1;
- (void)stopMonitoringPredictedConditionsForAction:(id)a0 handler:(id /* block */)a1;
- (void)provideFeedbackForAction:(id)a0 engagementResult:(long long)a1 handler:(id /* block */)a2;

@end
