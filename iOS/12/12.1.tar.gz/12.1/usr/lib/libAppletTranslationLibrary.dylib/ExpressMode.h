@interface ExpressMode : NSObject

+ (id)SerializeConfigurationDataForSE:(id)a0 fastPath:(BOOL)a1 error:(id *)a2;
+ (BOOL)PerformActivations:(id)a0 transceiver:(id)a1 fastPath:(BOOL)a2 seHasActivatedApplets:(BOOL *)a3 error:(id *)a4;
+ (BOOL)configureSE:(id)a0 transceiver:(id)a1 seHasActivatedApplets:(BOOL *)a2 skipAllActivations:(BOOL)a3 fastPath:(BOOL)a4 error:(id *)a5;
+ (id)checkAppletCompatibility:(id)a0 fastPath:(BOOL *)a1 error:(id *)a2;

@end
