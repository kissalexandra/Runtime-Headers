@interface MediaPlayerUINavigationButtonAccessibility : __MediaPlayerUINavigationButtonAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;

@end
