@interface MKAnnotationViewAccessibility : __MKAnnotationViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (id)_disclosureCalloutButton;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityHint;
- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;
- (id)_accessibilityHitTest:(struct CGPoint { double x0; double x1; })a0 withEvent:(id)a1;

@end
