@interface RTEventDevice : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;


@end
