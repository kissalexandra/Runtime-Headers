@interface MPUTransportControlsViewAccessibility : __MPUTransportControlsViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_configureTransportButton:(id)a0 forTransportControl:(id)a1;
- (void)_accessibilityLoadAccessibilityInformationForTransportButton:(id)a0;
- (void)_accessibilityLoadAccessibilityInformation;

@end
