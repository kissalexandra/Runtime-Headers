@interface RTPriorityQueue : NSObject {
    struct __CFBinaryHeap { } *_heap;
}

@property (readonly, nonatomic) unsigned long long count;

- (id)peek;
- (id)dequeue;
- (void)enqueue:(id)a0;
- (id)init;
- (void)dealloc;
- (id)initWithObjects:(id)a0;

@end
