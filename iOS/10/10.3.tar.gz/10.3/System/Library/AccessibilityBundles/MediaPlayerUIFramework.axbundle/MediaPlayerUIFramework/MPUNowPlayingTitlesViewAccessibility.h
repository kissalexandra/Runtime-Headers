@interface MPUNowPlayingTitlesViewAccessibility : __MPUNowPlayingTitlesViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithStyle:(long long)a0;
- (id)accessibilityLabel;
- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;
- (BOOL)accessibilityElementsHidden;
- (void)_accessibilityLoadAccessibilityInformation;

@end
