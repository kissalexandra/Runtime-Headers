@interface __CMKCameraViewAccessibility_super : UIAccessibilitySafeCategory

@end
