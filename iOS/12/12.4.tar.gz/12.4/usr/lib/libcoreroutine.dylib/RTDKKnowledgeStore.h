@class NSObject;
@protocol OS_dispatch_queue, _DKKnowledgeQuerying;

@interface RTDKKnowledgeStore : NSObject {
    id<_DKKnowledgeQuerying> _knowledgeStore;
    NSObject<OS_dispatch_queue> *_requestQueue;
    NSObject<OS_dispatch_queue> *_queue;
}

+ (id)sharedInstance;

- (void)executeQuery:(id)a0 streamType:(long long)a1 offset:(unsigned long long)a2 withCompletion:(id /* block */)a3;
- (id)init;
- (void).cxx_destruct;
- (void)reset;
- (void)resume;

@end
