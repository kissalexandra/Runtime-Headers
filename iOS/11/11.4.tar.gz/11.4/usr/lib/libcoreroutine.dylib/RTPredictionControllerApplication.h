@class RTMediaRemote, RTApplicationManager, RTPredictionExpertApplicationDataSource;

@interface RTPredictionControllerApplication : RTPredictionController

@property (nonatomic) BOOL routineEnabled;
@property (retain, nonatomic) RTApplicationManager *applicationManager;
@property (retain, nonatomic) RTMediaRemote *mediaRemote;
@property (nonatomic) unsigned long long maxLocationsOfInterestForTraining;
@property (nonatomic) double maxTimeIntervalBeforeTrainingWithoutLocations;
@property (retain, nonatomic) RTPredictionExpertApplicationDataSource *dataSource;

+ (long long)reasonForPredictionWithEvent:(id)a0;

- (id)init;
- (void)invalidate;
- (void).cxx_destruct;
- (void)_unregisterForNotifications;
- (void)_registerForNotifications;
- (void)_setup;
- (void)dumpPredictionTable:(id /* block */)a0;
- (void)fetchPredictionTablePropertyListRepresentationWithHandler:(id /* block */)a0;
- (id)initWithExperts:(id)a0 dataProviders:(id)a1 defaultsManager:(id)a2 authorizationManager:(id)a3 persistenceManager:(id)a4 dataProtectionManager:(id)a5 metricManager:(id)a6 locationTagger:(id)a7 mediaRemote:(id)a8 predictionTable:(id)a9 applicationManager:(id)a10 dataSource:(id)a11;
- (void)_buildExpertsWithHandler:(id /* block */)a0;
- (id)_createExpertsFromClass:(Class)a0 featureAddonArray:(id)a1 dataSource:(id)a2;
- (id)_createExpertFromClass:(Class)a0 featureAddons:(id)a1 dataSource:(id)a2;
- (void)_updateRegisteredDefaults:(id /* block */)a0;
- (void)updateValueForKey:(id)a0 expectedClass:(Class)a1 handler:(id /* block */)a2;
- (void)onDefaultsUpdate:(id)a0;
- (void)onAuthorizationUpdate:(id)a0;
- (void)_processData:(id /* block */)a0;
- (void)__processData:(id /* block */)a0;
- (void)_handleErrorWhileProcessingData:(id)a0 handler:(id /* block */)a1;
- (id)_createPredictedApplicationWithEvent:(id)a0 predictionItem:(id)a1;
- (void)predictWithEvent:(id)a0 limit:(unsigned long long)a1 handler:(id /* block */)a2;
- (void)predictWithEvent:(id)a0 limit:(unsigned long long)a1 confidence:(double)a2 handler:(id /* block */)a3;
- (id)combinePredictions:(id)a0 withFallbackPredictionsForEvent:(id)a1;
- (void)rankUniqueLocationsWithDataProvider:(id)a0 handler:(id /* block */)a1;
- (void)fetchPredictedApplicationsForEvent:(id)a0 handler:(id /* block */)a1;

@end
