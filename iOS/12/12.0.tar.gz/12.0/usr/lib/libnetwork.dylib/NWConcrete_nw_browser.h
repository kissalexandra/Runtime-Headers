@class NSString, NSObject;
@protocol OS_nw_path_evaluator, OS_nw_array, OS_nw_parameters, OS_nw_path, OS_nw_browse_descriptor, OS_dispatch_queue;

@interface NWConcrete_nw_browser : NSObject <OS_nw_browser> {
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } lock;
    NSObject<OS_nw_browse_descriptor> *descriptor;
    NSObject<OS_nw_parameters> *parameters;
    struct _DNSServiceRef_t { } *dns_service;
    struct _DNSServiceRef_t { } *dns_service_secondary_pointer;
    int dns_error;
    NSObject<OS_nw_path_evaluator> *browse_evaluator;
    NSObject<OS_nw_path> *current_browse_path;
    id /* block */ update_handler;
    id /* block */ cancel_handler;
    NSObject<OS_dispatch_queue> *client_queue;
    NSObject<OS_nw_array> *endpoint_array;
    NSObject<OS_nw_array> *path_endpoint_array;
    void *internally_retained_object;
    unsigned char is_custom_browser : 1;
    unsigned char is_nexus_only_browser : 1;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)initWithDescriptor:(id)a0 parameters:(id)a1;
- (void).cxx_destruct;
- (void)dealloc;

@end
