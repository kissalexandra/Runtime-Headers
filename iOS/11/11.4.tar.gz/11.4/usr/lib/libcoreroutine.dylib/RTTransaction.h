@class NSString;

@interface RTTransaction : NSObject

@property (retain, nonatomic) id object;
@property (copy, nonatomic) NSString *userDescription;

- (id)init;
- (void).cxx_destruct;
- (id)initForObject:(id)a0;
- (id)initForObject:(id)a0 description:(id)a1;

@end
