@interface CAMHDRButtonAccessibility : __CAMHDRButtonAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityIdentifier;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;
- (BOOL)accessibilityActivate;

@end
