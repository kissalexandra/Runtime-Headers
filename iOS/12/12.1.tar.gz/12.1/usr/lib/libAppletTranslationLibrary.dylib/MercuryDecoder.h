@interface MercuryDecoder : NSObject

+ (id)parseStartEvent:(id)a0 withApplet:(id)a1 error:(id *)a2;
+ (id)parseActivityTimeout:(id)a0 withApplet:(id)a1 error:(id *)a2;
+ (id)parseEndEvent:(id)a0 withApplet:(id)a1 error:(id *)a2;
+ (id)DecodeE1TLV:(const struct { char *x0; unsigned long long x1; } *)a0 transactionInfo:(id *)a1 error:(id *)a2;
+ (id)DecodeE456TLV:(const struct { char *x0; unsigned long long x1; } *)a0 currencyExponent:(id)a1 error:(id *)a2;
+ (void)RemoveMatchedTapIns:(id)a0 transactionsInProgress:(id)a1;
+ (BOOL)IsIncompatibleApplet:(unsigned int)a0 sw:(unsigned short)a1;
+ (id)parseHCIEvent:(id)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 withTransceiver:(id)a4 withError:(id *)a5;
+ (id)getAppletStateAndHistory:(id)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 withError:(id *)a4;

@end
