@class NSString, NSObject;
@protocol OS_nw_context, OS_nw_interface;

@interface NWConcrete_nw_endpoint : NSObject <OS_nw_endpoint> {
    NSObject<OS_nw_context> *context;
    NSObject<OS_nw_interface> *interface;
    char *description;
    char *logging_description;
    NWConcrete_nw_endpoint *parent_endpoint;
    int original_fd;
    unsigned short alternate_port;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } lock;
    struct nw_hash_table { } *associations;
    unsigned char is_local_domain : 1;
    unsigned char parent_is_proxy : 1;
    unsigned char description_used : 1;
    unsigned char logging_description_used : 1;
}

@property (readonly, nonatomic) unsigned int type;
@property (readonly, nonatomic) const char *domainForPolicy;
@property (readonly, nonatomic) const char *hostname;
@property (readonly, nonatomic) unsigned short port;
@property (nonatomic) unsigned short priority;
@property (nonatomic) unsigned short weight;
@property (readonly, nonatomic) const char *getDescription;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void)dealloc;
- (BOOL)isEqual:(id)a0;
- (id)copyDictionary;
- (id)redactedDescription;
- (void).cxx_destruct;
- (char *)createDescription:(BOOL)a0;
- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1 matchParent:(BOOL)a2;
- (id)copyEndpoint;
- (unsigned long long)getHash;
- (const char *)getLoggingDescription;

@end
