@class RTPlatform, RTWiFiFootprintMonitor, RTLearnedLocationManager, RTDeviceLocationPredictor, RTVisitManager, RTMotionActivityManager;

@interface RTScenarioTriggerManager : RTNotifier

@property (nonatomic) unsigned long long interestedInConstantFootprint;
@property (nonatomic) unsigned long long interestedInSettledState;
@property (nonatomic) unsigned long long interestedInStarkConnectionState;
@property (nonatomic) unsigned long long interestedInVisits;
@property (retain, nonatomic) RTDeviceLocationPredictor *deviceLocationPredictor;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTMotionActivityManager *motionActivityManager;
@property (nonatomic) unsigned long long motionSettledState;
@property (retain, nonatomic) RTPlatform *platform;
@property (nonatomic) unsigned long long settledState;
@property (nonatomic) unsigned long long monitoredScenarioTriggerTypes;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) RTWiFiFootprintMonitor *wifiFootprintMonitor;
@property (nonatomic) long long wiFiFootprintState;

+ (id)settledStateName:(unsigned long long)a0;
+ (id)scenarioTriggerTypeToNotificationName:(unsigned long long)a0;

- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)onVisitManagerNotification:(id)a0;
- (void)_onVisitManagerNotification:(id)a0;
- (id)initWithDeviceLocationPredictor:(id)a0 learnedLocationManager:(id)a1 visitManager:(id)a2 motionActivityManager:(id)a3 wifiFootprintMonitor:(id)a4 platform:(id)a5;
- (void)simulateScenarioTrigger:(id)a0 handler:(id /* block */)a1;
- (void)onMotionActivityManagerNotification:(id)a0;
- (void)_evaluateSettledState;
- (void)onWiFiFootprintStateNotification:(id)a0;
- (void)_startMonitoringScenarioTriggerOfType:(unsigned long long)a0;
- (void)_stopMonitoringScenarioTriggerOfType:(unsigned long long)a0;
- (unsigned long long)_notificationNameToScenarioTriggerType:(id)a0;
- (void)_checkForFirstTimeInCityWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForFirstTimeInNeighborhoodWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForFirstTimeAtLocationWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForLastTimeAtLocationWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForAtFamiliarLocationWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForArrivedEarlyWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForStayedLateWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForHeadedToHomeWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_checkForHeadedToWorkWithVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_handleVisitIncident:(id)a0 atLocationOfInterest:(id)a1;
- (void)_handleVisit:(id)a0;
- (void)_onMotionActivityManagerNotification:(id)a0;
- (void)_onWiFiFootprintStateNotification:(id)a0;
- (void)_postScenarioTriggerNotification:(id)a0;
- (void)postScenarioTriggerNotification:(id)a0;
- (void)onPostScenarioTriggerNotificationFromDefaults;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
