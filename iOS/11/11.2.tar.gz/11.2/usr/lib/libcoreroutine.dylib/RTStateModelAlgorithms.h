@interface RTStateModelAlgorithms : NSObject

+ (id)bucketizeDates:(id)a0 bucketInterval:(double)a1 latestDate:(id)a2;

@end
