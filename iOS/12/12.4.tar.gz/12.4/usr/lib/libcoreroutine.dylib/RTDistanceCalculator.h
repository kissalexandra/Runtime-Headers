@class RTLocationShifter;

@interface RTDistanceCalculator : RTService

@property (retain, nonatomic) RTLocationShifter *locationShifter;

- (double)distanceFromLocation:(id)a0 toLocation:(id)a1 error:(id *)a2;
- (void).cxx_destruct;

@end
