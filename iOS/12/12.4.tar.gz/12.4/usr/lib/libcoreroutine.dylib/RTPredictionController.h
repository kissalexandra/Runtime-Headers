@class RTMetricManager, RTPersistenceManager, RTAuthorizationManager, RTLocationTagger, RTPredictionTableController, NSDate, NSDictionary, RTInvocationDispatcher, RTDefaultsManager, NSMutableArray, RTDataProtectionManager, NSObject;
@protocol OS_dispatch_queue;

@interface RTPredictionController : NSObject

@property (nonatomic) unsigned long long queueCount;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) NSMutableArray *expertQueues;
@property (retain, nonatomic) NSMutableArray *experts;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTDataProtectionManager *dataProtectionManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTLocationTagger *locationTagger;
@property (retain, nonatomic) RTPredictionTableController *predictionTable;
@property (nonatomic) unsigned long long expertQueueMaxWidth;
@property (retain, nonatomic) NSDictionary *dataProviders;
@property (nonatomic) BOOL ready;
@property (retain, nonatomic) NSDate *dateOfLastSuccessfulProcessing;
@property (retain, nonatomic) NSDate *dateOfLastProcessing;
@property (nonatomic) BOOL unlockedSinceBoot;
@property (nonatomic) long long encryptedDataAvailability;

- (void)_processData:(id /* block */)a0;
- (void)processData:(id /* block */)a0;
- (id)dataProviderForName:(id)a0;
- (id)initWithExperts:(id)a0 dataProviders:(id)a1 defaultsManager:(id)a2 authorizationManager:(id)a3 persistenceManager:(id)a4 dataProtectionManager:(id)a5 metricManager:(id)a6 locationTagger:(id)a7 predictionTable:(id)a8;
- (void)onDataProtectionChange:(id)a0;
- (void)_teardownExpertQueues;
- (void)purgeDataProviders;
- (void)_recursiveInvokeBatchedExpertsAtDate:(id)a0 withHandler:(id /* block */)a1;
- (void)submitMetricWithExpertMetrics:(id)a0;
- (void)submitMetricWithPredictionTable:(id)a0 lastProcessingDate:(id)a1 currentProcessingStartDate:(id)a2;
- (id)_finalizeProcessing;
- (void)_handleUnlockedSinceBootNotification:(BOOL)a0;
- (void)_handleEncryptedDataAvailabilityChange:(long long)a0;
- (void)_refreshDataProvidersWithHandler:(id /* block */)a0;
- (void)_purgeDataProviders;
- (id)_requestExpertQueue;
- (void)_handleErrorWhileProcessingData:(id)a0 handler:(id /* block */)a1;
- (void)_recursiveInvokeBatchedExpertsWithHandler:(id /* block */)a0;
- (void)findUniqueContextsWithKey:(id)a0 dataProvider:(id)a1 expectedClass:(Class)a2 handler:(id /* block */)a3;
- (void)refreshDataProvidersWithHandler:(id /* block */)a0;
- (id)init;
- (void)dealloc;
- (void).cxx_destruct;
- (void)invalidate;

@end
