@class RTKeepAliveTransaction, NSString, CARSessionStatus;

@interface RTStarkManager_CarKit : RTStarkManager <CARSessionObserving> {
    CARSessionStatus *_carSessionStatus;
}

@property (nonatomic) long long connectionState;
@property (nonatomic) BOOL trustedConnectionEstablished;
@property (retain, nonatomic) RTKeepAliveTransaction *dirty;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_shutdown;
- (void)sessionDidConnect:(id)a0;
- (void)sessionDidDisconnect:(id)a0;
- (void)_sessionDidChange:(id)a0;
- (BOOL)updateConnectionState;
- (void)postConnectionStateNotification;
- (void)updateTrustedConnectionEstablished;
- (void)onPairedVehiclesDidChange:(id)a0;
- (void)_fetchConnectionStateWithHandler:(id /* block */)a0;

@end
