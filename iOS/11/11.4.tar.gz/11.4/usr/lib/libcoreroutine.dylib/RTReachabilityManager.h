@interface RTReachabilityManager : RTNotifier

@property (nonatomic) struct __SCNetworkReachability { } *reachabilityRef;
@property (readonly, nonatomic) long long currentReachability;

+ (long long)_processReachabilityChange:(unsigned int)a0;
+ (id)reachabilityToString:(long long)a0;

- (id)init;
- (id)description;
- (void)shutdown;
- (void)setCurrentReachability:(long long)a0;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_startMonitoringReachability;
- (void)_stopMonitoringReachability;
- (void)processReachabilityChange:(unsigned int)a0;
- (id)currentReachabilityString;
- (void)fetchCurrentReachability:(id /* block */)a0;
- (void)_fetchCurrentReachability:(id /* block */)a0;
- (BOOL)_getCurrentReachability:(unsigned int *)a0;

@end
