@class NSMutableDictionary, NSMutableSet, NSMutableArray, NSObject;
@protocol OS_dispatch_queue;

@interface RTLifeCycleManager : NSObject

@property (retain, nonatomic) NSMutableArray *signals;
@property (retain, nonatomic) NSMutableDictionary *transactions;
@property (retain, nonatomic) NSMutableDictionary *listeners;
@property (retain, nonatomic) NSMutableSet *services;
@property (nonatomic) BOOL activeTransaction;
@property (nonatomic) BOOL exitWhenNoTransactions;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;

+ (id)sharedInstance;

- (void)exit;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)_start;
- (void)start;
- (id)keyForObject:(id)a0;
- (id)createSourceForSignal:(int)a0 withBlock:(id /* block */)a1;
- (void)addService:(id)a0;
- (void)incrementTransactionsForObject:(id)a0;
- (void)decrementTransactionsForObject:(id)a0;
- (void)processTransactions;
- (void)exitWithDelay:(double)a0;
- (void)_exit;

@end
