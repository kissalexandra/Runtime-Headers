@class NSUserDefaults, RTNanoRegistry;

@interface RTPlatform_MobileGestalt : RTPlatform {
    NSUserDefaults *_userDefaults;
    RTNanoRegistry *_nanoRegistry;
}

- (id)init;
- (void).cxx_destruct;
- (id)systemVersion;
- (id)productType;
- (id)deviceClass;
- (BOOL)internalInstall;
- (BOOL)supportsMultiUser;
- (BOOL)supportsCoreRoutineCapability;
- (id)userAssignedDeviceName;
- (id)systemModel;
- (BOOL)iPhonePlatform;
- (BOOL)watchPlatform;
- (BOOL)macOSPlatform;
- (BOOL)simulatorPlatform;
- (BOOL)lowEndHardware;
- (BOOL)iPhoneDevice;
- (BOOL)supportsScenarioTriggers;
- (id)initWithNanoRegistry:(id)a0 userDefaults:(id)a1;

@end
