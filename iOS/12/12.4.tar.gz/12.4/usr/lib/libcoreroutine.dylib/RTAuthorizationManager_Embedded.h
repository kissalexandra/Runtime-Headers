@class NSString, CLLocationManager;

@interface RTAuthorizationManager_Embedded : RTAuthorizationManager <CLLocationManagerDelegate> {
    CLLocationManager *_magicalMomentsLocationManager;
    BOOL _magicalMomentsLocationEnabled;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (BOOL)isLocationServicesEnabled;
- (void)locationManager:(id)a0 didChangeAuthorizationStatus:(int)a1;
- (void)_setup;
- (id)initWithMetricManager:(id)a0 platform:(id)a1 userSessionMonitor:(id)a2;
- (void)_fetchMagicalMomentsLocationUsageEnabled:(id /* block */)a0;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)_handleMagicalMomentsLocationAuthChange:(int)a0;
- (void).cxx_destruct;

@end
