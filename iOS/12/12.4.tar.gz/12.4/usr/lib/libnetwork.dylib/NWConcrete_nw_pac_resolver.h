@class NSString, NSObject;
@protocol OS_nw_context;

@interface NWConcrete_nw_pac_resolver : NSObject <OS_nw_pac_resolver> {
    id /* block */ result_block;
    NSObject<OS_nw_context> *context;
    struct __CFURL { } *endpointURL;
    struct __CFURL { } *pacURL;
    struct __CFString { } *pacScript;
    struct __CFData { } *auditToken;
    struct __CFString { } *bundleIdentifier;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void)dealloc;
- (void).cxx_destruct;

@end
