@interface RTPriorityQueue : NSObject {
    struct __CFBinaryHeap { } *_heap;
}

@property (readonly, nonatomic) unsigned long long count;

- (id)peek;
- (id)dequeue;
- (id)init;
- (void)dealloc;
- (id)initWithObjects:(id)a0;
- (void)enqueue:(id)a0;

@end
