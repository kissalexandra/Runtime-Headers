@interface OS_nw_array : OS_object

- (void)_dispose;

@end
