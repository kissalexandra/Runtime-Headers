@interface RTXPC : NSObject

+ (id)checkClientConnection:(id)a0 forEntitlements:(id)a1;
+ (BOOL)xpcConnection:(id)a0 hasEntitlement:(id)a1;
+ (id)signingIdentifierOfConnection:(id)a0;
+ (id)allowInternalFrameworkAccessForConnection:(id)a0;
+ (BOOL)checkClientCodeSigning:(id)a0 error:(id *)a1;
+ (id)executablePathOfConnection:(id)a0;

@end
