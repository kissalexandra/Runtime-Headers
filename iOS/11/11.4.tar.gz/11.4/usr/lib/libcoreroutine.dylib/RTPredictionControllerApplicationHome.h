@interface RTPredictionControllerApplicationHome : RTPredictionControllerApplication

@property (nonatomic) unsigned long long maxMicroLocationsForTraining;
@property (nonatomic) double minMicroLocationConfidenceThreshold;

- (id)init;
- (void)invalidate;
- (void)_unregisterForNotifications;
- (void)_registerForNotifications;
- (void)_setup;
- (id)initWithExperts:(id)a0 dataProviders:(id)a1 defaultsManager:(id)a2 authorizationManager:(id)a3 persistenceManager:(id)a4 dataProtectionManager:(id)a5 metricManager:(id)a6 locationTagger:(id)a7 mediaRemote:(id)a8 predictionTable:(id)a9 applicationManager:(id)a10 dataSource:(id)a11;
- (void)_buildExpertsWithHandler:(id /* block */)a0;
- (void)_updateRegisteredDefaults:(id /* block */)a0;
- (void)updateValueForKey:(id)a0 expectedClass:(Class)a1 handler:(id /* block */)a2;
- (void)onDefaultsUpdate:(id)a0;
- (void)onAuthorizationUpdate:(id)a0;
- (void)__processData:(id /* block */)a0;
- (id)combinePredictions:(id)a0 withFallbackPredictionsForEvent:(id)a1;
- (id)findUniqueMicroLocations:(id)a0 limit:(unsigned long long)a1 minimumProbability:(double)a2;

@end
