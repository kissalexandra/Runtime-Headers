@class RTInvocationDispatcher, RTReachabilityManager, ASAssetQuery, NSDate, RTMetricManager, NSUserDefaults;

@interface RTAssetManager : RTNotifier

@property (nonatomic) long long currentReachability;
@property (retain, nonatomic) NSDate *dateOfLastUpdateAttempt;
@property (retain, nonatomic) NSDate *dateOfLastSuccessfulUpdate;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) NSUserDefaults *userDefaults;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTReachabilityManager *reachabilityManager;
@property (nonatomic) BOOL ready;
@property (retain, nonatomic) ASAssetQuery *assetQuery;

- (id)init;
- (void).cxx_destruct;
- (void)_unregisterForNotifications;
- (void)_registerForNotifications;
- (void)_setup;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)forceUpdateAssetMetadata;
- (id)initWithUserDefaults:(id)a0 metricManager:(id)a1 reachabilityManager:(id)a2;
- (void)_invalidateAssetQuery;
- (void)performUpdateOfAssetsWithTypeAssetType:(id)a0 handler:(id /* block */)a1;
- (void)_performUpdateOfAssetsWithTypeAssetType:(id)a0 handler:(id /* block */)a1;
- (void)_finalizeAssetUpdateOperationWithError:(id)a0;
- (void)_downloadAsset:(id)a0 handler:(id /* block */)a1;
- (void)_installAsset:(id)a0 handler:(id /* block */)a1;
- (void)onReachabilityChange:(id)a0;
- (void)updateAssetServerURL:(id)a0 assetType:(id)a1 handler:(id /* block */)a2;
- (void)_submitAssertVersionMetric;
- (void)_registerForMetricSubmission;
- (void)_submitAssertVersionMetricWithHandler:(id /* block */)a0;

@end
