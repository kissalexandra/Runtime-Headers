@interface nw_listener_inbox_protocol : nw_listener_inbox {
    struct nw_listen_protocol_callbacks { void /* function */ *new_flow; void /* function */ *disconnected; } _listen_callbacks;
    struct nw_listen_protocol { struct nw_listen_protocol_callbacks *callbacks; struct nw_protocol *protocol_handler; void *protocol_handler_context; void *handle; } _listen_protocol;
}

- (id)description;
- (BOOL)cancel;
- (id)initWithProtocol:(struct nw_protocol { unsigned char x0[16]; struct nw_protocol_identifier *x1; struct nw_protocol_callbacks *x2; struct nw_protocol *x3; void *x4; struct nw_protocol *x5; void *x6; } *)a0 delegate:(id)a1;

@end
