@class RTEvent;

@interface RTDataProviderEventNotificationRealtime : RTNotification

@property (readonly, nonatomic) RTEvent *event;

- (id)initWithEvent:(id)a0;
- (void).cxx_destruct;

@end
