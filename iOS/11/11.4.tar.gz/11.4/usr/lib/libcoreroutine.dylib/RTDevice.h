@class NSUUID, NSString;

@interface RTDevice : NSObject

@property (readonly, nonatomic) NSUUID *identifier;
@property (readonly, nonatomic) NSString *deviceName;
@property (readonly, nonatomic) NSString *deviceClass;
@property (readonly, nonatomic) NSString *deviceModel;

- (void).cxx_destruct;
- (id)description;
- (id)initWithDeviceMO:(id)a0;

@end
