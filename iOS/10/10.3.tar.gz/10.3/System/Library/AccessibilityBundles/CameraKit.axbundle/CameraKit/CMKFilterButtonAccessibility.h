@interface CMKFilterButtonAccessibility : __CMKFilterButtonAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityHint;

@end
