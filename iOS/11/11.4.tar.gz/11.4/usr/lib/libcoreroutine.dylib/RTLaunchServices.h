@interface RTLaunchServices : NSObject

+ (void)launchClientWithBundleIdentifier:(id)a0 restorationIdentifier:(id)a1 eventAgentManager:(id)a2 handler:(id /* block */)a3;
+ (BOOL)canOpenApplication:(id)a0;
+ (id)createProcessAssertionForPid:(int)a0;

@end
