@class RTMapServiceManager, NSString, RTFingerprintManager, RTLocationManager, RTMotionActivityManager;

@interface RTMapItemProviderBluePOI : RTMapItemProviderBase <RTMapItemProvider>

@property (retain, nonatomic) RTFingerprintManager *fingerprintManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTMotionActivityManager *motionActivityManager;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (id)mapItemsWithinDistance:(double)a0 location:(id)a1 startDate:(id)a2 endDate:(id)a3 error:(id *)a4;
- (id)initWithDistanceCalculator:(id)a0 fingerprintManager:(id)a1 locationManager:(id)a2 mapServiceManager:(id)a3 motionActivityManager:(id)a4;
- (id)fingerprintsBetweenStartDate:(id)a0 endDate:(id)a1 error:(id *)a2;
- (id)accessPointsForFingerprint:(id)a0 error:(id *)a1;
- (id)locationsForAccessPoints:(id)a0 error:(id *)a1;
- (id)locationsFrom:(id)a0 to:(id)a1 error:(id *)a2;
- (id)motionActivitesFrom:(id)a0 to:(id)a1 error:(id *)a2;
- (id)mapItemsFromLocations:(id)a0 accessPoints:(id)a1 error:(id *)a2;
- (id)filterByDistance:(id)a0 location:(id)a1 thresholdForUnknownLabel:(double)a2 error:(id *)a3;
- (id)poiHarvestForFingerprint:(id)a0 mapItem:(id)a1 referenceLocation:(id)a2 error:(id *)a3;
- (BOOL)submitHarvest:(id)a0 error:(id *)a1;
- (BOOL)harvestVisits:(id)a0 mapItem:(id)a1 error:(id *)a2;

@end
