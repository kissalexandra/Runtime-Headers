@interface MFAutocompleteResultsTableViewControllerAccessibility : __MFAutocompleteResultsTableViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_selectSearchResultsRecipientAtIndexPath:(id)a0;

@end
