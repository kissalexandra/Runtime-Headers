@interface UIKeyboardPredictionView_TFExtras : __UIKeyboardPredictionView_TFExtras_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0;
- (void)layoutSubviews;
- (void)speakTypingLoadAccessibilityInformation;
- (BOOL)accessibilityLongPressGestureRecognizerEnabled;
- (void)_handleAXLongPress:(id)a0;
- (void)setAccessibilityLongPressGestureRecognizerEnabled:(BOOL)a0;
- (void)setAccessibilityCurrentIndex:(long long)a0;
- (long long)accessibilityCurrentIndex;
- (void)_speakLabelAtCell:(id)a0 forCurrentInputMode:(id)a1;

@end
