@class NSString, NSObject;
@protocol OS_dispatch_data, OS_nw_interface;

@interface NWConcrete_nw_browse_descriptor : NSObject <OS_nw_browse_descriptor> {
    int type;
    char *bonjour_type;
    char *bonjour_domain;
    NSObject<OS_dispatch_data> *custom_data;
    id /* block */ browse_block;
    NSObject<OS_nw_interface> *interface;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
