@class NSString;

@interface AXMemoriesSlider : UIAccessibilityElement

@property (nonatomic) long long sliderType;
@property (retain, nonatomic) NSString *selectedDescription;

- (void).cxx_destruct;
- (struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })accessibilityFrame;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (unsigned long long)accessibilityTraits;
- (void)accessibilityIncrement;
- (void)accessibilityDecrement;
- (id)_accessibilityUserTestingElementBaseType;
- (id)_axContainingCollectionView;
- (long long)_axContainingSelectedItem;

@end
