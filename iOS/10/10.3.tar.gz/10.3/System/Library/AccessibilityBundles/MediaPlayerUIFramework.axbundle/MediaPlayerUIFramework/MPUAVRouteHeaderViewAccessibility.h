@interface MPUAVRouteHeaderViewAccessibility : __MPUAVRouteHeaderViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityHint;
- (BOOL)isAccessibilityElement;
- (void)setActivated:(BOOL)a0 animated:(BOOL)a1;

@end
