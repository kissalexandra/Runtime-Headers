@class NSDateComponents;

@interface RTPredictionExpertFeatureAddonTimeOfDay : RTPredictionExpertFeatureAddon

@property (readonly, nonatomic) NSDateComponents *startDateComponents;
@property (readonly, nonatomic) NSDateComponents *endDateComponents;

+ (id)timeOfDayFeatureAddonsWithRequestedDuration:(double)a0 offsetFromMidnight:(double)a1;

- (void).cxx_destruct;
- (id)description;
- (long long)addonType;
- (id)initWithStartDateComponents:(id)a0 endDateComponents:(id)a1;

@end
