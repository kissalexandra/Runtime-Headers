@class NSString;

@interface NWConcrete_nw_interface : NSObject <OS_nw_interface> {
    unsigned long long update_time;
    unsigned int index;
    struct nw_interface_details { struct nw_interface_signature { unsigned char signature[20]; unsigned char signature_len; unsigned char __pad[3]; } ipv4_signature; struct nw_interface_signature { unsigned char signature[20]; unsigned char signature_len; unsigned char __pad[3]; } ipv6_signature; int is_active; int mtu; unsigned char expensive : 1; unsigned char tx_start : 1; unsigned char ack_priority : 1; unsigned char carrier_aggregation : 1; unsigned char __pad_bits : 4; unsigned char __pad[3]; } details;
    unsigned int delegate_index;
    unsigned int generation;
    int type;
    int subtype;
    char name[25];
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void)dealloc;

@end
