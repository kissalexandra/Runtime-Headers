@class NSArray, RTLearnedPlace, RTLearnedPlaceTypeInferenceStats;

@interface RTLearnedPlaceTypeInferencePlaceStats : NSObject

@property (readonly, nonatomic) RTLearnedPlace *place;
@property (readonly, nonatomic) NSArray *visits;
@property (readonly, nonatomic) RTLearnedPlaceTypeInferenceStats *stats;

+ (double)extractTopMedianDwellTimeFromVisits:(id)a0;
+ (id)extractWeeklyStatsFromDailyStats:(id)a0;
+ (id)extractDailyStatsFromVisits:(id)a0;
+ (id)visitsWithDwellTimeBetweenDateRange:(id)a0 start:(id)a1 end:(id)a2;

- (void).cxx_destruct;
- (id)description;
- (void)log;
- (id)initWithPlace:(id)a0 visits:(id)a1;

@end
