@class NSObject, NSString, RTPersonalizationPortraitManager, RTMapServiceManager;
@protocol OS_dispatch_queue;

@interface RTMapItemProviderPortrait : NSObject <RTMapItemProvider>

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (retain, nonatomic) RTPersonalizationPortraitManager *personalizationPortraitManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (id)mapItemsWithinDistance:(double)a0 location:(id)a1 startDate:(id)a2 endDate:(id)a3 error:(id *)a4;
- (id)initWithMapServiceManager:(id)a0 personalizationPortraitManager:(id)a1;
- (id)_mapItemsForLocation:(id)a0 withNames:(id)a1 error:(id *)a2;

@end
