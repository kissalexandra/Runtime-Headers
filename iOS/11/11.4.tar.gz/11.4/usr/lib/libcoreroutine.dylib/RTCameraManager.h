@interface RTCameraManager : RTNotifier

+ (id)allocWithZone:(struct _NSZone { } *)a0;

@end
