@class RTInvocationDispatcher, RTDefaultsManager, ASAssetQuery, RTXPCActivityManager, NSDate, RTMetricManager;

@interface RTAssetManager : RTService

@property (retain, nonatomic) NSDate *dateOfLastUpdateAttempt;
@property (retain, nonatomic) NSDate *dateOfLastSuccessfulUpdate;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTXPCActivityManager *xpcActivityManager;
@property (nonatomic) BOOL ready;
@property (retain, nonatomic) ASAssetQuery *assetQuery;

- (void)_setup;
- (void)shutdown;
- (id)initWithDefaultsManager:(id)a0 metricManager:(id)a1 xpcActivityManager:(id)a2;
- (void)_finalizeAssetUpdateOperationWithError:(id)a0;
- (void)performUpdateOfAssetsWithTypeAssetType:(id)a0 handler:(id /* block */)a1;
- (void)_registerForMetricSubmission;
- (void)_submitAssertVersionMetric;
- (void)_invalidateAssetQuery;
- (void)_performUpdateOfAssetsWithTypeAssetType:(id)a0 handler:(id /* block */)a1;
- (void)_downloadAsset:(id)a0 handler:(id /* block */)a1;
- (void)_installAsset:(id)a0 handler:(id /* block */)a1;
- (void)forceUpdateAssetMetadata;
- (void)updateAssetServerURL:(id)a0 assetType:(id)a1 handler:(id /* block */)a2;
- (void)_submitAssertVersionMetricWithHandler:(id /* block */)a0;
- (id)init;
- (void).cxx_destruct;

@end
