@class RTDataProtectionManager, NSDate, NSObject, RTNextPredictedLocationsOfInterestCache, RTMapServiceManager, RTDefaultsManager, NSMutableArray, RTPlatform, RTMapsSupportManager, RTMetricManager, RTVehicleLocationProvider, RTEventManager, NSString, RTLearnedLocationManager, NSArray, RTLocationManager;
@protocol OS_dispatch_source;

@interface RTDeviceLocationPredictor : RTService <RTNextPredictedLocationsOfInterestCacheDelegate, RTPurgable>

@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (retain, nonatomic) RTMapsSupportManager *mapsSupportManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTDataProtectionManager *dataProtectionManager;
@property (nonatomic) long long encryptedDataAvailability;
@property (retain, nonatomic) RTNextPredictedLocationsOfInterestCache *nextPredictedLocationsOfInterestCache;
@property (nonatomic) BOOL encryptedDataAvailabilityNotificationNeeded;
@property (nonatomic) BOOL monitorNextPredictedLocationsOfInterest;
@property (retain, nonatomic) NSDate *lastNextPredictedLocationsOfInterestDate;
@property (nonatomic) BOOL pendingNextPredictedLocationsOfInterestRequest;
@property (retain, nonatomic) NSObject<OS_dispatch_source> *nextPredictedLocationsOfInterestPollLocationTimer;
@property (retain, nonatomic) NSArray *nextPredictedLocationsOfInterest;
@property (nonatomic) double nextPredictedLocationsOfInterestProcessInterval;
@property (nonatomic) double nextPredictedLocationsOfInterestPollLocationInterval;
@property (retain, nonatomic) NSMutableArray *evalPredictedLocationsOfInterest;
@property (retain, nonatomic) NSMutableArray *evalPredictedExitDates;
@property (retain, nonatomic) RTEventManager *eventManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTVehicleLocationProvider *vehicleLocationProvider;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)fetchPredictedLocationsOfInterestOnDate:(id)a0 withHandler:(id /* block */)a1;
- (void)_unregisterForNotifications;
- (void)_setup;
- (void)_registerForNotifications;
- (void)_purge;
- (void)_shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)fetchNextPredictedLocationsOfInterestFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 withHandler:(id /* block */)a3;
- (void)fetchPredictedExitDatesFromLocation:(id)a0 onDate:(id)a1 withHandler:(id /* block */)a2;
- (void)fetchPredictedLocationsOfInterestBetweenStartDate:(id)a0 endDate:(id)a1 withHandler:(id /* block */)a2;
- (id)initWithDataProtectionManager:(id)a0 defaultsManager:(id)a1 eventManager:(id)a2 learnedLocationManager:(id)a3 locationManager:(id)a4 mapServiceManager:(id)a5 mapsSupportManager:(id)a6 metricManager:(id)a7 nextPredictedLocationsOfInterestCache:(id)a8 platfrom:(id)a9 vehicleLocationProvider:(id)a10 queue:(id)a11;
- (void)purgeManager:(id)a0 performPurgeOfType:(long long)a1 completion:(id /* block */)a2;
- (void)onLearnedLocationManagerNotification:(id)a0;
- (void)onLocationNotification:(id)a0;
- (void)_fetchNextPredictedLocationsOfInterestFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 withHandler:(id /* block */)a3;
- (void)_setupNextPredictedLocationOfInterestPollTimer;
- (void)_setupEvalMode;
- (void)_clear;
- (void)_onLocations:(id)a0;
- (void)shouldMonitorNextPredictedLocationsOfInterest;
- (void)onDataProtectionNotification:(id)a0;
- (void)updateEncryptedDataAvailabilityNotificationNeeded;
- (void)_fetchPredictedExitDatesFromLocation:(id)a0 onDate:(id)a1 withHandler:(id /* block */)a2;
- (void)_fetchPredictedLocationsOfInterestBetweenStartDate:(id)a0 endDate:(id)a1 withHandler:(id /* block */)a2;
- (void)_updateNextPredictedLocationsOfInterestWithLocations:(id)a0;
- (void)_postNextPredictedLocationsOfInterest:(id)a0;
- (void)_updateEvalMode;
- (void)_onLearnedLocationManagerNotification:(id)a0;
- (void)onCacheEnabledDidChange:(BOOL)a0;
- (void)logStateModelAvailabilityMetricWithAvailability:(long long)a0;
- (id)init;
- (void).cxx_destruct;
- (void)clear;
- (void)purge;

@end
