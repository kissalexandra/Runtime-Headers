@interface __MKOfficialAppViewAccessibility_super : UIAccessibilitySafeCategory

@end
