@interface MiroVideoScrubberContainerViewControllerAccessibility : __MiroVideoScrubberContainerViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_accessibilityLoadAccessibilityInformation;
- (id)timeLabelBackground;

@end
