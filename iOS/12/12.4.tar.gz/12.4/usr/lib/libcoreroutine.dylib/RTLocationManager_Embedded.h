@class NSString;

@interface RTLocationManager_Embedded : RTLocationManager <_CLMicroLocationDelegate>

@property (nonatomic) BOOL monitoringMicroLocations;
@property (nonatomic) BOOL monitoringPredictedApplications;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)_shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)shouldMonitorMicroLocations;
- (void)shouldMonitorPredictedApplications;
- (void)locationManager:(id)a0 didUpdateMicroLocations:(id)a1;
- (void)_startUpdatingMicroLocationForLocationOfInterestWithIdentifier:(id)a0;
- (void)_stopUpdatingMicroLocation;
- (void)_requestCurrentMicroLocation;
- (void)_fetchPredictedApplicationsAtLocation:(id)a0 handler:(id /* block */)a1;
- (void)locationManager:(id)a0 didUpdatePredictedApplications:(id)a1;

@end
