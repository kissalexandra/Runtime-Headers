@class PHFetchResult, NSString, PHPhotoLibrary, NSObject, NSDate;
@protocol OS_dispatch_queue;

@interface RTPhotoLibraryManagerDelegate_Camera : NSObject <PHPhotoLibraryChangeObserver, RTPhotoLibraryManagerDelegate>

@property (weak, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (readonly, nonatomic) PHPhotoLibrary *photoLibrary;
@property (readonly, nonatomic) id /* block */ notifierBlock;
@property (retain, nonatomic) PHFetchResult *fetchedAssets;
@property (retain, nonatomic) NSDate *dateOfLastLibraryProcessing;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)photoLibraryDidChange:(id)a0;
- (void)connectToPhotoLibraryOnQueue:(id)a0;
- (void)disconnectFromPhotoLibrary;
- (id)initWithPhotoLibrary:(id)a0 notifierBlock:(id /* block */)a1;
- (id)_fetchAllAssetsSinceDate:(id)a0;
- (void)_refreshAssetsSinceDate:(id)a0;
- (void)_processPhotoLibraryChanges:(id)a0;
- (void)_processIncrementalPhotoLibraryChanges:(id)a0 since:(id)a1;
- (void)_reprocessWholePhotoLibrarySince:(id)a0;
- (void)_processAsset:(id)a0 since:(id)a1;

@end
