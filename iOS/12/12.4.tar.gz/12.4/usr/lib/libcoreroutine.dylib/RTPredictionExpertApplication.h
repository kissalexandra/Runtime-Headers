@class RTDefaultsManager, RTMediaRemote, NSPredicate, RTPredictionExpertApplicationDataSource;

@interface RTPredictionExpertApplication : RTPredictionExpert

@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTMediaRemote *mediaRemote;
@property (nonatomic) double maxEventAge;
@property (nonatomic) double deresolution;
@property (retain, nonatomic) NSPredicate *appLaunchFilterPredicate;
@property (retain, nonatomic) NSPredicate *nowPlayingFilterPredicate;
@property (readonly, nonatomic) RTPredictionExpertApplicationDataSource *dataSource;

- (void)processData:(id /* block */)a0;
- (id)initWithQueue:(id)a0 category:(long long)a1 dataSource:(id)a2 defaultsManager:(id)a3 mediaRemote:(id)a4 featureAddons:(id)a5;
- (void)_fetchEventsFromDataProvider:(id)a0 predicate:(id)a1 sortDescriptors:(id)a2 handler:(id /* block */)a3;
- (id)_createEventStoreWithClasses:(id)a0;
- (void)_processFilteredEvents:(id)a0 appLaunchEvents:(id)a1 histogram:(id)a2 filterOnAppLaunchDate:(BOOL)a3 filterOnEventDate:(BOOL)a4 handler:(id /* block */)a5;
- (id)supportedEventClasses;
- (void)_processEventsWithAppLaunchEvents:(id)a0 handler:(id /* block */)a1;
- (id)dateIntervalForAppLaunchEvent:(id)a0;
- (void)createExpertMetricWithHandler:(id /* block */)a0;
- (id)dateIntervalForEvent:(id)a0;
- (id)globalAppLaunchCountedSetFrom:(id)a0;
- (id)initWithQueue:(id)a0 category:(long long)a1 dataSource:(id)a2;
- (id)_createExpertMetric;
- (void).cxx_destruct;

@end
