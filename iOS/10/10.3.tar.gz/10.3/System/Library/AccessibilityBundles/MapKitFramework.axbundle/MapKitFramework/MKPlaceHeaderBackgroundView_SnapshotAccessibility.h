@interface MKPlaceHeaderBackgroundView_SnapshotAccessibility : __MKPlaceHeaderBackgroundView_SnapshotAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0 mapItem:(id)a1;
- (void)_axAnnotateMapView;
- (void)_accessibilityLoadAccessibilityInformation;

@end
