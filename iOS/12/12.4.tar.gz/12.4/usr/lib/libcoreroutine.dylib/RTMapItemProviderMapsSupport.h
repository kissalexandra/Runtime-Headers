@class NSString, RTMapsSupportManager;

@interface RTMapItemProviderMapsSupport : RTMapItemProviderBase <RTMapItemProvider>

@property (retain, nonatomic) RTMapsSupportManager *mapsSupportManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)mapItemsWithinDistance:(double)a0 location:(id)a1 startDate:(id)a2 endDate:(id)a3 error:(id *)a4;
- (id)initWithDistanceCalculator:(id)a0 mapsSupportManager:(id)a1;
- (double)confidenceFromMapItemSource:(unsigned long long)a0;
- (id)init;
- (void).cxx_destruct;

@end
