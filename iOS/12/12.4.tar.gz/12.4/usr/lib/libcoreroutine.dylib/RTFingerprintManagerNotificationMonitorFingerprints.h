@interface RTFingerprintManagerNotificationMonitorFingerprints : RTNotification

@end
