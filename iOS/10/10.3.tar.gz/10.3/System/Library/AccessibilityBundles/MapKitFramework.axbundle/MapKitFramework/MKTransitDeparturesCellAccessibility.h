@interface MKTransitDeparturesCellAccessibility : __MKTransitDeparturesCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)_axIsCountdownCell;
- (BOOL)_accessibilityIsInActivate;
- (void)_accessibilitySetIsInActivate:(BOOL)a0;
- (id)tableTextAccessibleLabel:(id)a0;

@end
