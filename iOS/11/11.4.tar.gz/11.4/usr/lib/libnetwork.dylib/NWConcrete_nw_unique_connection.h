@class NSString, NWConcrete_nw_connection, NSObject;
@protocol OS_nw_endpoint;

@interface NWConcrete_nw_unique_connection : NSObject <OS_nw_unique_connection> {
    NSObject<OS_nw_endpoint> *endpoint;
    char service[430];
    unsigned long long sequenceNumber;
    unsigned char uuid[16];
    NWConcrete_nw_connection *connection;
    BOOL isIncoming;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
