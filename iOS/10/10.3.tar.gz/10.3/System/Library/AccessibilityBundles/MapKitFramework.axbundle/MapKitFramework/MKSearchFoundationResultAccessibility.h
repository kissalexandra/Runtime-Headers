@interface MKSearchFoundationResultAccessibility : __MKSearchFoundationResultAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithMapItem:(id)a0 iconSize:(unsigned long long)a1 currentLocation:(id)a2;

@end
