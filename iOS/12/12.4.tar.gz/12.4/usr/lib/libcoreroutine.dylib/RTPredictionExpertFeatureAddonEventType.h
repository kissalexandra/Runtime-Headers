@class NSArray;

@interface RTPredictionExpertFeatureAddonEventType : RTPredictionExpertFeatureAddon

@property (readonly, nonatomic) NSArray *eventClasses;

- (id)initWithEventClasses:(id)a0;
- (long long)addonType;
- (void).cxx_destruct;
- (id)description;

@end
