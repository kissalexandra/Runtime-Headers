@class NSArray, NSMutableDictionary;

@interface RTWiFiManager_MobileWiFi : RTWiFiManager

@property (nonatomic) struct __WiFiManagerClient { } *wifiManager;
@property (retain, nonatomic) NSArray *devices;
@property (retain, nonatomic) NSMutableDictionary *accessPointForInterface;

+ (id)defaultScanRequest;
+ (id)scanRequestWithType:(long long)a0 dwellTime:(long long)a1 channels:(id)a2 lowPriority:(BOOL)a3;

- (void).cxx_destruct;
- (void)_setup;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_shutdown;
- (void)_scheduleScan;
- (void)_cancelScan;
- (void)_establishConnectionToWiFiManager;
- (void)_destroyConnectionToWiFiManager;
- (void)_setRegisteredForExtendedLinkCallbacks:(BOOL)a0;
- (void)_setRegisteredForPowerCallbacks:(BOOL)a0;
- (void)_setRegisteredForScanUpdateCallbacks:(BOOL)a0;
- (void)handleWiFiDeviceClientPowerCallback:(struct __WiFiDeviceClient { } *)a0;
- (void)_handleWiFiDeviceClientPowerCallback:(struct __WiFiDeviceClient { } *)a0;
- (void)_pollManagerPowerStatus;
- (void)handleWiFiDeviceClientExtendedLinkCallback:(struct __WiFiDeviceClient { } *)a0 eventData:(id)a1;
- (void)_handleWiFiDeviceClientExtendedLinkCallback:(struct __WiFiDeviceClient { } *)a0 eventData:(id)a1;
- (void)_pollAccessPoints;
- (void)handleWiFiDeviceClientScanUpdateCallback:(struct __WiFiDeviceClient { } *)a0 scanRequest:(id)a1 scanResults:(id)a2 error:(int)a3;
- (void)handleWiFiDeviceClientScanCallback:(struct __WiFiDeviceClient { } *)a0 scanResults:(id)a1 error:(int)a2;
- (void)_handleScanResultsCallback:(id)a0 error:(int)a1;

@end
