@interface RTManagedConfiguration_Embedded : RTManagedConfiguration

- (void)setDelegate:(id)a0;
- (void)dealloc;
- (BOOL)effectiveBoolValueForSetting:(id)a0;
- (void)profileConnectionDidReceiveEffectiveSettingsChangedNotification:(id)a0 userInfo:(id)a1;
- (BOOL)isDiagnosticsAndUsageAllowed;
- (BOOL)isFindMyCarAllowed;
- (id)stringToManagedConfigurationKey:(id)a0;

@end
