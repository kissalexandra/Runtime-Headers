@interface CAMBurstIndicatorViewAccessibility : __CAMBurstIndicatorViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_updateCountLabelWithNumberOfPhotos;

@end
