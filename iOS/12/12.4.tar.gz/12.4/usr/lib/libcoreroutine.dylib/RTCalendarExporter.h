@class NSString, NSArray, NSData, GEOMapService;

@interface RTCalendarExporter : NSObject {
    GEOMapService *_mapService;
}

@property (nonatomic) BOOL compress;
@property (copy, nonatomic) NSString *calendarName;
@property (copy, nonatomic) NSString *calendarColor;
@property (copy, nonatomic) NSArray *locationsOfInterest;
@property (readonly) NSData *data;

- (BOOL)writeToURL:(id)a0 error:(id *)a1;
- (id)initWithMapService:(id)a0;
- (id)init;
- (void).cxx_destruct;
- (id)calendar;
- (id)components;
- (id)document;

@end
