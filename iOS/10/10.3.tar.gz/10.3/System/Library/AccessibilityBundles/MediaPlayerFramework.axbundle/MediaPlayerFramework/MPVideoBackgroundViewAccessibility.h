@interface MPVideoBackgroundViewAccessibility : __MPVideoBackgroundViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (BOOL)isAccessibilityElement;
- (BOOL)accessibilityElementsHidden;

@end
