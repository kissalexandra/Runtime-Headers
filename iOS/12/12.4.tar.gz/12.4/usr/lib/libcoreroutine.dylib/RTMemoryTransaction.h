@class NSObject;
@protocol OS_os_transaction;

@interface RTMemoryTransaction : RTTransaction

@property (retain, nonatomic) NSObject<OS_os_transaction> *transaction;

- (id)initForObject:(id)a0 description:(id)a1;
- (void)dealloc;
- (void).cxx_destruct;

@end
