@class NSDictionary, NSObject;
@protocol OS_dispatch_queue;

@interface RTPredictionExpertDataSource : NSObject

@property (readonly, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (readonly, nonatomic) NSDictionary *dataProviders;

- (void).cxx_destruct;
- (void)reset;
- (id)dataProviderForName:(id)a0;
- (void)prefetch:(id /* block */)a0;
- (id)initWithDataProviders:(id)a0;

@end
