@class NSString;

@interface RTPredictionItemApplicationMO : RTPredictionItemMO

@property (retain, nonatomic) NSString *bundleId;

+ (id)managedObjectWithBundleId:(id)a0 confidence:(id)a1 inManagedObjectContext:(id)a2;

@end
