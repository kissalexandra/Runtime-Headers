@class MSPHistoryContainer, MSPFavoritesContainer, NSObject;
@protocol OS_dispatch_queue;

@interface RTMapsSupportManager : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) MSPFavoritesContainer *favoritesContainer;
@property (retain, nonatomic) MSPHistoryContainer *historyContainer;

+ (id)locationFromHistoryEntry:(id)a0;
+ (id)locationFromFavorite:(id)a0;
+ (id)mapItemFromHistoryEntry:(id)a0;
+ (id)mapItemFromFavorite:(id)a0;

- (id)init;
- (void).cxx_destruct;
- (void)fetchNextPredictedLocationsOfInterestFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 withHandler:(id /* block */)a3;
- (id)_getNextPredictedLocationsOfInterestBackedByFavoritePlaceFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 favorites:(id)a3;
- (id)_getNextPredictedLocationsOfInterestBackedByHistortyEntryRouteFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 historyEntries:(id)a3;
- (id)_getNextPredictedLocationsOfInterestBackedByHistortyEntryPlaceDisplayFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 historyEntries:(id)a3;
- (void)_fetchFavoritesWithHandler:(id /* block */)a0;
- (void)fetchFavoritesWithHandler:(id /* block */)a0;
- (void)_fetchFavoritePlacesWithHandler:(id /* block */)a0;
- (void)_fetchHistoryEntriesWithHandler:(id /* block */)a0;
- (void)fetchHistoryEntriesWithHandler:(id /* block */)a0;
- (void)showTrafficConditionsBulletinWithTitle:(id)a0 message:(id)a1 actionURL:(id)a2;
- (void)clearTrafficConditionsBulletin;
- (void)showParkedCarBulletinForEvent:(id)a0;
- (void)showParkedCarReplacementBulletinForEvent:(id)a0 replacingEvent:(id)a1;
- (void)clearParkedCarBulletin;
- (void)_fetchFavoritePlaceMapItemsWithHandler:(id /* block */)a0;
- (void)fetchFavoritePlaceMapItemsWithHandler:(id /* block */)a0;
- (void)_fetchHistoryEntryRouteMapItemsWithHandler:(id /* block */)a0;
- (void)fetchHistoryEntryRouteMapItemsWithHandler:(id /* block */)a0;
- (void)_fetchHistoryEntryPlaceDisplayMapItemsWithHandler:(id /* block */)a0;
- (void)fetchHistoryEntryPlaceDisplayMapItemsWithHandler:(id /* block */)a0;
- (void)fetchFavoritePlacesWithHandler:(id /* block */)a0;
- (void)fetchHistoryEntryPlaceDisplaysWithHandler:(id /* block */)a0;
- (void)fetchHistoryEntryRoutesWithHandler:(id /* block */)a0;

@end
