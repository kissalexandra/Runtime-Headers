@interface RTSystemControl : NSObject

+ (id)valueForMib:(int *)a0 miblen:(int)a1;
+ (unsigned long long)sysctlByName:(id)a0;
+ (id)valueForKey:(id)a0;

@end
