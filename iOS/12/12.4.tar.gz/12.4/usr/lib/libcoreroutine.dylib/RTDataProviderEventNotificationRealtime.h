@class RTEvent;

@interface RTDataProviderEventNotificationRealtime : RTNotification

@property (readonly, nonatomic) RTEvent *event;

- (void).cxx_destruct;
- (id)initWithEvent:(id)a0;

@end
