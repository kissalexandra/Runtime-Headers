@interface RTPredictionItem : NSObject <NSCopying>

@property (readonly, nonatomic) double confidence;

- (id)init;
- (id)copyWithZone:(struct _NSZone { } *)a0;
- (id)initWithConfidence:(double)a0;

@end
