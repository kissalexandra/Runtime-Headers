@class NSArray;

@interface RTLearnedPlaceTypeInferenceWeeklyStats : NSObject

@property (readonly, nonatomic) NSArray *dailyStats;
@property (readonly, nonatomic) double dailyAggregateDwellTimeBetweenDateRangeAverage;
@property (readonly, nonatomic) double dailyAggregateDwellTimeBetweenDateRangeStandardDeviation;
@property (readonly, nonatomic) long long totalDailyVisitCount;
@property (readonly, nonatomic) long long daysWithNonZeroDwellTime;

- (void).cxx_destruct;
- (id)description;
- (id)initWithDailyStats:(id)a0;

@end
