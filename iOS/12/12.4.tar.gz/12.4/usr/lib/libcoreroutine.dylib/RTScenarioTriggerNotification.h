@class RTScenarioTrigger;

@interface RTScenarioTriggerNotification : RTNotification

@property (readonly, nonatomic) RTScenarioTrigger *scenarioTrigger;

- (id)initWithScenarioTrigger:(id)a0;
- (void).cxx_destruct;

@end
