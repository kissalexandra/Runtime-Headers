@interface TZXPCConstants : NSObject

@end
