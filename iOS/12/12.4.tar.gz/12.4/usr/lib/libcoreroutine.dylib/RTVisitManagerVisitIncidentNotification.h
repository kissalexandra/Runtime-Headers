@class RTVisit;

@interface RTVisitManagerVisitIncidentNotification : RTNotification

@property (readonly, nonatomic) RTVisit *visitIncident;

- (id)initWithVisitIncident:(id)a0;
- (id)init;
- (void).cxx_destruct;

@end
