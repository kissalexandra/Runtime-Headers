@class RTLocationOfInterest;

@interface RTEventLocationVisit : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly, nonatomic) RTLocationOfInterest *locationOfInterest;

- (id)initWithLocationOfInterest:(id)a0 source:(long long)a1;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (id)description;

@end
