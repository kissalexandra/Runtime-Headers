@class NSString;

@interface BKCatacomb : NSObject {
    NSString *_catacombDir;
}

+ (id)catacombWithDir:(id)a0 withSerial:(id)a1;

- (int)deleteFile:(id)a0;
- (int)deleteAll;
- (int)recover;
- (int)writeData:(id)a0 toFile:(id)a1;
- (id)catacombCommitDir;
- (id)catacombPrepareDir;
- (int)syncDir:(id)a0;
- (int)commitWrite;
- (int)readData:(id *)a0 fromFile:(id)a1;
- (id)init;
- (id)content;

@end
