@interface MiroIOSPlayerViewControllerAccessibility : __MiroIOSPlayerViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_accessibilityLoadAccessibilityInformation;
- (void)setControlVisibility:(BOOL)a0;
- (void)_setupBottomToolbar;
- (void)_addToggleControlsGestureRecognizer;
- (void)toggleControlVisibility:(id)a0;
- (void)hideProgressScreen;
- (id)editBBItem;
- (void)_axReloadFocus;

@end
