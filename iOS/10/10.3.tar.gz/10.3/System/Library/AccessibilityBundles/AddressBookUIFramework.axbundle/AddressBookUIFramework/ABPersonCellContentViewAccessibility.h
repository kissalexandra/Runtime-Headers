@interface ABPersonCellContentViewAccessibility : __ABPersonCellContentViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)setLabelText:(id)a0;
- (void)_accessibilityLoadAccessibilityInformation;

@end
