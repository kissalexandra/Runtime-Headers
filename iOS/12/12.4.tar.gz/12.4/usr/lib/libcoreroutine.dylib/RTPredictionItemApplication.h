@class NSString;

@interface RTPredictionItemApplication : RTPredictionItem <NSCopying>

@property (readonly, copy, nonatomic) NSString *bundleId;

- (id)initWithConfidence:(double)a0 bundleId:(id)a1;
- (id)init;
- (void).cxx_destruct;
- (id)copyWithZone:(struct _NSZone { } *)a0;

@end
