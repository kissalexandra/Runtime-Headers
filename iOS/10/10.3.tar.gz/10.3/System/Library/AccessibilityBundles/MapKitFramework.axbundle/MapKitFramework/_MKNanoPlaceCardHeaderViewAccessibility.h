@interface _MKNanoPlaceCardHeaderViewAccessibility : ___MKNanoPlaceCardHeaderViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityElements;
- (void)setMapItem:(id)a0;
- (void)_accessibilityUpdateCategoryAXLabel;
- (void)_accessibilityLoadAccessibilityInformation;

@end
