@interface __CMKTimerButtonAccessibility_super : UIAccessibilitySafeCategory

@end
