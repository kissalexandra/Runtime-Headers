@interface ABMultiCellContentViewAccessibility : __ABMultiCellContentViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)badgeIconWhenEditing:(BOOL)a0;

@end
