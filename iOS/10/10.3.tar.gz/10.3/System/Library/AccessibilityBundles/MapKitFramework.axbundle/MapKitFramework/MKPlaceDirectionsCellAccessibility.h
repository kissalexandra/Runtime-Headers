@interface MKPlaceDirectionsCellAccessibility : __MKPlaceDirectionsCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)updateETAFor:(unsigned long long)a0 button:(id)a1 label:(id)a2;
- (id)_axSpokenStringForDuration:(double)a0;
- (void)_axUpdateElements;
- (BOOL)_accessibilityHitTestShouldFallbackToNearestChild;

@end
