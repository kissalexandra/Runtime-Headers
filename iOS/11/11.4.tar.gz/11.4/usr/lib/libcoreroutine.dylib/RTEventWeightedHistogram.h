@class NSString, NSMutableDictionary;

@interface RTEventWeightedHistogram : RTEventHistogramBase <RTEventHistogram>

@property (retain, nonatomic) NSMutableDictionary *weightedEventModel;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (BOOL)supportsSecureCoding;

- (id)init;
- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (void)clear;
- (void)addEvent:(id)a0;
- (void)addEventId:(id)a0;
- (void)addEvent:(id)a0 weight:(double)a1;
- (void)addEventId:(id)a0 weight:(double)a1;
- (double)weightForEventId:(id)a0;
- (id)allEventIds;
- (void)scaleWeights:(double)a0;

@end
