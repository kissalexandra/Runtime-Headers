@interface Libsysdiagnose : NSObject

+ (id)setupConnection;
+ (int)addErrorString:(id)a0 WithCode:(id)a1 forError:(id *)a2;
+ (BOOL)verifyReply:(id)a0 withExpectedType:(struct _xpc_type_s { } *)a1 forError:(id *)a2;
+ (void)createMetrics:(id *)a0 fromResponse:(id)a1;
+ (id)createSysdiagnoseRequest:(id)a0;
+ (id)sendSysdiagnoseRequest:(id)a0 withMetrics:(id *)a1 withError:(id *)a2;
+ (id)sysdiagnoseWithMetadata:(id)a0 withMetrics:(id *)a1 withError:(id *)a2;
+ (id)fetchRemoteDiagnosticIDsWithError:(id *)a0;
+ (BOOL)cancelActiveSysdiagnoseWithError:(id *)a0;
+ (id)fetchDiagnosticIDFromDeviceSource:(unsigned long long)a0 WithMaxCount:(unsigned long long)a1 withError:(id *)a2;
+ (id)sysdiagnoseWithMetadata:(id)a0 withError:(id *)a1;

@end
