@interface DDParsecServiceCollectionViewControllerAccessibility : __DDParsecServiceCollectionViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityPerformEscape;

@end
