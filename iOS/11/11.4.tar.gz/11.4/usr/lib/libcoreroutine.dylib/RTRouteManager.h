@class RTMapAccess, RTGeoRouteStore, RTMotionActivityManager, RTLocationStore, NSObject, RTDefaultsManager, RTMetricManager, RTPlatform, RTBBDataProvider, RTReachabilityManager, RTPersistenceManager, RTLearnedLocationManager, NSString, NSArray;
@protocol OS_dispatch_queue;

@interface RTRouteManager : NSObject <RTPurgable>

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) RTLocationStore *locationStore;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) Class routeFinderClass;
@property (retain, nonatomic) RTMapAccess *mapAccess;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) RTBBDataProvider *bbDataProvider;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTReachabilityManager *reachabilityManager;
@property (retain, nonatomic) RTGeoRouteStore *geoRouteStore;
@property (retain, nonatomic) RTMotionActivityManager *motionActivityManager;
@property (nonatomic) BOOL learningInProgress;
@property (nonatomic) double minMotionAutomotiveRatio;
@property (nonatomic) double sampleRateForLearning;
@property (nonatomic) double maxLocationUncertainty;
@property (nonatomic) BOOL allowPersistRoutes;
@property (retain, nonatomic) NSArray *recentTransitions;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)_setup;
- (void)shutdown;
- (void)purgeManager:(id)a0 performPurgeOfType:(long long)a1 completion:(id /* block */)a2;
- (void)onLearnedLocationManagerNotification:(id)a0;
- (id)initWithLocationStore:(id)a0 learnedLocationManager:(id)a1 defaultsManager:(id)a2 persistenceManager:(id)a3 routeFinderClass:(Class)a4 platform:(id)a5 bbDataProvider:(id)a6 metricManager:(id)a7 reachabilityManager:(id)a8 geoRouteStore:(id)a9 motionActivityManager:(id)a10;
- (void)fetchPredictedRoutesToLocationOfInterestWithIdentifier:(id)a0 fromLocation:(id)a1 handler:(id /* block */)a2;
- (void)fetchRoutesToLocationOfInterestWithIdentifier:(id)a0 fromLocationOfInterestWithIdentifier:(id)a1 handler:(id /* block */)a2;
- (void)_fetchRoutesToLocationOfInterestWithIdentifier:(id)a0 fromLocationOfInterestWithIdentifier:(id)a1 handler:(id /* block */)a2;
- (void)_fetchRoutesBetweenStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)fetchAllRoutesWithHandler:(id /* block */)a0;
- (void)_fetchAllRoutesWithHandler:(id /* block */)a0;
- (void)_fetchRoutesWithPredicate:(id)a0 handler:(id /* block */)a1;
- (id)_locationOfInterestForVisit:(id)a0 fromLocationsOfInterest:(id)a1;
- (void)_buildTransitionsBetweenStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_learnRoutesForTransitions:(id)a0 currentTransitionIndex:(unsigned long long)a1 completionHandler:(id /* block */)a2;
- (void)_learnRouteForTransition:(id)a0 handler:(id /* block */)a1;
- (void)learnRoutesBetweenStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_learnRoutesBetweenStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_learnRoutesSinceLastProcessedDateWithHandler:(id /* block */)a0;
- (void)_persistRoute:(id)a0 handler:(id /* block */)a1;
- (void)sortRoutes:(id)a0 toLocationOfInterestWithIdentifier:(id)a1 fromLocation:(id)a2 handler:(id /* block */)a3;
- (void)_sortRoutes:(id)a0 toLocationOfInterestWithIdentifier:(id)a1 fromLocation:(id)a2 handler:(id /* block */)a3;
- (void)_sortRoutes:(id)a0 toLocationOfInterestWithIdentifier:(id)a1 fromLocationOfInterestWithIdentifier:(id)a2 handler:(id /* block */)a3;
- (void)_statsForRoute:(id)a0 handler:(id /* block */)a1;
- (void)_statsForLocations:(id)a0 typeDistribution:(id *)a1 majorGapLength:(double *)a2;
- (void)_injectRoutes:(id)a0 handler:(id /* block */)a1;
- (void)injectRoutes:(id)a0 handler:(id /* block */)a1;
- (void)_clearRoutesPredating:(id)a0 handler:(id /* block */)a1;
- (void)clearAllRoutesWithHandler:(id /* block */)a0;
- (void)removeRoutesAssociatedToVisitWithIdentifier:(id)a0 handler:(id /* block */)a1;
- (void)_displayLivabilityAlertIfAppropriate;
- (void)_updateGeoRoutes:(id)a0 toLocationOfInterestWithIdentifier:(id)a1 fromLocationOfInterestWithIdentifier:(id)a2 handler:(id /* block */)a3;
- (BOOL)_sampledForLearning;
- (void)_submitMetricRankRoutesInstanceWithNumberOfInputRoutes:(int)a0 highestRankedRouteScore:(int)a1;
- (void)_submitMetricLearnedRouteInstanceWithNumberOfInputLocations:(int)a0 numberOfFilteredLocations:(int)a1 length:(int)a2 recoveryTime:(int)a3 failureReason:(int)a4 latitude:(double)a5 longitude:(double)a6 majorGapLength:(int)a7 locationTypeDistribution:(id)a8 roadClassDistribution:(id)a9;

@end
