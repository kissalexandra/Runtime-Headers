@interface __MPUItemOfferButtonAccessibility_super : UIAccessibilitySafeCategory

@end
