@interface CAMViewfinderViewControllerAccessibility : __CAMViewfinderViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityPerformMagicTap;
- (void)_handleFilterButtonTapped:(id)a0;
- (void)_updateForShallowDepthOfFieldStatusChangedAnimated:(BOOL)a0;
- (void)cameraEffectsRenderer:(id)a0 didSelectFilterType:(long long)a1;

@end
