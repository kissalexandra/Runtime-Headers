@interface RTRuntime : NSObject

+ (id)subclassesOfClass:(Class)a0 images:(id)a1 includeParentClass:(BOOL)a2;
+ (id)directSubclassesOfClass:(Class)a0 images:(id)a1 includeParentClass:(BOOL)a2;
+ (id)classesFromImages:(id)a0;
+ (id)routineImageNames;
+ (id)routineClassStrings;
+ (id)routineSubclassesOfClass:(Class)a0;
+ (id)routineClasses;

@end
