@interface HerculesMappings : NSObject

+ (id)addBalancesFromVC:(id)a0 withTransceiver:(id)a1 forCity:(id)a2 withError:(id *)a3;
+ (id)mergeTaps:(id)a0 forCity:(id)a1 outEnRoute:(id *)a2;
+ (id)getStationCode:(id)a0 withTransitInformation:(id)a1 forCity:(id)a2;
+ (id)getTransitModality:(id)a0 forCity:(id)a1;
+ (id)getStationMode:(unsigned char)a0 forCity:(id)a1;
+ (id)processEnRouteStatus:(id)a0 forOperation:(unsigned char)a1 forCity:(id)a2;

@end
