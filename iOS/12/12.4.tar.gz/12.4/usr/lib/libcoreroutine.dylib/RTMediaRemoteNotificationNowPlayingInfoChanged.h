@class NSString;

@interface RTMediaRemoteNotificationNowPlayingInfoChanged : RTNotification

@property (readonly, copy, nonatomic) NSString *bundleIdentifier;
@property (readonly, nonatomic) double duration;
@property (readonly, nonatomic) long long playbackState;

- (id)initWithBundleIdentifier:(id)a0 duration:(double)a1 playbackState:(long long)a2;
- (void).cxx_destruct;

@end
