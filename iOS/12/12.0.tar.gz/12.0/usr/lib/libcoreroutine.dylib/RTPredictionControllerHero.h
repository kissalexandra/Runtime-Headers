@class RTDataProviderHeroApp, RTApplicationManager;

@interface RTPredictionControllerHero : RTNotifier

@property (retain, nonatomic) RTDataProviderHeroApp *dataProvider;
@property (retain, nonatomic) RTApplicationManager *applicationManager;

- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)stopMonitoringForPredictedApplications;
- (void)fetchPredictedApplications:(id /* block */)a0;
- (void)fetchPredictedApplicationsAtLocation:(id)a0 handler:(id /* block */)a1;
- (void)fetchPredictedApplicationsWithPredicate:(id)a0 handler:(id /* block */)a1;
- (id)initWithDataProvider:(id)a0 applicationManager:(id)a1;
- (void)_stopMonitoringForPredictedApplications;
- (void)_startMonitoringForPredictedApplications;
- (void)onHeroAppPrediction:(id)a0;
- (void)_onHeroAppPrediction:(id)a0;
- (void)onApplicationChange:(id)a0;
- (void)_refreshAllData;
- (void)_onApplicationChange:(id)a0;
- (void)startMonitoringForPredictedApplications;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)invalidate;

@end
