@class RTInvocationDispatcher, NSArray, NSString, RTPurgeManager, NSError, NSMutableArray;

@interface RTDataProvider : RTService <RTDataProviderProtocol> {
    NSMutableArray *_cachedData;
    BOOL _cachedDataNeedsCopyOnWrite;
}

@property (nonatomic) long long state;
@property (retain, nonatomic) RTPurgeManager *purgeManager;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) NSArray *cachedData;
@property (nonatomic) BOOL populating;
@property (retain, nonatomic) NSError *invalidationError;
@property (readonly, nonatomic) NSString *name;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)providerName;

- (void)_purge;
- (void)_shutdown;
- (id)initWithPurgeManager:(id)a0;
- (void)populateDataProviderWithHandler:(id /* block */)a0;
- (void)purgeWithHandler:(id /* block */)a0;
- (void)refreshWithHandler:(id /* block */)a0;
- (void)fetchDataWithFilterPredicates:(id)a0 sortDescriptors:(id)a1 handler:(id /* block */)a2;
- (void)onMemoryWarningNotification:(id)a0;
- (void)_removeAllEvents;
- (void)_refresh;
- (void)_fetchDataWithFilterPredicates:(id)a0 sortDescriptors:(id)a1 handler:(id /* block */)a2;
- (void)__fetchDataWithFilterPredicates:(id)a0 sortDescriptors:(id)a1 handler:(id /* block */)a2;
- (void)addObjectToCachedData:(id)a0;
- (void)fetchAllDataWithHandler:(id /* block */)a0;
- (void)removeObserverInternal:(id)a0 notificationName:(id)a1;
- (void)addObserverInternal:(id)a0 notificationName:(id)a1;
- (void)fetchDataProviderStatus:(id /* block */)a0;
- (id)init;
- (void).cxx_destruct;
- (void)_didReceiveMemoryWarning:(long long)a0;
- (void)purge;
- (void)refresh;

@end
