@class AXHAStepSlider, NSNumberFormatter, AXRemoteHearingAidDevice;
@protocol AXHearingVolumeCellDelegate;

@interface AXHearingVolumeCell : AXHearingBlurCell {
    NSNumberFormatter *_numberFormatter;
    AXHAStepSlider *_stepSlider;
}

@property (retain, nonatomic) AXRemoteHearingAidDevice *device;
@property (nonatomic) long long type;
@property (nonatomic) id<AXHearingVolumeCellDelegate> delegate;

- (void)layoutSubviews;
- (void)dealloc;
- (id)title;
- (double)value;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;
- (void)accessibilityIncrement;
- (void)accessibilityDecrement;
- (void)updateVolumeValue;
- (void)sliderValueDidChange:(id)a0;
- (short)numberOfStepsForType:(long long)a0;
- (id)initWithDevice:(id)a0 andType:(long long)a1;

@end
