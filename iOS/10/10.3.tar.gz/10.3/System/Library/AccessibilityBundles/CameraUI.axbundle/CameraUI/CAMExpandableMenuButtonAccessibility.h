@interface CAMExpandableMenuButtonAccessibility : __CAMExpandableMenuButtonAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)isAccessibilityElement;

@end
