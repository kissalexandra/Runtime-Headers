@interface __CMKTopBarAccessibility_super : UIAccessibilitySafeCategory

@end
