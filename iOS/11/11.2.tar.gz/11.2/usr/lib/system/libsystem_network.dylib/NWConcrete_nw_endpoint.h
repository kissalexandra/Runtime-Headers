@class NSString, NSObject;
@protocol OS_nw_interface;

@interface NWConcrete_nw_endpoint : NSObject <OS_nw_endpoint> {
    BOOL is_local_domain;
    NSObject<OS_nw_interface> *interface;
    char *parent_endpoint_domain;
    char *description;
    NWConcrete_nw_endpoint *proxy_original_endpoint;
}

@property (readonly, nonatomic) unsigned int type;
@property (readonly, nonatomic) const char *domainForPolicy;
@property (readonly, nonatomic) unsigned short port;
@property (readonly, nonatomic) const char *getDescription;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1;
- (unsigned long long)getHash;
- (id)copyDictionary;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (BOOL)isEqual:(id)a0;

@end
