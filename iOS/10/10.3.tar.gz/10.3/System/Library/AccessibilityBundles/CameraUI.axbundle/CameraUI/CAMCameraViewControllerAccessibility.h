@interface CAMCameraViewControllerAccessibility : __CAMCameraViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityPerformEscape;

@end
