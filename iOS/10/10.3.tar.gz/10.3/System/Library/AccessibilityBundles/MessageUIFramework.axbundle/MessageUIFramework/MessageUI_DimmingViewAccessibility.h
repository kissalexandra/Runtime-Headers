@interface MessageUI_DimmingViewAccessibility : __MessageUI_DimmingViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)passthroughViews;

@end
