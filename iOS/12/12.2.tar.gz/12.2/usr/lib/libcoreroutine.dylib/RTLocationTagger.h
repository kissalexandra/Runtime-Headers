@class RTMicroLocation, NSUUID, RTAuthorizationManager, RTVisitManager, RTInvocationDispatcher, RTLearnedLocationManager, NSObject, RTLocationManager;
@protocol OS_dispatch_queue;

@interface RTLocationTagger : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (nonatomic) BOOL ready;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (nonatomic) BOOL realtimeLocationTaggingAllowed;
@property (nonatomic) BOOL historicLocationTaggingAllowed;
@property (nonatomic) double maximumEventLocationTaggingTimeInterval;
@property (retain, nonatomic) RTMicroLocation *currentMicroLocation;
@property (retain, nonatomic) NSUUID *currentLocationOfInterestIdentifier;

- (void)_unregisterForNotifications;
- (void)shutdown;
- (void)_registerForNotifications;
- (id)initWithAuthorizationManager:(id)a0 locationManager:(id)a1 learnedLocationManager:(id)a2 visitManager:(id)a3;
- (void)onMicroLocationUpdate:(id)a0;
- (void)onLowConfidenceVisitNotification:(id)a0;
- (void)onMagicalMomentsLocationUsageUpdate:(id)a0;
- (void)onRoutineEnabledUpdate:(id)a0;
- (void)_fetchLowConfidenceVisitIncident:(id /* block */)a0;
- (void)onVisitManagerAvailable:(id)a0;
- (void)_handleLowConfidenceVisitIncident:(id)a0;
- (void)_armLocationTagger;
- (void)_disarmLocationTagger;
- (BOOL)_validateObject:(id)a0;
- (void)_performTagWithObject:(id)a0;
- (void)tagObjectWithLocation:(id)a0 handler:(id /* block */)a1;
- (BOOL)tagObjectWithLocation:(id)a0 error:(id *)a1;
- (void)realtimeLocationTaggingAllowed:(id /* block */)a0;
- (void)historicalLocationTaggingAllowed:(id /* block */)a0;
- (void)tagObject:(id)a0 withLocationVisitEvents:(id)a1;
- (void)tagObject:(id)a0 withMicroLocationEvents:(id)a1 minimumProbability:(double)a2;
- (id)init;
- (void).cxx_destruct;

@end
