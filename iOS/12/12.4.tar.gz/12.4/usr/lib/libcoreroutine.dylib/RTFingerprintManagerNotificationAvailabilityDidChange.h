@interface RTFingerprintManagerNotificationAvailabilityDidChange : RTNotification

@property (readonly, nonatomic) BOOL available;

- (id)initWithAvailability:(BOOL)a0;
- (id)description;

@end
