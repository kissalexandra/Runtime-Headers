@class NSMutableDictionary;

@interface RTStateTransitionMotionActivityTypeHistogram : NSObject

@property (retain, nonatomic) NSMutableDictionary *motionActivityTypeBins;

- (void)addMotionActivityType:(unsigned long long)a0;
- (unsigned long long)getDominantMotionActivityType;
- (id)init;
- (void).cxx_destruct;
- (void)show;

@end
