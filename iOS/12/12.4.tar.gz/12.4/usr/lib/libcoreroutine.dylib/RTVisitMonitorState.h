@class RTVisit, NSMutableArray;

@interface RTVisitMonitorState : NSObject <NSSecureCoding, NSCopying>

@property (class, readonly) BOOL supportsSecureCoding;

@property (nonatomic) BOOL insideAnLoi;
@property (nonatomic) BOOL insideAnLoiButStatTimeNotMet;
@property (nonatomic) double lastProcessedSample_s;
@property (nonatomic) double potentialEntry_s;
@property (nonatomic) double potentialExit_s;
@property (nonatomic) double sumLat_deg;
@property (nonatomic) double sumLon_deg;
@property (nonatomic) double sumLat2_deg;
@property (nonatomic) double sumLon2_deg;
@property (nonatomic) double entrySampleLat_deg;
@property (nonatomic) double entrySampleLon_deg;
@property (nonatomic) long long dataPointCnt;
@property (nonatomic) long long adaptionSampleCnt;
@property (nonatomic) double lastProcessedSampleForAdaption_s;
@property (nonatomic) long long outlierCnt;
@property (retain, nonatomic) NSMutableArray *tempOutliers;
@property (nonatomic) BOOL entryEdgeDetected;
@property (retain, nonatomic) RTVisit *lastVisitIncident;
@property (retain, nonatomic) RTVisit *lastLowConfidenceVisitIncident;
@property (nonatomic) long long pendingReprocessRequestCount;
@property (nonatomic) long long visitCallCnt;
@property (nonatomic) BOOL checkedForHintNearEntryLocation;
@property (nonatomic) long long lowConfidenceVisitStatus;

- (void)dump;
- (id)init;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (id)copyWithZone:(struct _NSZone { } *)a0;

@end
