@class CLLocation, NSDate;

@interface RTHint : NSObject

@property (retain, nonatomic) CLLocation *location;
@property (nonatomic) long long source;
@property (readonly, nonatomic) NSDate *date;

+ (id)hintSourceToString:(long long)a0;

- (id)initWithLocation:(id)a0 source:(long long)a1 date:(id)a2;
- (BOOL)isEqual:(id)a0;
- (void).cxx_destruct;
- (unsigned long long)hash;
- (id)description;

@end
