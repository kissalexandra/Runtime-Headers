@class NSString, NSNumber;

@interface ADEvent : NSObject

@property long long operation;
@property long long storage;
@property long long key;
@property (retain) NSString *stringKey;
@property (retain) NSNumber *value;

+ (id)eventWithOperation:(long long)a0 Storage:(long long)a1 Key:(long long)a2 Value:(id)a3;
+ (id)eventWithOperation:(long long)a0 Storage:(long long)a1 StringKey:(id)a2 Value:(id)a3;

- (id)initWithOperation:(long long)a0 Storage:(long long)a1 Key:(long long)a2 StringKey:(id)a3 Value:(id)a4;
- (id)stringKey:(long long)a0 useCase:(int)a1 prearmedApplePay:(BOOL)a2;
- (void)pushToAggregateDictionary:(long long)a0 useCase:(int)a1 prearmedApplePay:(BOOL)a2;
- (id)description;
- (void)dealloc;

@end
