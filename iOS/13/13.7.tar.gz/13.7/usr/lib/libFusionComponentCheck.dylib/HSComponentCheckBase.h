@interface HSComponentCheckBase : NSObject

- (id)init;
- (int)setup;
- (id)querySN;
- (int)setupInRamdisk;

@end
