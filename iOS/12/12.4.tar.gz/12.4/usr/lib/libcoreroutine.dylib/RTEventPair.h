@interface RTEventPair : NSObject

@property (readonly, nonatomic) id firstObject;
@property (readonly, nonatomic) id secondObject;

- (id)initWithFirstObject:(id)a0 secondObject:(id)a1;
- (BOOL)isEqualToEventPair:(id)a0;
- (id)init;
- (BOOL)isEqual:(id)a0;
- (void).cxx_destruct;
- (unsigned long long)hash;
- (id)description;

@end
