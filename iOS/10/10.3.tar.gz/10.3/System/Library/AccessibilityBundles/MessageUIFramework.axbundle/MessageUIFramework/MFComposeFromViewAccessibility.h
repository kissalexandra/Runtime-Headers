@interface MFComposeFromViewAccessibility : __MFComposeFromViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityContainer;
- (id)_accountLabel;

@end
