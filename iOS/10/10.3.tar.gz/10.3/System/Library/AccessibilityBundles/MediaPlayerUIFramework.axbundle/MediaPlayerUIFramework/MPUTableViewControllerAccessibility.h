@interface MPUTableViewControllerAccessibility : __MPUTableViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (long long)_accessibilityTableViewIndexAdjustment;

@end
