@interface AppletTranslator : NSObject

+ (void)cleanup;
+ (id)userDefaults;
+ (BOOL)isInternalBuild;
+ (struct os_state_data_s { unsigned int x0; union { unsigned int x0 : 32; unsigned int x1; } x1; struct os_state_data_decoder_s { char x0[64]; char x1[64]; } x2; char x3[64]; unsigned char x4[0]; } *)dumpState;
+ (void)registerForCleanup:(id)a0;
+ (void)deregisterForCleanup:(id)a0;
+ (id)parseHCIEvent:(id)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 withTransceiver:(id)a4 withError:(id *)a5;
+ (id)GetAppletProperties:(id)a0 withPackage:(id)a1 withModule:(id)a2 withTransceiver:(id)a3 withError:(id *)a4;
+ (id)getNFCSettings;
+ (BOOL)isDebugLoggingEnabled;
+ (BOOL)configureSEExpressApplets:(id)a0 transceiver:(id)a1 seHasActivatedApplets:(BOOL *)a2 skipAllActivations:(BOOL)a3 error:(id *)a4;
+ (void)initLibrary:(id /* block */)a0;
+ (void)initLibraryWithDelegate:(id)a0;
+ (id)getATLDelegate;
+ (id)getAppletStateAndHistory:(id)a0 withPackage:(id)a1 withModule:(id)a2 withTransceiver:(id)a3 withError:(id *)a4;
+ (BOOL)appletCacheUpdated:(id)a0 serialNumber:(id)a1 isdSequenceCounter:(id)a2 transceiver:(id)a3 error:(id *)a4;
+ (BOOL)setPlasticCardMode:(BOOL)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 serialNumber:(id)a4 transceiver:(id)a5 error:(id *)a6;
+ (BOOL)configureSEExpressApplets:(id)a0 transceiver:(id)a1 error:(id *)a2;
+ (id)checkSEExpressAppletCompatibility:(id)a0 error:(id *)a1;
+ (id)processEndOfTransaction:(id)a0 withPackage:(id)a1 withModule:(id)a2 withTransceiver:(id)a3 withError:(id *)a4;
+ (BOOL)isLegacyApplet:(id)a0 withPackage:(id)a1 withModule:(id)a2;

@end
