@interface MPUSystemMediaControlsViewAccessibility : __MPUSystemMediaControlsViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)layoutSubviews;
- (id)accessibilityIdentifier;
- (id)initWithStyle:(long long)a0;
- (void)_accessibilityLoadAccessibilityInformation;

@end
