@interface __MFComposeHeaderViewAccessibility_super : UIAccessibilitySafeCategory

@end
