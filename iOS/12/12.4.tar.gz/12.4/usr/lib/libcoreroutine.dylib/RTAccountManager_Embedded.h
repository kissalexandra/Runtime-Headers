@interface RTAccountManager_Embedded : RTAccountManager

- (id)_primaryiCloudAccount;

@end
