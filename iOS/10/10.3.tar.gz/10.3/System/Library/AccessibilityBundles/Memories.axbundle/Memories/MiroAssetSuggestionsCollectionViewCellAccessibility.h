@interface MiroAssetSuggestionsCollectionViewCellAccessibility : __MiroAssetSuggestionsCollectionViewCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;
- (id)_axPHAsset;
- (id)_accessibilityPhotoDescription;
- (void)configureWithAsset:(id)a0 selected:(BOOL)a1;

@end
