@interface __MPButtonAccessibility_super : UIAccessibilitySafeCategory

@end
