@interface __ABBannerViewAccessibility_super : UIAccessibilitySafeCategory

@end
