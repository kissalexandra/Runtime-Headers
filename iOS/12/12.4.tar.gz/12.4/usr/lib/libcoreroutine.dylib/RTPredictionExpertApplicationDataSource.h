@class RTLocationTagger, NSArray, RTApplicationManager, RTDefaultsManager, RTInvocationDispatcher, NSError;

@interface RTPredictionExpertApplicationDataSource : RTPredictionExpertDataSource {
    NSArray *_applicationBlacklist;
    NSArray *_nowPlayingBlacklist;
    RTApplicationManager *_applicationManager;
    RTLocationTagger *_locationTagger;
    RTDefaultsManager *_defaultsManager;
    RTInvocationDispatcher *_dispatcher;
    BOOL _ready;
    NSError *_fetchError;
}

@property (readonly, nonatomic) double minNowPlayingEventDuration;
@property (readonly, nonatomic) double microLocationConfidenceThreshold;
@property (readonly, nonatomic) NSArray *filteredMatchedAppLaunchEvents;
@property (readonly, nonatomic) NSArray *locationVisitEvents;
@property (readonly, nonatomic) NSArray *microLocationEvents;

+ (id)defaultApplicationBlacklist;

- (void)prefetch:(id /* block */)a0;
- (id)initWithDataProviders:(id)a0 applicationManager:(id)a1 locationTagger:(id)a2 defaultsManager:(id)a3;
- (void)matchEventsToAllLocationEvents:(id)a0;
- (id)init;
- (void).cxx_destruct;
- (void)reset;

@end
