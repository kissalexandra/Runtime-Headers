@class NSNumber;

@interface RTPredictionExpertFeatureAddonWeekdayMO : RTPredictionExpertFeatureAddonMO

@property (retain, nonatomic) NSNumber *targetDays;

+ (id)managedObjectWithTargetDays:(long long)a0 inManagedObjectContext:(id)a1;

@end
