@interface MFComposeRecipientViewAccessibility : __MFComposeRecipientViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0;
- (void)dragUpdated:(id)a0 atPoint:(struct CGPoint { double x0; double x1; })a1;
- (void)dragEntered:(id)a0 atPoint:(struct CGPoint { double x0; double x1; })a1;
- (void)dragStartedWithItem:(id)a0;
- (void)addRecipient:(id)a0 index:(unsigned long long)a1 animate:(BOOL)a2;
- (void)_reflowAnimated:(BOOL)a0;
- (void)removeRecipient:(id)a0;

@end
