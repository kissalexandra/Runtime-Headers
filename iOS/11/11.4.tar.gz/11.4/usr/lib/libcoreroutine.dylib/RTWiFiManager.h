@class NSArray;

@interface RTWiFiManager : RTNotifier

@property (nonatomic) unsigned long long powerStatus;
@property (readonly, nonatomic) unsigned long long linkStatus;
@property (retain, nonatomic) NSArray *accessPoints;

+ (id)allocWithZone:(struct _NSZone { } *)a0;
+ (BOOL)supportsNotificationName:(id)a0;
+ (id)linkStatusToString:(unsigned long long)a0;
+ (id)powerStatusToString:(unsigned long long)a0;

- (void)setup;
- (id)init;
- (void).cxx_destruct;
- (void)_setup;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_shutdown;
- (void)scheduleScan;
- (void)cancelScan;
- (void)fetchPowerStatus:(id /* block */)a0;
- (void)fetchLinkStatus:(id /* block */)a0;
- (void)_scheduleScan;
- (void)_cancelScan;
- (void)_notifyScanResults:(id)a0;

@end
