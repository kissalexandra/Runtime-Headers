@interface RTPersistenceMirroringPolicy : NSObject

@property (readonly, nonatomic) BOOL allowsMirroringViaCellular;

@end
