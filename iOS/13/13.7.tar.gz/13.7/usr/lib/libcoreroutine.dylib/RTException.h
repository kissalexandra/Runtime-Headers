@interface RTException : NSObject

+ (void)kuzcoSaysNoTouchy;
+ (void)dontOpenDeadInside;

@end
