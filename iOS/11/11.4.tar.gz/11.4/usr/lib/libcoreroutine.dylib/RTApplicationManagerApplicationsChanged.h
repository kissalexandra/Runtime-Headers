@class NSSet;

@interface RTApplicationManagerApplicationsChanged : RTNotification

@property (readonly, copy, nonatomic) NSSet *installedApplicationBundleIdentifiers;
@property (readonly, copy, nonatomic) NSSet *uninstalledApplicationBundleIdentifiers;

- (void).cxx_destruct;
- (id)initWithInstalledApplicationBundleIdentifiers:(id)a0 uninstalledApplicationBundleIdentifiers:(id)a1;

@end
