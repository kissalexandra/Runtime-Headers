@interface CMKCaptureControllerAccessibility : __CMKCaptureControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)cameraControllerVideoCaptureDidStart:(id)a0;
- (void)_setCameraMode:(long long)a0 cameraDevice:(long long)a1;
- (void)_sessionStopped:(id)a0;
- (BOOL)capturePhotoUsingHDR:(BOOL)a0;
- (void)_capturedPhotoWithDictionary:(id)a0 error:(id)a1 HDRUsed:(BOOL)a2;
- (void)_accessibilityLoadAccessibilityInformation;
- (void)_sessionStarted:(id)a0;
- (void)captureOutput:(id)a0 didOutputMetadataObjects:(id)a1 fromConnection:(id)a2;

@end
