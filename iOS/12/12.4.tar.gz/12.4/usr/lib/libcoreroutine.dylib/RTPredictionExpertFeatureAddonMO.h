@class NSSet;

@interface RTPredictionExpertFeatureAddonMO : NSManagedObject

@property (retain, nonatomic) id eventFilterPredicate;
@property (retain, nonatomic) NSSet *entry;

+ (id)managedObjectWithPredicate:(id)a0 inManagedObjectContext:(id)a1;

@end
