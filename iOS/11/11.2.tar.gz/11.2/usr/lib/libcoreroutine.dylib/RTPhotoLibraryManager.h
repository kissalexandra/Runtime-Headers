@class RTDataProtectionManager;
@protocol RTPhotoLibraryManagerDelegate;

@interface RTPhotoLibraryManager : RTNotifier

@property (readonly, nonatomic) RTDataProtectionManager *dataProtectionManager;
@property (readonly, nonatomic) id<RTPhotoLibraryManagerDelegate> delegate;
@property (nonatomic) BOOL encryptedDataAvailability;

- (id)init;
- (void).cxx_destruct;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithDataProtectionManager:(id)a0;
- (id)initWithDataProtectionManager:(id)a0 delegate:(id)a1;
- (void)onDataProtectionNotification:(id)a0;

@end
