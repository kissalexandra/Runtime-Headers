@class NSString, NSNumber, NSDate;

@interface RTEventModelUserInteractionMO : NSManagedObject

@property (copy, nonatomic) NSString *feedback;
@property (retain, nonatomic) NSNumber *interaction;
@property (copy, nonatomic) NSString *locationOfInterestIdentifier;
@property (copy, nonatomic) NSString *receiptCalendarIdentifier;
@property (copy, nonatomic) NSString *receiptLocation;
@property (copy, nonatomic) NSString *receiptTitle;
@property (copy, nonatomic) NSDate *date;

+ (id)managedObjectWithFeedback:(id)a0 interaction:(id)a1 locationOfInterestIdentifier:(id)a2 receiptCalendarIdentifier:(id)a3 receiptLocation:(id)a4 receiptTitle:(id)a5 date:(id)a6 inManagedObjectContext:(id)a7;

@end
