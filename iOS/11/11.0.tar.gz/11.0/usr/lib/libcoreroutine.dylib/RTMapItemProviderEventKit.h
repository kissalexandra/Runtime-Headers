@class NSString, RTMapServiceManager, RTEventManager;

@interface RTMapItemProviderEventKit : NSObject <RTMapItemProvider>

@property (retain, nonatomic) RTEventManager *eventManager;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

@end
