@interface MKUIImageAccessibility : __MKUIImageAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (id)_mapkit_imageNamed:(id)a0;
+ (id)_mapkit_transitArtworkImageWithDataSource:(id)a0 size:(long long)a1 forView:(id)a2 withWidthPaddingMultiple:(double)a3;
+ (Class)safeCategoryBaseClass;

@end
