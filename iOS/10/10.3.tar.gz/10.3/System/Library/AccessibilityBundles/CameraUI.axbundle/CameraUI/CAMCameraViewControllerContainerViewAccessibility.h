@interface CAMCameraViewControllerContainerViewAccessibility : __CAMCameraViewControllerContainerViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)layoutSubviews;
- (void)_accessibilityLoadAccessibilityInformation;
- (void)verifyViewOrdering;

@end
