@interface RTStarkManagerNotificationConnectionState : RTNotification

@property (nonatomic) long long connectionState;

- (id)initWithConnectionState:(long long)a0;

@end
