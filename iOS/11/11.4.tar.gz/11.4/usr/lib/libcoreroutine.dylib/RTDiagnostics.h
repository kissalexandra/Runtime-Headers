@class NSArray, RTPlatform, RTDefaultsManager;

@interface RTDiagnostics : NSObject {
    RTPlatform *_platform;
    RTDefaultsManager *_defaultsManager;
}

@property (copy) NSArray *diagnosticProviders;

- (id)init;
- (void).cxx_destruct;
- (id)initWithPlatform:(id)a0 defaultsManager:(id)a1;
- (void)logProcessDiagnosticInformation;
- (id)crashReports;
- (BOOL)collectArchiveSinceDate:(id)a0 path:(id)a1 error:(id *)a2;
- (void)fetchPathToDiagnosticFilesWithHandler:(id /* block */)a0;
- (void)rolloverSnapshots;
- (void)takeSnapshotSinceDate:(id)a0 description:(id)a1 handler:(id /* block */)a2;

@end
