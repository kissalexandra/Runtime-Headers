@class RTPersistenceManager, RTLocationStore, RTDeviceLocationPredictor, RTMapServiceManager, RTAssetManager, RTLocationManager, RTFingerprintManager, RTAuthorizationManager, RTWiFiManager, RTLearnedLocationManager, RTVisitManager, RTAccountManager, NSString, RTScenarioTriggerManager, NSObject, RTActionManager, RTRouteManager, RTPredictedApplicationManager, NSXPCConnection, RTEventModelProvider, RTVehicleLocationProvider, RTPurgeManager;
@protocol OS_dispatch_queue;

@interface RTInternalDaemonClient : NSObject <RTDaemonInternalProtocol>

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) RTPredictedApplicationManager *predictedApplicationManager;
@property (retain, nonatomic) RTScenarioTriggerManager *scenarioTriggerManager;
@property (retain, nonatomic) RTVehicleLocationProvider *vehicleLocationProvider;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTDeviceLocationPredictor *deviceLocationPredictor;
@property (retain, nonatomic) RTPurgeManager *purgeManager;
@property (retain, nonatomic) RTActionManager *actionManager;
@property (retain, nonatomic) RTEventModelProvider *eventModelProvider;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) RTAssetManager *assetManager;
@property (retain, nonatomic) RTLocationStore *locationStore;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTRouteManager *routeManager;
@property (retain, nonatomic) RTAccountManager *accountManager;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) RTFingerprintManager *fingerprintManager;
@property (retain, nonatomic) RTWiFiManager *wifiManager;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (retain, nonatomic) NSXPCConnection *xpcConnection;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (BOOL)hasEntitlement:(id)a0;
- (void).cxx_destruct;
- (void)fetchMagicalMomentsModelPropertyListRepresentation:(id /* block */)a0;
- (void)forceSequentialClusterIdentification:(id /* block */)a0;
- (void)injectLocationOfInterest:(id)a0 reply:(id /* block */)a1;
- (void)injectVisit:(id)a0 locationOfInterest:(id)a1 reply:(id /* block */)a2;
- (void)clearAllLocationsOfInterestWithReply:(id /* block */)a0;
- (void)fetchStoredLocationsFromDate:(id)a0 toDate:(id)a1 reply:(id /* block */)a2;
- (void)simulateScenarioTrigger:(id)a0 reply:(id /* block */)a1;
- (void)fetchPredictedApplicationsForEvent:(id)a0 withReply:(id /* block */)a1;
- (void)processDataForPredictionModelWithReply:(id /* block */)a0;
- (void)printMagicalMomentsModelWithReply:(id /* block */)a0;
- (void)forceUpdateAssetMetadata;
- (void)updateAssetServerURL:(id)a0 assetType:(id)a1 reply:(id /* block */)a2;
- (void)requestCurrentMicroLocation;
- (void)forceEventModelRefreshWithReply:(id /* block */)a0;
- (void)injectLocations:(id)a0 reply:(id /* block */)a1;
- (void)fetchRoutesToLocationOfInterestWithIdentifier:(id)a0 fromLocationOfInterestWithIdentifier:(id)a1 reply:(id /* block */)a2;
- (void)learnRoutesBetweenStartDate:(id)a0 endDate:(id)a1 reply:(id /* block */)a2;
- (void)injectRoutes:(id)a0 reply:(id /* block */)a1;
- (void)clearAllRoutesWithReply:(id /* block */)a0;
- (void)simulateVisit:(id)a0 reply:(id /* block */)a1;
- (void)performImportMirroringRequest:(id /* block */)a0;
- (void)performExportMirroringRequest:(id /* block */)a0;
- (void)performZoneResetMirroringRequest:(id /* block */)a0;
- (void)fetchVisitsBetweenStartDate:(id)a0 endDate:(id)a1 reply:(id /* block */)a2;
- (void)injectFingerprintWithSettledState:(BOOL)a0 start:(id)a1 reply:(id /* block */)a2;
- (void)injectWiFiAccessPointWithMac:(id)a0 rssi:(long long)a1 channel:(long long)a2 age:(double)a3 date:(id)a4 reply:(id /* block */)a5;
- (void)fetchCurrentPredictedLocationsOfInterestLookingBack:(double)a0 lookingAhead:(double)a1 reply:(id /* block */)a2;
- (void)logLocationsOfInterestWithReply:(id /* block */)a0;
- (id)initWithQueue:(id)a0 deviceLocationPredictor:(id)a1 scenarioTriggerManager:(id)a2 vehicleLocationProvider:(id)a3 predictedApplicationManager:(id)a4 actionManager:(id)a5 eventModelProvider:(id)a6 visitManager:(id)a7 authorizationManager:(id)a8 purgeManager:(id)a9 assetManager:(id)a10 locationStore:(id)a11 locationManager:(id)a12 learnedLocationManager:(id)a13 routeManager:(id)a14 accountManager:(id)a15 persistenceManager:(id)a16 fingerprintManager:(id)a17 wifiManager:(id)a18 mapServiceManager:(id)a19;

@end
