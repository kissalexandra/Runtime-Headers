@class RTVisitMonitor, RTHintManager, RTLocationAwarenessManager, RTInvocationDispatcher, RTDefaultsManager, NSMutableArray, RTPlatform, NSManagedObjectContext, RTMetricManager, NSString, RTPersistenceManager, RTLearnedLocationManager, RTLocationManager;

@interface RTVisitManager : RTNotifier <RTVisitMonitorDelegate>

@property (retain, nonatomic) RTVisitMonitor *visitMonitor;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTHintManager *hintManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTLocationAwarenessManager *locationAwarenessManager;
@property (retain, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (nonatomic) BOOL spoofMode;
@property (retain, nonatomic) NSMutableArray *spoofVisitIncidentTokens;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)setup;
- (id)init;
- (void).cxx_destruct;
- (void)_setup;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_shutdown;
- (void)fetchLastVisitIncidentWithHandler:(id /* block */)a0;
- (void)fetchLastLowConfidenceVisitIncidentWithHandler:(id /* block */)a0;
- (void)onVisitIncident:(id)a0 error:(id)a1;
- (void)onLeechedVisitIncident:(id)a0 error:(id)a1;
- (void)onLowConfidenceVisitIncident:(id)a0 error:(id)a1;
- (void)onVisitMonitorStateChanged:(id)a0;
- (id)initWithQueue:(id)a0 persistenceManager:(id)a1 defaultsManager:(id)a2 platform:(id)a3 locationManager:(id)a4 learnedLocationManager:(id)a5 hintManager:(id)a6 metricManager:(id)a7 locationAwarenessManager:(id)a8;
- (void)_saveManagedObjectContext;
- (void)_saveVisitMonitorState:(id)a0;
- (void)_setupVisitMonitor;
- (void)_updateStateForVisitIncidents;
- (void)_updateStateForLeechedVisitIncidents;
- (void)_updateStateForLowConfidenceVisitIncidents;
- (void)_fetchVisitsFromVisitMonitor:(id)a0 fromDate:(id)a1 toDate:(id)a2 limit:(unsigned long long)a3 handler:(id /* block */)a4;
- (void)_fetchVisitsFromDate:(id)a0 toDate:(id)a1 handler:(id /* block */)a2;
- (void)fetchVisitsFromDate:(id)a0 toDate:(id)a1 handler:(id /* block */)a2;
- (void)_onVisitIncident:(id)a0 error:(id)a1;
- (void)_onLeechedVisitIncident:(id)a0 error:(id)a1;
- (void)_onLowConfidenceVisitIncident:(id)a0 error:(id)a1;
- (void)_onVisitMonitorStateChanged:(id)a0;
- (id)registerForSpoofVisitIncidentOfCategory:(id)a0;
- (void)unregisterForSpoofVisitIncidentWithToken:(int)a0;
- (void)_simulateVisit:(id)a0 handler:(id /* block */)a1;
- (void)simulateVisit:(id)a0 handler:(id /* block */)a1;

@end
