@class NSString;
@protocol NSObject, NSSecureCoding, NSCopying;

@interface RTPredictionExpertFeatureAddonContext : RTPredictionExpertFeatureAddon

@property (readonly, nonatomic) NSString *key;
@property (readonly, nonatomic) id<NSObject, NSCopying, NSSecureCoding> value;

- (id)initWithKey:(id)a0 value:(id)a1;
- (void).cxx_destruct;
- (id)description;
- (long long)addonType;

@end
