@class NSString, RTDeviceMO, NSData, NSUUID, NSDate;

@interface RTCloudManagedObject : NSManagedObject

@property (retain, nonatomic) RTDeviceMO *device;
@property (copy, nonatomic) NSString *ckRecordID;
@property (copy, nonatomic) NSData *ckRecordSystemFields;
@property (copy, nonatomic) NSUUID *identifier;
@property (copy, nonatomic) NSDate *creationDate;
@property (copy, nonatomic) NSDate *expirationDate;

- (void)awakeFromInsert;

@end
