@class RTPlatform, NSArray, RTInvocationDispatcher, RTManagedConfiguration, AWDServerConnection, NSObject;
@protocol OS_dispatch_queue;

@interface RTMetricManager : NSObject

@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) RTPlatform *platform;
@property (nonatomic) BOOL ready;
@property (retain, nonatomic) NSArray *configuredMetricClasses;
@property (retain, nonatomic) AWDServerConnection *awdServerConnection;
@property (retain, nonatomic) RTManagedConfiguration *managedConfigurationManager;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;

+ (id)metricForType:(unsigned long long)a0;
+ (int)modelTypeFromSupportingEventClass:(Class)a0;
+ (id)addonMetricFromAddon:(id)a0;
+ (id)addonStringFromType:(int)a0;
+ (id)productionMetrics;
+ (double)doubleWithSignificantDigits:(double)a0 digits:(int)a1;
+ (int)roundTimeInterval:(double)a0 byIntervalUnit:(unsigned long long)a1;
+ (int)doubleToInt:(double)a0 shifts:(int)a1;
+ (int)intWithSignificantDigits:(int)a0 digits:(int)a1;

- (void)shutdown;
- (void)submitMetric:(id)a0;
- (void)fetchDiagnosticsEnabled:(id /* block */)a0;
- (void)submitMetricWithIdentifier:(id)a0 dictionary:(id)a1 handler:(id /* block */)a2;
- (id)initWithPlatform:(id)a0;
- (id)initWithAWDServerConnection:(id)a0 configuredClasses:(id)a1 managedConfigurationManager:(id)a2 platform:(id)a3;
- (void)_setupWithConfiguredClasses:(id)a0;
- (void)_fetchDiagnosticsEnabled:(id /* block */)a0;
- (void)_registerQueriableMetric:(unsigned long long)a0 withHandler:(id /* block */)a1;
- (void)_releaseMetricPlaceholderForMetric:(id)a0 withHandler:(id /* block */)a1;
- (void)_submitMetric:(id)a0 withHandler:(id /* block */)a1;
- (void)_submitMetricWithIdentifier:(id)a0 dictionary:(id)a1 handler:(id /* block */)a2;
- (id)convertMetricWithIdentifier:(id)a0 dictionary:(id)a1;
- (void)submitMetric:(id)a0 withHandler:(id /* block */)a1;
- (BOOL)_routineConfiguredForMetric:(id)a0;
- (BOOL)_isDiagnosticsSubmissionAllowed;
- (void)registerQueriableMetric:(unsigned long long)a0 withHandler:(id /* block */)a1;
- (id)createMetricForType:(unsigned long long)a0;
- (id)init;
- (void).cxx_destruct;

@end
