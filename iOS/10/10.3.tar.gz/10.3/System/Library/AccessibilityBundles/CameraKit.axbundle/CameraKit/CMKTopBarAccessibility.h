@interface CMKTopBarAccessibility : __CMKTopBarAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (BOOL)shouldGroupAccessibilityChildren;
- (BOOL)_accessibilityOnlyComparesByXAxis;

@end
