@class NSString, NSDate;
@protocol GEOMapItem;

@interface RTLOIDisplayInfo : NSObject

@property (readonly, nonatomic) int style;
@property (readonly, nonatomic) long long type;
@property (readonly, nonatomic) long long modeOfTransportation;
@property (readonly, nonatomic) id<GEOMapItem> geoMapItem;
@property (readonly, nonatomic) NSString *unknownTypeName;
@property (readonly, nonatomic) double eta;
@property (readonly, nonatomic) NSDate *arrival;
@property (readonly, nonatomic) NSDate *deparature;

+ (id)dateFormatter;
+ (id)durationFormatter;

- (id)mapsURL;
- (void).cxx_destruct;
- (id)description;
- (id)localizedDescription;
- (id)localizedTitle;
- (id)localizedMessage;
- (id)initWithStyle:(int)a0 type:(long long)a1 geoMapItem:(id)a2 unknownTypeName:(id)a3 eta:(double)a4 arrival:(id)a5 departure:(id)a6 modeOfTransportation:(long long)a7;
- (BOOL)isEquivalentToDisplayInfo:(id)a0;

@end
