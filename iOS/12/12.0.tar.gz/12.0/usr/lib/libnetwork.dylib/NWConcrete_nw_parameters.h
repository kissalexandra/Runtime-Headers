@class NSString, NWConcrete_nw_protocol_stack, NSObject;
@protocol OS_dispatch_data, OS_xpc_object, OS_nw_interface, OS_nw_endpoint, OS_nw_context, OS_nw_array;

@interface NWConcrete_nw_parameters : NSObject <OS_nw_parameters> {
    struct { unsigned char proc_uuid[16]; unsigned char e_proc_uuid[16]; unsigned char parent_id[16]; unsigned int traffic_class; int pid; unsigned int uid; struct { unsigned int val[8]; } e_audit_token; int mtu_override; int data_mode; int required_interface_type; int required_interface_subtype; int ecn_mode; int multipath_service; int service_class; int companion_preference; int expired_dns_behavior; unsigned int sleep_keepalive_interval; unsigned char address_family; unsigned char dry_run : 1; unsigned char prohibit_expensive_paths : 1; unsigned char prohibit_roaming : 1; unsigned char no_proxy : 1; unsigned char no_opaque_proxy : 1; unsigned char no_transform : 1; unsigned char fast_open_enabled : 1; unsigned char use_long_outstanding_queries : 1; unsigned char use_awdl : 1; unsigned char use_p2p : 1; unsigned char resolve_ptr : 1; unsigned char indefinite : 1; unsigned char indefinite_set : 1; unsigned char reuse_local_address : 1; unsigned char no_fallback : 1; unsigned char multipath_fallback : 1; unsigned char receive_any_interface : 1; unsigned char enable_tls13 : 1; unsigned char is_probe : 1; unsigned char custom_protocols_only : 1; unsigned char discretionary : 1; unsigned char bundle_id_to_uuid_mapping_failed : 1; unsigned char pid_to_uuid_mapping_failed : 1; unsigned char allow_socket_access : 1; unsigned char local_only : 1; unsigned char server : 1; unsigned char is_fallback : 1; unsigned char desperate_ivan : 1; unsigned char only_primary_requires_type : 1; unsigned char allow_unusable_addresses : 1; unsigned char prefer_no_proxy : 1; unsigned char https_proxy_is_opaque : 1; unsigned char https_proxy_over_tls : 1; unsigned char tls_should_trust_invalid_certificates : 1; unsigned char __pad_bits : 6; unsigned char __pad[2]; } value;
    char *e_bundle_id;
    char *account_id;
    char *url;
    char *sanitized_url;
    NSObject<OS_xpc_object> *tls_session_id;
    NSObject<OS_xpc_object> *proxy_configuration;
    NSObject<OS_xpc_object> *effective_proxy_settings;
    NSObject<OS_nw_endpoint> *local_address;
    NSObject<OS_nw_interface> *required_interface;
    NSObject<OS_nw_array> *transforms;
    NSObject<OS_xpc_object> *prohibited_interface_types;
    NSObject<OS_xpc_object> *prohibited_interface_subtypes;
    NSObject<OS_xpc_object> *prohibited_interfaces;
    NSObject<OS_xpc_object> *prohibited_netagent_domains;
    NSObject<OS_xpc_object> *prohibited_netagent_types;
    NSObject<OS_xpc_object> *prohibited_netagent_uuids;
    NSObject<OS_xpc_object> *required_netagent_domains;
    NSObject<OS_xpc_object> *required_netagent_types;
    NSObject<OS_xpc_object> *required_netagent_uuids;
    NSObject<OS_xpc_object> *preferred_netagent_domains;
    NSObject<OS_xpc_object> *preferred_netagent_types;
    NSObject<OS_xpc_object> *preferred_netagent_uuids;
    NSObject<OS_xpc_object> *avoided_netagent_domains;
    NSObject<OS_xpc_object> *avoided_netagent_types;
    NSObject<OS_xpc_object> *avoided_netagent_uuids;
    NSObject<OS_dispatch_data> *initial_data_payload;
    NWConcrete_nw_protocol_stack *default_stack;
    NSObject<OS_nw_array> *secondary_stacks;
    NSObject<OS_nw_array> *proxy_options;
    NSObject<OS_nw_context> *context;
    NSObject<OS_xpc_object> *metadata;
    char url_hash[9];
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)initWithStack:(id)a0;
- (id)initWithParameters:(id)a0 stripConnected:(BOOL)a1;
- (void).cxx_destruct;
- (void)dealloc;

@end
