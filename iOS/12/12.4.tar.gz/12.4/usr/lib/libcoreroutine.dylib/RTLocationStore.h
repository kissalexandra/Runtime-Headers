@class NSMutableArray, NSObject;
@protocol OS_dispatch_source;

@interface RTLocationStore : RTStore {
    BOOL _flushTimerSuspended;
    NSMutableArray *_locations;
}

@property (readonly) NSObject<OS_dispatch_source> *flushTimer;

- (void)_shutdown;
- (id)initWithPersistenceManager:(id)a0;
- (void)fetchMetricsFromDate:(id)a0 toDate:(id)a1 handler:(id /* block */)a2;
- (void)_storeLocations:(id)a0 handler:(id /* block */)a1;
- (void)storeLocations:(id)a0 handler:(id /* block */)a1;
- (void)fetchLocationsFromDate:(id)a0 toDate:(id)a1 uncertainty:(double)a2 limit:(unsigned long long)a3 handler:(id /* block */)a4;
- (void)_removeLocationsPredating:(id)a0 handler:(id /* block */)a1;
- (void)removeLocationsPredating:(id)a0 handler:(id /* block */)a1;
- (void)_flushCachedLocations:(id /* block */)a0;
- (void)_suspendFlushTimer;
- (void)_resumeFlushTimer;
- (void)_fetchLocationsFromDate:(id)a0 toDate:(id)a1 uncertainty:(double)a2 limit:(unsigned long long)a3 handler:(id /* block */)a4;
- (void)_fetchMetricsFromDate:(id)a0 toDate:(id)a1 handler:(id /* block */)a2;
- (id)init;
- (void).cxx_destruct;

@end
