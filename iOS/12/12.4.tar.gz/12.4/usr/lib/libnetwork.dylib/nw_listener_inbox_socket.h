@interface nw_listener_inbox_socket : nw_listener_inbox {
    void *_source;
    int _sockfd_for_logging_only_do_not_close_or_use;
    unsigned char _ipProtocol;
}

- (id)initWithSocket:(int)a0 parameters:(id)a1 delegate:(id)a2;
- (id)initWithParameters:(id)a0 delegate:(id)a1;
- (id)description;
- (BOOL)cancel;

@end
