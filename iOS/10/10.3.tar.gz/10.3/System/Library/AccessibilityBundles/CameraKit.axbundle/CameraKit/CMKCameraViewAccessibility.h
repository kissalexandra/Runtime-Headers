@interface CMKCameraViewAccessibility : __CMKCameraViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)dealloc;
- (BOOL)accessibilityPerformMagicTap;
- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0 spec:(id)a1;
- (void)viewWillBeDisplayed;
- (void)setCameraMode:(long long)a0;
- (void)_resetZoom;
- (void)_toggleCameraButtonWasPressed:(id)a0;
- (void)_reallyToggleCamera;
- (BOOL)_zoomIsAllowed;
- (void)showZoomSlider;
- (void)cameraControllerModeDidChange:(id)a0;
- (void)cameraControllerSessionDidStart:(id)a0;
- (void)_filterButtonTapped:(id)a0;
- (void)_setReviewingImagePickerCapture:(BOOL)a0 updateUI:(BOOL)a1;
- (void)hideZoomSlider;
- (BOOL)_shouldHideZoomSliderForMode:(long long)a0;
- (void)_accessibilityDetectFaces:(BOOL)a0 controller:(id)a1 completionBlock:(id /* block */)a2;
- (void)_updateOverlayControlsAccessibility;
- (void)_axSetNoCustomActions;
- (void)_axSetAccessibilityCustomActions;
- (BOOL)_accessibilityLockFocus;
- (BOOL)_accessibilityIncreaseExposure;
- (BOOL)_accessibilityDecreaseExposure;
- (void)_axPostAnnoucement:(id)a0;
- (void)_axShowFocusInCenterIfNotShowing;
- (BOOL)_axSetExposureValue:(float)a0;
- (BOOL)accessibilityFaceDetectionEnabled;
- (void)_detectLuminance:(struct opaqueCMSampleBuffer { } *)a0;
- (id)_accessibilityFaceElements;
- (void)_accessibilityLoadAccessibilityInformation;
- (void)_stopCapturingPanorama;

@end
