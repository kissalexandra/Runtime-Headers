@interface RTPredictionExpertFeatureAddonTimeOfDayMO : RTPredictionExpertFeatureAddonMO

@property (retain, nonatomic) id endDateComponents;
@property (retain, nonatomic) id startDateComponents;

+ (id)managedObjectWithStartDateComponents:(id)a0 endDateComponents:(id)a1 inManagedObjectContext:(id)a2;
+ (id)_managedObjectWithStartDateComponents:(id)a0 endDateComponents:(id)a1 inManagedObjectContext:(id)a2;
+ (id)managedObjectWithDateRange:(id)a0 inManagedObjectContext:(id)a1;

@end
