@interface RTIONotificationPort : NSObject

@property (readonly, nonatomic) struct IONotificationPort { } *port;
@property (readonly, nonatomic) struct __CFRunLoopSource { } *runLoopSource;

+ (id)newPort;

- (unsigned int)addMatchingNotificationForServiceName:(id)a0 observer:(id)a1;
- (unsigned int)addInterestNotificationForEntry:(unsigned int)a0 observer:(id)a1;
- (id)init;
- (void)dealloc;

@end
