@interface __MKUIButtonAccessibility_super : UIAccessibilitySafeCategory

@end
