@class RTLocationTagger, RTLearnedLocationManager, RTVisitManager, RTLocationManager;

@interface RTDataProviderLocation : RTDataProviderDuet

@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTLocationTagger *locationTagger;
@property (retain, nonatomic) RTVisitManager *visitManager;

- (id)init;
- (void).cxx_destruct;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)onVisitManagerAvailable:(id)a0;
- (void)onMicroLocationUpdate:(id)a0;
- (void)onLowConfidenceVisitNotification:(id)a0;
- (id)supportedEventClasses;
- (id)supportedEventStreams;
- (void)populateDataProviderWithHandler:(id /* block */)a0;
- (void)fetchCurrentLocationWithHandler:(id /* block */)a0;
- (id)initWithPurgeManager:(id)a0 locationTagger:(id)a1 defaultsManager:(id)a2 locationManager:(id)a3 visitManager:(id)a4 learnedLocationManager:(id)a5;
- (void)_registerForVisitNotifications;
- (void)_unregisterForVisitNotifications;
- (void)_registerForMicroLocationNotifications;
- (void)_unregisterForMicroLocationNotifications;
- (void)_fetchLowConfidenceVisitIncident;
- (void)_processLowConfidenceVisit:(id)a0;
- (void)_processMicroLocationUpdate:(id)a0;

@end
