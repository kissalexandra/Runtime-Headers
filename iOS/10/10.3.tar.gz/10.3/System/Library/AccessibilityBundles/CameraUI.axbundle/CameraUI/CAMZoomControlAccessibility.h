@interface CAMZoomControlAccessibility : __CAMZoomControlAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)continueTrackingWithTouch:(id)a0 withEvent:(id)a1;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;
- (void)accessibilityIncrement;
- (void)accessibilityDecrement;
- (BOOL)accessibilityActivate;
- (double)_axRoundedZoomFactor:(double)a0;
- (double)_axZoomFactor;
- (void)_setAXZoomFactor:(double)a0;

@end
