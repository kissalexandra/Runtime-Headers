@interface MPVolumeSliderAccessibility : __MPVolumeSliderAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_setValue:(float)a0 andSendAction:(BOOL)a1;
- (id)accessibilityLabel;
- (void)_layoutVolumeWarningView;
- (id)_accessibilityHitTest:(struct CGPoint { double x0; double x1; })a0 withEvent:(id)a1;

@end
