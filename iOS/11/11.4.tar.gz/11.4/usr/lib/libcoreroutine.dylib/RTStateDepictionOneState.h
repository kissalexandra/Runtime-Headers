@class NSString, RTStateModelLocation, NSDate, NSMutableArray;
@protocol GEOMapItem;

@interface RTStateDepictionOneState : NSObject <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (retain, nonatomic) RTStateModelLocation *location;
@property (nonatomic) long long type;
@property (nonatomic) long long typeSource;
@property (retain, nonatomic) id<GEOMapItem> mapItem;
@property (nonatomic) long long mapItemSource;
@property (retain, nonatomic) NSDate *geocodeDate;
@property (retain, nonatomic) NSMutableArray *histEntryExit_s;
@property (retain, nonatomic) NSString *customLabel;

- (id)init;
- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (id)description;
- (id)initWithLocation:(id)a0 type:(long long)a1 typeSource:(long long)a2 mapItem:(id)a3 mapItemSource:(long long)a4 customLabel:(id)a5;

@end
