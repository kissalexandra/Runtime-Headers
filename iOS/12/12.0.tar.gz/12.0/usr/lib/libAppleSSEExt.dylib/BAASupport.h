@interface BAASupport : NSObject

+ (void)setBlessedUser:(unsigned int)a0 keybagUUID:(unsigned char[16])a1;
+ (int)getCertificateExpirationDate:(double *)a0;
+ (int)issueNewCertificate;
+ (void)setDelegate:(id)a0;
+ (int)prepare;
+ (void)initialize;

@end
