@interface AXSpeechActionPublicImplementation : __AXSpeechActionPublicImplementation_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)dealloc;
- (id)utterance;
- (void)setUtterance:(id)a0;

@end
