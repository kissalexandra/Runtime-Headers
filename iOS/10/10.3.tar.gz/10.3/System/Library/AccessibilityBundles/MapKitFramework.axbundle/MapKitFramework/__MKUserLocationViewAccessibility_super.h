@interface __MKUserLocationViewAccessibility_super : UIAccessibilitySafeCategory

@end
