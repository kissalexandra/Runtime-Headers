@class NSString, NSObject;
@protocol OS_nw_array, OS_dispatch_data, OS_nw_outbound_message;

@interface NWConcrete_nw_write_request : NSObject <OS_nw_write_request> {
    NWConcrete_nw_write_request *nwr_next;
    id /* block */ completion;
    NSObject<OS_dispatch_data> *data;
    NSObject<OS_nw_outbound_message> *message;
    NSObject<OS_nw_array> *data_array;
    unsigned long long consumed_data_count;
    unsigned char variant;
    unsigned char complete : 1;
    unsigned char idempotent : 1;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
