@interface RTGeoRouteStore : RTStore

- (id)init;
- (void)clearWithHandler:(id /* block */)a0;
- (void)purgePredating:(id)a0 handler:(id /* block */)a1;
- (void)storeGeoRoutes:(id)a0 handler:(id /* block */)a1;
- (void)_fetchGeoRoutesFromLocationOfInterestIdentifier:(id)a0 toLocationOfInterestIdentifier:(id)a1 handler:(id /* block */)a2;
- (void)fetchGeoRoutesFromLocationOfInterestIdentifier:(id)a0 toLocationOfInterestIdentifier:(id)a1 handler:(id /* block */)a2;
- (void)_removeGeoRoutesFromLocationOfInterestIdentifier:(id)a0 toLocationOfInterestIdentifier:(id)a1 handler:(id /* block */)a2;
- (void)removeGeoRoutesFromLocationOfInterestIdentifier:(id)a0 toLocationOfInterestIdentifier:(id)a1 handler:(id /* block */)a2;
- (void)_updateGeoRoutes:(id)a0 fromLocationOfInterestIdentifier:(id)a1 toLocationOfInterestIdentifier:(id)a2 handler:(id /* block */)a3;
- (void)updateGeoRoutes:(id)a0 fromLocationOfInterestIdentifier:(id)a1 toLocationOfInterestIdentifier:(id)a2 handler:(id /* block */)a3;

@end
