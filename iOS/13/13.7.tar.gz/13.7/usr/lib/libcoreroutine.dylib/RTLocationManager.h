@class RTDefaultsManager, CLLocationManager, RTAuthorizationManager, RTPowerAssertion, RTPlatform, CLLocationManagerRoutine, NSString, RTInvocationDispatcher, NSObject, CLLocation, NSMutableArray, RTLocationStore;
@protocol OS_dispatch_source;

@interface RTLocationManager : RTService <CLLocationManagerDelegate, RTPurgable>

@property (retain, nonatomic) CLLocation *lastLocation;
@property (retain, nonatomic) NSMutableArray *currentLocationHandlers;
@property (nonatomic) BOOL updating;
@property (nonatomic) BOOL leechingLocations;
@property (nonatomic) BOOL monitoringLocations;
@property (retain, nonatomic) NSObject<OS_dispatch_source> *stopUpdatingLocationTimer;
@property (retain, nonatomic) RTPowerAssertion *powerAssertion;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) CLLocationManager *locationManager;
@property (retain, nonatomic) CLLocationManagerRoutine *locationManagerRoutine;
@property (nonatomic) BOOL enabled;
@property (nonatomic) BOOL supported;
@property (nonatomic) BOOL locationStoreAvailable;
@property (nonatomic) BOOL persistingLocations;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTLocationStore *locationStore;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (BOOL)supportsNotificationName:(id)a0;

- (id)init;
- (void).cxx_destruct;
- (void)locationManager:(id)a0 didUpdateLocations:(id)a1;
- (void)startUpdatingLocation;
- (void)stopUpdatingLocation;
- (void)locationManager:(id)a0 didChangeAuthorizationStatus:(int)a1;
- (void)_setup;
- (void)_registerNotifications;
- (void)_unregisterNotifications;
- (void)_shutdown;
- (void)_createLocationManager;
- (void)onUserSessionChangeNotification:(id)a0;
- (void)shouldPersistLocations;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)fetchStoredLocationsWithContext:(id)a0 handler:(id /* block */)a1;
- (id)initWithAuthorizationManager:(id)a0 defaultsManager:(id)a1 locationStore:(id)a2 platform:(id)a3 routineLocationManager:(id)a4;
- (void)performPurgeOfType:(long long)a0 referenceDate:(id)a1 completion:(id /* block */)a2;
- (void)fetchStoredLocationsWithOptions:(id)a0 handler:(id /* block */)a1;
- (void)submitHarvestSample:(id)a0 handler:(id /* block */)a1;
- (void)fetchCachedLocationWithHandler:(id /* block */)a0;
- (void)fetchCurrentLocationWithHandler:(id /* block */)a0;
- (void)fetchStoredLocationsCountFromDate:(id)a0 toDate:(id)a1 uncertainty:(double)a2 limit:(unsigned long long)a3 handler:(id /* block */)a4;
- (void)injectLocations:(id)a0 handler:(id /* block */)a1;
- (void)onStopUpdatingLocationTimerExpiry;
- (void)onAuthorizationNotification:(id)a0;
- (void)onLocationStoreNotification:(id)a0;
- (void)shouldLeechLocations;
- (void)shouldMonitorLocations;
- (void)_storeLocations:(id)a0 handler:(id /* block */)a1;
- (void)_fetchStoredLocationsCountFromDate:(id)a0 toDate:(id)a1 uncertainty:(double)a2 limit:(unsigned long long)a3 handler:(id /* block */)a4;
- (void)_fetchStoredLocationsWithContext:(id)a0 handler:(id /* block */)a1;
- (void)_fetchStoredLocationsWithOptions:(id)a0 handler:(id /* block */)a1;
- (void)_removeLocationsPredating:(id)a0 handler:(id /* block */)a1;

@end
