@class NSPort, NSRunLoop;

@interface AXSpeechThread : NSThread {
    NSPort *_machPort;
    NSRunLoop *_threadRunLoop;
}

- (void).cxx_destruct;
- (void)cancel;
- (void)stop;
- (void)main;

@end
