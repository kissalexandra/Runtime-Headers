@interface SBFingerTouch : NSObject {
    struct { struct { int source; unsigned int s; unsigned int ns; } tmFingerOn; struct { int source; unsigned int s; unsigned int ns; } tmFingerOff; BOOL isFingerOffGenuine; int sensorRestartReason; unsigned int ftStateFlags; unsigned int ftCounter; unsigned int matchCounter; unsigned int nCaptureEvents; struct __tag_tsSBCaptureEvent *ce; BOOL initialButtonCondition; unsigned int nButtonEvents; struct __tag_tsSBButtonEvent *be; } _fingerTouch;
    BOOL _touchInLockout;
}

@property BOOL initialButtonState;

- (void)dealloc;
- (BOOL)isComplete;
- (BOOL)isFingerOn;
- (void)discardIncompleteCaptures;
- (const struct { struct { int x0; unsigned int x1; unsigned int x2; } x0; struct { int x0; unsigned int x1; unsigned int x2; } x1; BOOL x2; int x3; unsigned int x4; unsigned int x5; unsigned int x6; unsigned int x7; struct __tag_tsSBCaptureEvent *x8; BOOL x9; unsigned int x10; struct __tag_tsSBButtonEvent *x11; } *)getFinalisedSBFingerTouchStruct;
- (void)inLockout:(BOOL)a0;
- (id)initWithFingerOnTimestamp:(struct { int x0; unsigned int x1; unsigned int x2; })a0 buttonState:(BOOL)a1 preceedingButtonEvents:(struct __tag_tsSBButtonEvent { struct { int x0; unsigned int x1; unsigned int x2; } x0; BOOL x1; int x2; struct __tag_tsSBButtonEvent *x3; } *)a2 buttonEventCount:(unsigned int)a3;
- (void)fingerOffTimestamp:(struct { int x0; unsigned int x1; unsigned int x2; })a0;
- (BOOL)captureBufferInfoImageForProcessingTimestamp:(struct { int x0; unsigned int x1; unsigned int x2; })a0;
- (BOOL)captureRejected;
- (BOOL)captureRejectedAfterImageWasAccepted;
- (BOOL)captureImageProcessingResult:(struct { short x0; unsigned int x1; unsigned char x2; unsigned char x3; unsigned char x4; struct { unsigned char x0; unsigned char x1; unsigned char x2; unsigned char x3; unsigned char x4; unsigned int x5; unsigned int x6; unsigned char x7; unsigned char x8; float x9; float x10; float x11; unsigned int x12; unsigned int x13; float x14[5]; unsigned char x15; unsigned char x16; unsigned char x17; unsigned char x18; unsigned long long x19; unsigned int x20; unsigned char x21; unsigned char x22; unsigned char x23; } x5; unsigned char x6; int x7; unsigned char x8; int x9; unsigned long long x10; unsigned long long x11; unsigned int x12; } *)a0;
- (BOOL)enrollProgressInfo:(struct { unsigned int x0; unsigned short x1; unsigned int x2; struct { short x0; short x1; short x2; short x3; short x4; short x5; short x6; unsigned char x7[16]; unsigned char x8[16]; short x9; struct { struct { short x0; short x1; short x2; } x0; short x1; short x2; } x10[300]; short x11; short x12; short x13; short x14; short x15; short x16; } x3; unsigned int x4; struct { unsigned int x0; unsigned char x1[16]; } x5; struct { unsigned char x0; unsigned char x1; unsigned char x2; unsigned char x3; unsigned char x4; unsigned int x5; unsigned int x6; unsigned char x7; unsigned char x8; float x9; float x10; float x11; unsigned int x12; unsigned int x13; float x14[5]; unsigned char x15; unsigned char x16; unsigned char x17; unsigned char x18; unsigned long long x19; unsigned int x20; unsigned char x21; unsigned char x22; unsigned char x23; } x6; struct { short x0; short x1; short x2; short x3; short x4; short x5; unsigned char x6; unsigned char x7[1]; struct { short x0; short x1; short x2; short x3; struct { short x0; short x1; short x2; short x3; } x4; } x8; unsigned char x9; unsigned char x10; } x7; } *)a0;
- (void)buttonEventTimestamp:(struct { int x0; unsigned int x1; unsigned int x2; })a0 state:(BOOL)a1 force:(unsigned int)a2;
- (BOOL)matchResult:(id)a0 withDetails:(id)a1 timestamp:(struct { int x0; unsigned int x1; unsigned int x2; })a2 templates:(struct { unsigned int x0[5]; unsigned char x1[5][5][16]; unsigned int x2[5]; } *)a3;
- (void)captureBufferInfoDataReady:(struct { int x0; unsigned int x1; unsigned int x2; })a0 sensorStatus:(unsigned char)a1;
- (void)failedCapture:(struct { int x0; unsigned int x1; unsigned int x2; })a0 statusData:(id)a1;
- (void)markIncomplete;
- (void)sensorRecoveryReason:(int)a0;
- (BOOL)isCaptureEventComplete:(struct __tag_tsSBCaptureEvent { struct { int x0; unsigned int x1; unsigned int x2; } x0; unsigned char x1; union { struct { unsigned char x0; unsigned char x1; unsigned char x2; unsigned char x3; } x0; struct { unsigned char x0; unsigned char x1; unsigned char x2; unsigned char x3; } x1; struct { struct { int x0; unsigned int x1; unsigned int x2; } x0; int x1; } x2; } x2; unsigned int x3; struct { int x0; unsigned int x1; unsigned int x2; } x4; struct { int x0; unsigned int x1; unsigned int x2; } x5; int x6; struct tag_tsImageDeblurringInfo *x7; int x8; union { struct { unsigned char x0[16]; unsigned int x1; short x2; short x3; short x4; short x5; short x6; short x7; struct { unsigned int x0; BOOL x1; short x2; short x3; short x4; short x5; BOOL x6; BOOL x7; BOOL x8; } x8; int x9; } x0; struct { struct { unsigned int x0[5]; unsigned char x1[5][5][16]; unsigned int x2[5]; } x0; struct { int x0; unsigned int x1; unsigned int x2; } x1; struct { int x0; unsigned int x1; unsigned int x2; } x2; int x3; struct { unsigned int x0; BOOL x1; BOOL x2; short x3; short x4; int x5; int x6; short x7; struct { short x0; short x1; short x2; } x8; short x9; short x10; short x11; short x12; } x4; unsigned char x5[16]; unsigned int x6; } x1; } x9; struct __tag_tsSBCaptureEvent *x10; } *)a0;

@end
