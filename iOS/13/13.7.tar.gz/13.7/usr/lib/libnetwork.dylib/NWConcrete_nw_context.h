@class NSString, NSObject;
@protocol OS_dispatch_workloop;

@interface NWConcrete_nw_context : NSObject <OS_nw_context> {
    NSObject<OS_dispatch_workloop> *workloop;
    char *identifier;
    struct nw_context_cache { struct _cache_entries_head { struct nw_association_cache_entry *x0; struct nw_association_cache_entry **x1; } x0; struct _idle_cache_entries_head { struct nw_association_cache_entry *x0; struct nw_association_cache_entry **x1; } x1; struct nw_hash_table *x2; struct nw_hash_table *x3; struct nw_hash_table *x4; void *x5; unsigned int x6; unsigned int x7; } *cache;
    struct nw_context_globals { void *x0; struct nw_timer_list_head { struct nw_timer_entry *x0; struct nw_timer_entry **x1; } x1; struct nw_hash_table *x2; unsigned long long x3; struct os_unfair_lock_s { unsigned int x0; } x4; struct os_unfair_lock_s { unsigned int x0; } x5; struct os_unfair_lock_s { unsigned int x0; } x6; struct nw_hash_table *x7; void *x8; void *x9; struct nw_mem_buffer_manager *x10; struct nw_mem_buffer_manager *x11; struct nw_mem_buffer_manager *x12; struct nw_mem_buffer_manager *x13; struct nw_mem_buffer_manager *x14; } *globals;
    NWConcrete_nw_context *isolated_context;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } activate_lock;
    unsigned int max_cache_entries;
    unsigned int target_cache_entries;
    unsigned int max_idle_cache_entries;
    int scheduling_mode;
    int privacy_level;
    unsigned char isolate_protocol_stack : 1;
    unsigned char isolate_protocol_cache : 1;
    unsigned char is_implicit : 1;
    unsigned char is_isolated_context : 1;
    unsigned char activated : 1;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)dealloc;
- (id)redactedDescription;
- (void).cxx_destruct;
- (id)initWithIdentifier:(const char *)a0;

@end
