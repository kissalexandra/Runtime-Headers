@class NSMutableArray;

@interface ADStorage : NSObject {
    NSMutableArray *_eventList;
}

+ (id)storage;

- (id)init;
- (void)dealloc;
- (void)clear;
- (void)addEvent:(id)a0;
- (void)pushToAggregateDictionary:(long long)a0 useCase:(int)a1 prearmedApplePay:(BOOL)a2;

@end
