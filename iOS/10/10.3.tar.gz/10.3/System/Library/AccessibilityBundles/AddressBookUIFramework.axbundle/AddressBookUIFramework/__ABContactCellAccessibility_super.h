@interface __ABContactCellAccessibility_super : UIAccessibilitySafeCategory

@end
