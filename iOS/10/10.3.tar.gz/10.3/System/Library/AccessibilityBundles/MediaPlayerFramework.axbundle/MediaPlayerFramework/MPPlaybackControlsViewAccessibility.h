@interface MPPlaybackControlsViewAccessibility : __MPPlaybackControlsViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_shuffleButton:(id)a0;

@end
