@interface MKPlaceInlineMapViewControllerAccessibility : __MKPlaceInlineMapViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_updateMap;
- (void)_axUpdateMapContentView;
- (void)_accessibilityLoadAccessibilityInformation;

@end
