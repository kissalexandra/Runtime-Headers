@class CLLocationManager, RTAuthorizationManager, RTPowerAssertion, RTPlatform, CLLocationManagerRoutine, NSString, RTInvocationDispatcher, NSObject, CLLocation, NSMutableArray, RTLocationStore;
@protocol OS_dispatch_source;

@interface RTLocationManager : RTService <CLLocationManagerRoutineDelegate, RTPurgable>

@property (retain, nonatomic) CLLocation *lastLocation;
@property (retain, nonatomic) NSMutableArray *currentLocationHandlers;
@property (retain, nonatomic) NSObject<OS_dispatch_source> *stopUpdatingLocationTimer;
@property (nonatomic) BOOL updating;
@property (nonatomic) BOOL leechingLocations;
@property (nonatomic) BOOL monitoringLocations;
@property (retain, nonatomic) RTPowerAssertion *powerAssertion;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) CLLocationManager *locationManager;
@property (retain, nonatomic) CLLocationManagerRoutine *locationManagerRoutine;
@property (nonatomic) BOOL enabled;
@property (nonatomic) BOOL supported;
@property (nonatomic) BOOL locationStoreAvailable;
@property (nonatomic) BOOL persistingLocations;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTLocationStore *locationStore;
@property (retain, nonatomic) RTPlatform *platform;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (BOOL)supportsNotificationName:(id)a0;
+ (id)allocWithZone:(struct _NSZone { } *)a0;

- (void)startUpdatingLocation;
- (void)stopUpdatingLocation;
- (void)locationManager:(id)a0 didUpdateLocations:(id)a1;
- (void)locationManager:(id)a0 didChangeAuthorizationStatus:(int)a1;
- (void)_setup;
- (void)requestCurrentMicroLocation;
- (void)fetchCurrentLocationWithHandler:(id /* block */)a0;
- (void)onUserSessionChangeNotification:(id)a0;
- (void)_shutdown;
- (void)shouldPersistLocations;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)fetchPredictedApplicationsAtLocation:(id)a0 handler:(id /* block */)a1;
- (id)initWithAuthorizationManager:(id)a0 locationStore:(id)a1 platform:(id)a2 routineLocationManager:(id)a3;
- (void)purgeManager:(id)a0 performPurgeOfType:(long long)a1 completion:(id /* block */)a2;
- (void)fetchStoredLocationsFromDate:(id)a0 toDate:(id)a1 uncertainty:(double)a2 limit:(unsigned long long)a3 handler:(id /* block */)a4;
- (void)submitHarvestSample:(id)a0 handler:(id /* block */)a1;
- (void)stopUpdatingMicroLocation;
- (void)_startUpdatingMicroLocationForLocationOfInterestWithIdentifier:(id)a0;
- (void)_stopUpdatingMicroLocation;
- (void)_requestCurrentMicroLocation;
- (void)_fetchPredictedApplicationsAtLocation:(id)a0 handler:(id /* block */)a1;
- (void)fetchCachedLocationWithHandler:(id /* block */)a0;
- (void)injectLocations:(id)a0 handler:(id /* block */)a1;
- (void)onStopUpdatingLocationTimerExpiry;
- (void)onAuthorizationNotification:(id)a0;
- (void)onLocationStoreNotification:(id)a0;
- (void)performBlockOnMainThreadAndWait:(id /* block */)a0;
- (void)_createLocationManager;
- (void)shouldLeechLocations;
- (void)shouldMonitorLocations;
- (void)_storeLocations:(id)a0 handler:(id /* block */)a1;
- (void)_fetchStoredLocationsFromDate:(id)a0 toDate:(id)a1 uncertainty:(double)a2 limit:(unsigned long long)a3 handler:(id /* block */)a4;
- (void)_removeLocationsPredating:(id)a0 handler:(id /* block */)a1;
- (void)startUpdatingMicroLocationForLocationOfInterestWithIdentifier:(id)a0;
- (id)init;
- (void)dealloc;
- (void).cxx_destruct;
- (void)_registerNotifications;
- (void)_unregisterNotifications;

@end
