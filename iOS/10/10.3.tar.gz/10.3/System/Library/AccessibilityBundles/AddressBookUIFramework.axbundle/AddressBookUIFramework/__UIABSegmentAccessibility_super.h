@interface __UIABSegmentAccessibility_super : UIAccessibilitySafeCategory

@end
