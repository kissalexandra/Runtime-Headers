@protocol SETransceiver;

@interface TransceiverWrapper : NSObject <SETransceiver> {
    id<SETransceiver> _transceiver;
    struct _CircularBuffer { char *x0; char *x1; char *x2; unsigned long long x3; unsigned char x4[0]; } *_circbuff;
    unsigned char _circBuffStorage[4096];
}

+ (id)withTransceiver:(id)a0;

- (id)transceive:(id)a0 error:(id *)a1;
- (id)transceiveAndCheckSW:(id)a0 error:(id *)a1;
- (BOOL)applyScript:(id)a0 ignoreSW:(BOOL)a1 error:(id *)a2;
- (id)transceiveBytesAndCheckSW:(const char *)a0 length:(unsigned long long)a1 error:(id *)a2;
- (id)transceiveBytesAndCheckSW:(const char *)a0 length:(unsigned long long)a1 inArray:(id)a2 error:(id *)a3;
- (id)initWithTransceiver:(id)a0;
- (id)transceiveAndCheckSW:(id)a0 inArray:(id)a1 error:(id *)a2;
- (void)dumpAPDUs:(id /* block */)a0;
- (BOOL)applyScript:(id)a0 error:(id *)a1;

@end
