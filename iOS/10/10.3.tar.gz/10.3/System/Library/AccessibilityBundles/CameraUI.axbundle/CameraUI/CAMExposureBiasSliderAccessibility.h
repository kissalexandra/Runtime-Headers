@interface CAMExposureBiasSliderAccessibility : __CAMExposureBiasSliderAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityValue;
- (BOOL)isAccessibilityElement;
- (void)setExposureBiasValue:(float)a0;

@end
