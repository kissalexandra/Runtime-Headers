@class NSString, NSArray, RTMapItemMO, NSNumber;

@interface RTAddressMO : RTCloudManagedObject

@property (copy, nonatomic) NSString *subThoroughfare;
@property (copy, nonatomic) NSString *thoroughfare;
@property (copy, nonatomic) NSString *subLocality;
@property (copy, nonatomic) NSString *locality;
@property (copy, nonatomic) NSString *subAdministrativeArea;
@property (copy, nonatomic) NSString *administrativeArea;
@property (copy, nonatomic) NSString *administrativeAreaCode;
@property (copy, nonatomic) NSString *postalCode;
@property (copy, nonatomic) NSString *country;
@property (copy, nonatomic) NSString *countryCode;
@property (copy, nonatomic) NSString *inlandWater;
@property (copy, nonatomic) NSString *ocean;
@property (retain, nonatomic) NSArray *areasOfInterest;
@property (copy, nonatomic) NSNumber *island;
@property (retain, nonatomic) RTMapItemMO *mapItem;

+ (id)fetchRequest;
+ (id)managedObjectWithAddress:(id)a0 managedObject:(id)a1 inManagedObjectContext:(id)a2;
+ (id)managedObjectWithAddress:(id)a0 inManagedObjectContext:(id)a1;

@end
