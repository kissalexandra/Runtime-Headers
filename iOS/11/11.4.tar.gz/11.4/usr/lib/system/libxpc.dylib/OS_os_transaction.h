@interface OS_os_transaction : OS_object

- (void)_dispose;
- (id)init;
- (id)description;

@end
