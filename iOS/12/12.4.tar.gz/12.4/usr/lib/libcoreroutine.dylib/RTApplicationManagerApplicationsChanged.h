@class NSSet;

@interface RTApplicationManagerApplicationsChanged : RTNotification

@property (readonly, copy, nonatomic) NSSet *installedApplicationBundleIdentifiers;
@property (readonly, copy, nonatomic) NSSet *uninstalledApplicationBundleIdentifiers;

- (id)initWithInstalledApplicationBundleIdentifiers:(id)a0 uninstalledApplicationBundleIdentifiers:(id)a1;
- (void).cxx_destruct;

@end
