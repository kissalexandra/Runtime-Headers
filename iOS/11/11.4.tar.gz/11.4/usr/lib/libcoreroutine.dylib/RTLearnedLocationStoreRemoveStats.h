@class NSNumber, NSArray;

@interface RTLearnedLocationStoreRemoveStats : NSObject

@property (readonly) unsigned long long type;
@property (readonly) NSNumber *ageOfOldestRecordInDays;
@property (readonly) NSArray *agesInDays;

+ (unsigned long long)typeFromEntityName:(id)a0;

- (void).cxx_destruct;
- (id)initWithType:(unsigned long long)a0 ageOfOldestRecord:(id)a1 ages:(id)a2;

@end
