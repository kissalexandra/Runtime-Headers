@class NSUUID, NSString, NSOrderedSet, NSDate;

@interface RTRouteMO : NSManagedObject

@property (retain, nonatomic) NSUUID *identifier;
@property (copy, nonatomic) NSDate *start;
@property (copy, nonatomic) NSDate *stop;
@property (retain, nonatomic) NSUUID *originLocationOfInterestIdentifier;
@property (retain, nonatomic) NSUUID *destinationLocationOfInterestIdentifier;
@property (retain, nonatomic) NSUUID *originVisitIdentifier;
@property (retain, nonatomic) NSUUID *destinationVisitIdentifier;
@property (copy, nonatomic) NSString *name;
@property (retain, nonatomic) NSOrderedSet *locations;

+ (id)fetchRequest;
+ (id)managedObjectWithRoute:(id)a0 inManagedObjectContext:(id)a1;

@end
