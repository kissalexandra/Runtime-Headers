@class NSString, NSObject;
@protocol OS_nw_read_request, OS_nw_write_request, OS_dispatch_queue, OS_nw_endpoint, OS_dispatch_data, OS_nw_fd_wrapper, OS_nw_channel, OS_xpc_object, OS_nw_path;

@interface NWConcrete_nw_endpoint_flow : NSObject <OS_nw_endpoint_flow> {
    NSObject<OS_nw_path> *connected_path;
    void *internally_retained_object;
    unsigned char initialized_protocol : 1;
    unsigned char setup_protocols : 1;
    unsigned char started_protocols : 1;
    unsigned char is_viable : 1;
    unsigned char has_connected : 1;
    unsigned char initial_payload_sent : 1;
    unsigned char assigned_initial_writes : 1;
    unsigned char is_channel : 1;
    unsigned char is_multipath : 1;
    unsigned char multipath_nat64_query_outstanding : 1;
    unsigned char servicing_reads : 1;
    unsigned char input_finished : 1;
    unsigned char custom_protocols_only : 1;
    unsigned char is_flow_divert : 1;
    NWConcrete_nw_endpoint_flow *clone_from_flow;
    struct nw_protocol_identifier { char name[32]; int level; int mapping; } protocol_identifier;
    struct nw_protocol_callbacks { void /* function */ *add_input_handler; void /* function */ *remove_input_handler; void /* function */ *replace_input_handler; void /* function */ *connect; void /* function */ *disconnect; void /* function */ *connected; void /* function */ *disconnected; void /* function */ *error; void /* function */ *input_available; void /* function */ *output_available; void /* function */ *get_input_frames; void /* function */ *get_output_frames; void /* function */ *finalize_output_frames; void /* function */ *link_state; void /* function */ *get_parameters; void /* function */ *get_path; void /* function */ *get_local_endpoint; void /* function */ *get_remote_endpoint; void /* function */ *register_notification; void /* function */ *unregister_notification; void /* function */ *notify; void /* function */ *updated_path; void /* function */ *supports_external_data; void /* function */ *input_finished; void /* function */ *output_finished; void /* function */ *get_output_local_endpoint; void /* function */ *get_output_interface; void /* function */ *waiting_for_output; void /* function */ *copy_info; void /* function */ *add_listen_handler; void /* function */ *remove_listen_handler; void /* function */ *supports_message_frames; void /* function */ *reset; void /* function */ *input_flush; } protocol_callbacks;
    struct nw_protocol { unsigned char flow_id[16]; struct nw_protocol_identifier *identifier; struct nw_protocol_callbacks *callbacks; struct nw_protocol *output_handler; void *handle; struct nw_protocol *default_input_handler; void *output_handler_context; } protocol_handler;
    struct nw_protocol { unsigned char x0[16]; struct nw_protocol_identifier *x1; struct nw_protocol_callbacks *x2; struct nw_protocol *x3; void *x4; struct nw_protocol *x5; void *x6; } *transport_protocol;
    struct nw_protocol { unsigned char x0[16]; struct nw_protocol_identifier *x1; struct nw_protocol_callbacks *x2; struct nw_protocol *x3; void *x4; struct nw_protocol *x5; void *x6; } *tls_protocol;
    struct nw_protocol_identifier { char x0[32]; int x1; int x2; } *ip_protocol_identifier;
    struct tcp_info { unsigned char x0; unsigned char x1; unsigned char x2; unsigned char x3; unsigned int x4; unsigned int x5; unsigned int x6; unsigned int x7; unsigned int x8; unsigned int x9; unsigned int x10; unsigned int x11; unsigned int x12; unsigned int x13; unsigned int x14; unsigned int x15; unsigned int x16; unsigned int x17; int x18; unsigned int x19; unsigned long long x20; unsigned long long x21; unsigned long long x22; unsigned long long x23; unsigned long long x24; unsigned long long x25; unsigned long long x26; unsigned long long x27; unsigned long long x28; unsigned char x29; unsigned char x30; unsigned short x31; unsigned long long x32; unsigned long long x33; unsigned long long x34; unsigned long long x35; unsigned long long x36; unsigned long long x37; unsigned long long x38; unsigned long long x39; unsigned long long x40; unsigned long long x41; unsigned long long x42; unsigned long long x43; struct tcp_conn_status { unsigned char x0 : 1; unsigned char x1 : 1; unsigned char x2 : 1; unsigned char x3 : 1; } x44; unsigned char x45 : 1; unsigned char x46 : 1; unsigned char x47 : 1; unsigned char x48 : 1; unsigned char x49 : 1; unsigned char x50 : 1; unsigned char x51 : 1; unsigned char x52 : 1; unsigned char x53 : 1; unsigned char x54 : 1; unsigned char x55 : 1; unsigned char x56 : 1; unsigned char x57 : 1; unsigned char x58 : 1; unsigned char x59 : 1; unsigned char x60 : 1; unsigned char x61 : 1; unsigned char x62 : 1; unsigned char x63 : 1; unsigned char x64 : 1; unsigned char x65 : 1; unsigned char x66 : 1; unsigned char x67 : 1; unsigned char x68 : 1; unsigned char x69 : 1; unsigned char x70 : 1; unsigned char x71 : 1; unsigned char x72 : 1; unsigned int x73; unsigned int x74; unsigned int x75; unsigned int x76; unsigned int x77; unsigned int x78; unsigned int x79; unsigned int x80; unsigned int x81; unsigned long long x82; } *tcp_info;
    struct tcp_connection_info { unsigned char x0; unsigned char x1; unsigned char x2; unsigned char x3; unsigned int x4; unsigned int x5; unsigned int x6; unsigned int x7; unsigned int x8; unsigned int x9; unsigned int x10; unsigned int x11; unsigned int x12; unsigned int x13; unsigned int x14; unsigned int x15; unsigned char x16 : 1; unsigned char x17 : 1; unsigned char x18 : 1; unsigned char x19 : 1; unsigned char x20 : 1; unsigned char x21 : 1; unsigned char x22 : 1; unsigned char x23 : 1; unsigned char x24 : 1; unsigned char x25 : 1; unsigned char x26 : 1; unsigned char x27 : 1; unsigned char x28 : 1; unsigned char x29 : 1; unsigned char x30 : 1; unsigned int x31 : 17; unsigned long long x32; unsigned long long x33; unsigned long long x34; unsigned long long x35; unsigned long long x36; unsigned long long x37; unsigned long long x38; } *tcp_connection_info;
    NSObject<OS_nw_write_request> *write_requests;
    NSObject<OS_nw_read_request> *read_requests;
    NSObject<OS_dispatch_queue> *client_queue;
    id /* block */ read_close_handler;
    id /* block */ write_close_handler;
    struct __CFError { } *last_error;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } lock;
    NSObject<OS_nw_fd_wrapper> *connected_fd_wrapper;
    unsigned int pending_write_bytes;
    int pre_connected_fd;
    NSObject<OS_nw_channel> *channel;
    struct nw_protocol { unsigned char x0[16]; struct nw_protocol_identifier *x1; struct nw_protocol_callbacks *x2; struct nw_protocol *x3; void *x4; struct nw_protocol *x5; void *x6; } *socket_protocol;
    struct _DNSServiceRef_t { } *sleep_proxy_ref;
    NSObject<OS_xpc_object> *flow_divert_token;
    NSObject<OS_nw_endpoint> *flow_divert_endpoint;
    unsigned char keepalive_event_enabled : 1;
    unsigned long long first_keepalive_time;
    unsigned int keepalive_count;
    unsigned int configured_keepalive_count;
    unsigned int configured_keepalive_interval;
    id /* block */ adaptive_read_event_handler;
    id /* block */ adaptive_write_event_handler;
    id /* block */ keepalive_event_handler;
    NSObject<OS_dispatch_data> *final_data;
    int final_error;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)cancelWithHandler:(id)a0 forced:(BOOL)a1;
- (void)updatePathWithHandler:(id)a0;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)startWithHandler:(id)a0;

@end
