@protocol RTPersistenceContextDelegate;

@interface RTPersistenceContext : NSManagedObjectContext

@property (weak) id<RTPersistenceContextDelegate> delegate;
@property (nonatomic) long long mirroringQualityOfService;

- (void).cxx_destruct;
- (BOOL)save:(id *)a0;
- (id)executeRequest:(id)a0 error:(id *)a1;
- (unsigned long long)countForFetchRequest:(id)a0 error:(id *)a1;
- (id)executeFetchRequest:(id)a0 error:(id *)a1;
- (BOOL)_processError:(inout id *)a0;

@end
