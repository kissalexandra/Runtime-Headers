@class NSMutableDictionary, RTHintManager, RTLocationAwarenessManager, NSObject, RTMotionActivityManager, RTDefaultsManager, RTVisitFeedBuffer, RTPlatform, RTTimerManager, RTMetricManager, RTLearnedLocationManager, RTVisitMonitorState, RTLocationManager, RTTimer;
@protocol OS_dispatch_queue, RTVisitMonitorDelegate;

@interface RTVisitMonitor : NSObject {
    RTVisitFeedBuffer *_feedBuffer;
    RTTimer *_feedBufferTimer;
}

@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTHintManager *hintManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTLocationAwarenessManager *locationAwarenessManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTMotionActivityManager *motionActivityManager;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) RTTimerManager *timerManager;
@property (retain, nonatomic) RTVisitMonitorState *state;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (nonatomic) BOOL monitoringVisitIncidents;
@property (nonatomic) BOOL monitoringLeechedVisitIncidents;
@property (nonatomic) BOOL monitoringLowConfidenceVisitIncidents;
@property (nonatomic) unsigned long long feedBufferReferenceCounter;
@property (nonatomic) unsigned long long lowConfidencePipelineReferenceCounter;
@property (nonatomic) unsigned long long highConfidencePipelineReferenceCounter;
@property (retain, nonatomic) NSMutableDictionary *pipelines;
@property (weak, nonatomic) id<RTVisitMonitorDelegate> delegate;

+ (id)hyperParameterForPipelineType:(unsigned long long)a0;
+ (id)bucketLocations:(id)a0 interval:(double)a1;
+ (double)LocationHeartbeatWhileAwake;

- (id)init;
- (void).cxx_destruct;
- (void)shutdown;
- (void)fetchVisitsFromDate:(id)a0 toDate:(id)a1 handler:(id /* block */)a2;
- (id)initWithDefaultsManager:(id)a0 hintManager:(id)a1 learnedLocationManager:(id)a2 locationAwarenessManager:(id)a3 locationManager:(id)a4 metricManager:(id)a5 motionActivityManager:(id)a6 platform:(id)a7 queue:(id)a8 state:(id)a9 timerManager:(id)a10;
- (id)_createPipelineWithType:(unsigned long long)a0 name:(id)a1 lastVisit:(id)a2;
- (void)_startFeedBuffer;
- (void)_stopFeedBuffer;
- (id)_configurationForPipelineType:(unsigned long long)a0;
- (id)_moduleWithName:(id)a0 pipelineType:(unsigned long long)a1 hyperParameter:(id)a2;
- (id)_modulesForPipelineType:(unsigned long long)a0 hyperParameter:(id)a1;
- (void)_bootstrapPipeline:(id)a0 handler:(id /* block */)a1;
- (void)_processRealtimeVisits:(id)a0 pipeline:(id)a1;
- (void)_batchProcess:(id)a0 fromDate:(id)a1 toDate:(id)a2 handler:(id /* block */)a3;
- (void)_setupRealtimePipelineWithType:(unsigned long long)a0 handler:(id /* block */)a1;
- (void)onLeechedLocationsNotification:(id)a0;
- (void)_processLeechedLocations:(id)a0;
- (void)_processMatureLocations;
- (void)_startFeedBufferTimer;
- (void)handleVisitIncident:(id)a0;
- (void)handleLeechedVisitIncident:(id)a0;
- (void)logHintSourceUsageWithLocation:(id)a0;
- (void)handleLowConfidenceVisitIncident:(id)a0;
- (id)initWithDefaultsManager:(id)a0 hintManager:(id)a1 learnedLocationManager:(id)a2 locationAwarenessManager:(id)a3 locationManager:(id)a4 metricManager:(id)a5 motionActivityManager:(id)a6 platform:(id)a7 queue:(id)a8 state:(id)a9;
- (void)fetchVisitIncidentsFromLocations:(id)a0 handler:(id /* block */)a1;
- (void)startMonitoringVisitIncidents;
- (void)stopMonitoringVisitIncidents;
- (void)startMonitoringLeechedVisitIncidents;
- (void)stopMonitoringLeechedVisitIncidents;
- (void)startMonitoringLowConfidenceVisitIncidents;
- (void)stopMonitoringLowConfidenceVisitIncidents;
- (void)fetchVisitMonitorStatusWithHandler:(id /* block */)a0;
- (void)fetchVisitMonitorState:(id /* block */)a0;

@end
