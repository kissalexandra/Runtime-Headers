@interface __MFComposeBodyFieldAccessibility_super : UIAccessibilitySafeCategory

@end
