@class BBDataProviderProxy, NSString, BBDataProviderConnection, NSObject;
@protocol OS_dispatch_queue;

@interface RTBBDataProvider : NSObject <BBRemoteDataProvider> {
    NSObject<OS_dispatch_queue> *_queue;
    BBDataProviderConnection *_connection;
    BBDataProviderProxy *_proxy;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (id)sortDescriptors;
- (id)sectionIdentifier;
- (id)defaultSectionInfo;
- (id)sectionDisplayName;
- (id)sectionParameters;
- (void)postNotificationWithTitle:(id)a0 message:(id)a1 actionBundleId:(id)a2;

@end
