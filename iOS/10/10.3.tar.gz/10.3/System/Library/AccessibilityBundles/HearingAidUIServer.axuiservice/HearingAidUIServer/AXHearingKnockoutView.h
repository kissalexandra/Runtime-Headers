@class _UIBackdropView;

@interface AXHearingKnockoutView : UIView

@property (nonatomic) _UIBackdropView *backdropView;

+ (id)knockoutViewWithBackdrop:(id)a0;

- (void)didMoveToSuperview;

@end
