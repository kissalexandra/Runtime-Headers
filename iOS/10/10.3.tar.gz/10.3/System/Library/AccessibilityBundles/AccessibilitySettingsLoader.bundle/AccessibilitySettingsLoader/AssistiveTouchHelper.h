@interface AssistiveTouchHelper : NSObject

+ (void)initializeMonitoring;

- (id)init;
- (void)enable;
- (void)_sendKeyboardStatusUpdate:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0;
- (void)installMediaCategoriesAndValidate;
- (void)installiPodUICategoriesAndValidate;
- (void)installKeyboardListener;
- (void)installMediaControlsListener;
- (void)_handleMediaPlaybackEnded;

@end
