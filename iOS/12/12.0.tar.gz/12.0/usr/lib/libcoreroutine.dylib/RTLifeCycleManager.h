@class NSMutableDictionary, NSMutableSet, NSMutableArray, NSObject;
@protocol OS_dispatch_queue;

@interface RTLifeCycleManager : NSObject

@property (retain, nonatomic) NSMutableArray *signals;
@property (retain, nonatomic) NSMutableDictionary *transactions;
@property (retain, nonatomic) NSMutableDictionary *listeners;
@property (retain, nonatomic) NSMutableSet *services;
@property (nonatomic) BOOL activeTransaction;
@property (nonatomic) BOOL exitWhenNoTransactions;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;

+ (id)sharedInstance;

- (void)exit;
- (id)keyForObject:(id)a0;
- (void)addService:(id)a0;
- (id)createSourceForSignal:(int)a0 withBlock:(id /* block */)a1;
- (void)processTransactions;
- (void)_exit;
- (void)incrementTransactionsForObject:(id)a0;
- (void)decrementTransactionsForObject:(id)a0;
- (void)exitWithDelay:(double)a0;
- (id)init;
- (void).cxx_destruct;
- (void)start;
- (void)dealloc;
- (void)_start;

@end
