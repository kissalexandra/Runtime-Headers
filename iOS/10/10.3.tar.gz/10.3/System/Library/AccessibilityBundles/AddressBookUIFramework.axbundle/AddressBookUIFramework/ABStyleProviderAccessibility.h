@interface ABStyleProviderAccessibility : __ABStyleProviderAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)cardCellFacebookBadge;

@end
