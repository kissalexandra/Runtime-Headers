@class NSArray, NSString, NSObject, RTMapAccess;
@protocol OS_dispatch_queue;

@interface RTRouteFinderViterbi : NSObject <RTRouteFinderProtocol>

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (copy, nonatomic) id /* block */ handler;
@property (retain, nonatomic) NSArray *evaluationBoard;
@property (retain, nonatomic) RTMapAccess *mapAccess;
@property (nonatomic) BOOL busy;
@property (nonatomic) unsigned long long shortestPathRequestBudget;
@property (nonatomic) unsigned long long totalShortestPathRequests;
@property int metricNumberOfFilteredLocations;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void).cxx_destruct;
- (void)findRouteForWaypoints:(id)a0 routeHandler:(id /* block */)a1;
- (id)initWithQueue:(id)a0 mapAccess:(id)a1;
- (void)findRouteForWayPoints:(id)a0 originRoad:(id)a1 destinationRoad:(id)a2 routeHandler:(id /* block */)a3;
- (void)_findRouteForWayPoints:(id)a0 originRoad:(id)a1 destinationRoad:(id)a2 routeHandler:(id /* block */)a3;
- (BOOL)_sanityCheckOnWaypoints:(id)a0 originRoad:(id)a1 destinationRoad:(id)a2 error:(id *)a3;
- (id)_buildEvaluationBoardForWaypoints:(id)a0 originRoad:(id)a1 destinationRoad:(id)a2;
- (void)_processWaypointIndex:(long long)a0;
- (void)_fetchRoadsForWaypointIndex:(long long)a0;
- (void)_evaluateScoreForWaypointIndex:(long long)a0;
- (void)_evaluateScoreForWaypointIndex:(long long)a0 roadItemIndex:(long long)a1;
- (void)_fetchTransitionForWaypointIndex:(long long)a0 roadItemIndex:(long long)a1 handler:(id /* block */)a2;
- (double)_emissionCostForWaypointIndex:(long long)a0 roadItemIndex:(long long)a1;
- (id)_extractBestRoute;
- (void)_callHandlerWithRoute:(id)a0 error:(id)a1;

@end
