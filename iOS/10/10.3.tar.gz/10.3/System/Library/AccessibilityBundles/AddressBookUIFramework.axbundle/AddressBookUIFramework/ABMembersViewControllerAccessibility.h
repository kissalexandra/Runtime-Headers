@interface ABMembersViewControllerAccessibility : __ABMembersViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (BOOL)showCardForPerson:(id)a0 withMemberCell:(id)a1 animate:(BOOL)a2;

@end
