@class RTPlaceInferenceManager, RTEventAgentManager, RTDeviceLocationPredictor, RTLocationStore, RTMapServiceManager, RTFingerprintManager, RTAssetManager, RTLocationManager, RTWiFiManager, RTLearnedLocationManager, NSString, RTAuthorizationManager, RTVisitManager, NSMutableDictionary, RTScenarioTriggerManager, RTAccountManager, NSXPCInterface, RTMetricManager, RTDiagnostics, RTEventModelProvider, RTVehicleLocationProvider, RTPurgeManager;

@interface RTClientListener : RTXPCListener <RTClientListenerProtocol, NSXPCListenerDelegate> {
    NSXPCInterface *_frameworkInterface;
    NSXPCInterface *_daemonInterface;
}

@property (retain, nonatomic) NSMutableDictionary *persistedClients;
@property (retain, nonatomic) RTScenarioTriggerManager *scenarioTriggerManager;
@property (retain, nonatomic) RTVehicleLocationProvider *vehicleLocationProvider;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTDeviceLocationPredictor *deviceLocationPredictor;
@property (retain, nonatomic) RTPurgeManager *purgeManager;
@property (retain, nonatomic) RTEventModelProvider *eventModelProvider;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) RTAssetManager *assetManager;
@property (retain, nonatomic) RTLocationStore *locationStore;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTEventAgentManager *eventAgentManager;
@property (retain, nonatomic) RTDiagnostics *diagnostics;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTPlaceInferenceManager *placeInferenceManager;
@property (retain, nonatomic) RTAccountManager *accountManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTFingerprintManager *fingerprintManager;
@property (retain, nonatomic) RTWiFiManager *wifiManager;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)persistedClientsPath;

- (id)init;
- (void).cxx_destruct;
- (BOOL)listener:(id)a0 shouldAcceptNewConnection:(id)a1;
- (void)_setup;
- (id)handleClientConnection:(id)a0;
- (void)saveDaemonClient:(id)a0;
- (id)handleRestorationForDaemonClient:(id)a0;
- (id)initWithAccountManager:(id)a0 assetManager:(id)a1 authorizationManager:(id)a2 deviceLocationPredictor:(id)a3 diagnostics:(id)a4 eventAgentManager:(id)a5 eventModelProvider:(id)a6 fingerprintManager:(id)a7 learnedLocationManager:(id)a8 locationManager:(id)a9 locationStore:(id)a10 mapServiceManager:(id)a11 metricManager:(id)a12 placeInferenceManager:(id)a13 purgeManager:(id)a14 scenarioTriggerManager:(id)a15 vehicleLocationProvider:(id)a16 visitManager:(id)a17 wifiManager:(id)a18;
- (void)_setupConnection:(id)a0 forClient:(id)a1;
- (void)handleDisconnectionForDaemonClient:(id)a0;

@end
