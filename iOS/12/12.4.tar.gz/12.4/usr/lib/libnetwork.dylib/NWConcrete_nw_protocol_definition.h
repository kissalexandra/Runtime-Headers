@class NSString;

@interface NWConcrete_nw_protocol_definition : NSObject <OS_nw_protocol_definition> {
    struct nw_protocol_identifier { char name[32]; int level; int mapping; } identifier;
    unsigned char unique_identifier[16];
    int variant;
    void /* function */ *allocate_globals;
    void /* function */ *deallocate_globals;
    void /* function */ *allocate_instance_state;
    void /* function */ *deallocate_instance_state;
    void /* function */ *allocate_flow_state;
    void /* function */ *deallocate_flow_state;
    void /* function */ *allocate_options;
    void /* function */ *copy_options;
    void /* function */ *deallocate_options;
    void /* function */ *check_equality_options;
    void /* function */ *allocate_metadata;
    void /* function */ *deallocate_metadata;
    void /* function */ *deallocate_cache_entry;
    void /* function */ *should_flush_cache;
    void /* function */ *initialize;
    void /* function */ *destroy;
    void /* function */ *handle_inbound;
    void /* function */ *handle_outbound;
    void /* function */ *handle_error;
    void /* function */ *inbound_starting;
    void /* function */ *inbound_stopping;
    void /* function */ *outbound_starting;
    void /* function */ *outbound_stopping;
    void /* function */ *start;
    void /* function */ *stop;
    void /* function */ *copy_metadata;
    unsigned int custom_flow_map_key_size;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;

@end
