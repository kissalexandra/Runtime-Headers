@interface RTArchiver : NSObject {
    struct archive { } *_archive;
}

@property (nonatomic) BOOL valid;

- (void)dealloc;
- (void)closeArchive;
- (id)initWithOutputURL:(id)a0 compress:(BOOL)a1;
- (void)addFileToArchive:(id)a0;
- (void)addDirectoryToArchive:(id)a0;

@end
