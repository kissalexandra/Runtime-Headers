@interface __MPAudioRouteCellAccessibility_super : UIAccessibilitySafeCategory

@end
