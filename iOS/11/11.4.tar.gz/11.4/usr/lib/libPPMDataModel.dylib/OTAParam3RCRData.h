@interface OTAParam3RCRData : PBCodable <NSCopying> {
    struct { float *list; unsigned long long count; unsigned long long size; } _tempCos;
    struct { float *list; unsigned long long count; unsigned long long size; } _val25cs;
}

@property (readonly, nonatomic) unsigned long long val25csCount;
@property (readonly, nonatomic) float *val25cs;
@property (readonly, nonatomic) unsigned long long tempCosCount;
@property (readonly, nonatomic) float *tempCos;

- (BOOL)readFrom:(id)a0;
- (void)writeTo:(id)a0;
- (void)copyTo:(id)a0;
- (void)mergeFrom:(id)a0;
- (void)dealloc;
- (BOOL)isEqual:(id)a0;
- (unsigned long long)hash;
- (id)description;
- (id)copyWithZone:(struct _NSZone { } *)a0;
- (id)dictionaryRepresentation;
- (void)clearVal25cs;
- (float)val25cAtIndex:(unsigned long long)a0;
- (void)addVal25c:(float)a0;
- (void)clearTempCos;
- (float)tempCoAtIndex:(unsigned long long)a0;
- (void)addTempCo:(float)a0;
- (void)setVal25cs:(float *)a0 count:(unsigned long long)a1;
- (void)setTempCos:(float *)a0 count:(unsigned long long)a1;

@end
