@class RTLocationTagger, NSMutableDictionary, RTMicroLocationCache, NSString, NSObject, _DKEventStream;
@protocol OS_dispatch_queue, _CDLocalContext;

@interface RTDuetHelper : NSObject <RTDiagnosticProvider>

@property (retain, nonatomic) RTLocationTagger *locationTagger;
@property (nonatomic) double minimumConfidenceThreshold;
@property (retain, nonatomic) NSMutableDictionary *registrationRecords;
@property (retain, nonatomic) id<_CDLocalContext> contextStore;
@property (retain, nonatomic) _DKEventStream *duetEventStream;
@property (retain, nonatomic) RTMicroLocationCache *microLocationCache;
@property (readonly, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (readonly, nonatomic) long long streamType;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)diagnosticFiles;
+ (id)duetHelperStreamTypeToDuetEventStream:(long long)a0;
+ (id)predicateForEventNotificationClass:(Class)a0;

- (id)init;
- (void).cxx_destruct;
- (void)purge;
- (void)shutdown;
- (void)_purge;
- (void)_shutdown;
- (void)_fetchAudioEventsWithStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_fetchBluetoothEventsWithStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_fetchStarkEventsWithStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_fetchMicroLocationEventsWithStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (id)initWithQueue:(id)a0 duetEventStream:(long long)a1 locationTagger:(id)a2 defaultsManager:(id)a3;
- (void)_fetchAllEventsForStreamType:(long long)a0 startDate:(id)a1 endDate:(id)a2 handler:(id /* block */)a3;
- (id)_convertDuetEvent:(id)a0;
- (void)startMonitoringForEventsWithNotificationClass:(Class)a0 handler:(id /* block */)a1;
- (void)_registerWithCoreDuetForRealtimeNotificationsWithNotificationClass:(Class)a0 handler:(id /* block */)a1;
- (void)stopMonitoringForEventsWithNotificationClass:(Class)a0;
- (void)_unregisterWithCoreDuetForRealtimeNotificationsWithNotificationClass:(Class)a0;
- (void)_unregisterWithCoreDuetForRealtimeNotificationsWithRegistrationIdentifier:(id)a0;
- (void)_processCoreDuetChangeNotificationWithIdentifier:(id)a0;
- (id /* block */)_contextChangeBlockForNotificationClass:(Class)a0;
- (void)_fetchDeviceFirstWakeupEventsWithStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_fetchNowPlayingEventsWithStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_fetchAppLaunchEventsWithStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;

@end
