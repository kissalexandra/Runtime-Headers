@class NSArray;

@interface RTDeviceLocationPredictorNextPredictedLocationsOfInterestNotification : RTNotification

@property (retain, nonatomic) NSArray *nextPredictedLocationsOfInterest;

- (void).cxx_destruct;
- (id)initWithNextPredictedLocationsOfInterest:(id)a0;

@end
