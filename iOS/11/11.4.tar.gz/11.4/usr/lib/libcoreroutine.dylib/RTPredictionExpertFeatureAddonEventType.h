@class NSArray;

@interface RTPredictionExpertFeatureAddonEventType : RTPredictionExpertFeatureAddon

@property (readonly, nonatomic) NSArray *eventClasses;

- (void).cxx_destruct;
- (id)description;
- (long long)addonType;
- (id)initWithEventClasses:(id)a0;

@end
