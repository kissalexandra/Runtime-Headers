@class NSObject;
@protocol OS_dispatch_queue;

@interface RTKeychainManager : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;

- (id)saltString:(id)a0 withSaltData:(id)a1 error:(id *)a2;
- (id)defaultSymmetricKeyAttributes;
- (BOOL)statusToError:(int)a0 error:(id *)a1;
- (id)_objectForKey:(id)a0 error:(id *)a1;
- (BOOL)_setObject:(id)a0 forKey:(id)a1 existence:(BOOL)a2 error:(id *)a3;
- (BOOL)_deleteValueWithKey:(id)a0 error:(id *)a1;
- (id)objectForKey:(id)a0 defaultHandler:(id /* block */)a1;
- (id)createSymmetricKeyWithSize:(long long)a0 identifier:(id)a1 storeInKeychain:(BOOL)a2 error:(id *)a3;
- (BOOL)removeEncryptionKeyWithIdentifier:(id)a0 error:(id *)a1;
- (id)encryptionKeyWithSize:(long long)a0 identifier:(id)a1 error:(id *)a2;
- (id)init;
- (void).cxx_destruct;
- (BOOL)setObject:(id)a0 forKey:(id)a1;

@end
