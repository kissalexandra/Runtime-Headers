@class NSArray;

@interface RTLocationManagerNotificationPredictedApplications : RTNotification

@property (readonly, nonatomic) NSArray *predictedApplications;

- (id)initWithPredictedApplications:(id)a0;
- (id)init;
- (void).cxx_destruct;

@end
