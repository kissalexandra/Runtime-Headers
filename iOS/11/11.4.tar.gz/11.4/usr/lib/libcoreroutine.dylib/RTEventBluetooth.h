@class NSString;

@interface RTEventBluetooth : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly, nonatomic) NSString *deviceIdentifier;
@property (readonly, nonatomic) NSString *deviceName;
@property (readonly, nonatomic) long long bluetoothState;
@property (readonly, nonatomic) long long deviceType;

+ (id)stringFromBluetoothState:(long long)a0;

- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (id)description;
- (id)initWithBluetoothState:(long long)a0 deviceType:(long long)a1 deviceName:(id)a2 hardwareAddress:(id)a3 source:(long long)a4 startDate:(id)a5 endDate:(id)a6;

@end
