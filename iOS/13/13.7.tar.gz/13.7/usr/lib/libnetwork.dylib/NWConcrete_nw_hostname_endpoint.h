@class NSObject;
@protocol OS_nw_txt_record;

@interface NWConcrete_nw_hostname_endpoint : NWConcrete_nw_endpoint {
    char *hostname;
    unsigned short port;
    unsigned short priority;
    unsigned short weight;
    NSObject<OS_nw_txt_record> *txt_record;
}

- (void)dealloc;
- (unsigned int)type;
- (id)copyDictionary;
- (unsigned short)port;
- (void).cxx_destruct;
- (unsigned short)priority;
- (void)setPriority:(unsigned short)a0;
- (void)setWeight:(unsigned short)a0;
- (unsigned short)weight;
- (const char *)hostname;
- (char *)createDescription:(BOOL)a0;
- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1 matchParent:(BOOL)a2;
- (id)copyEndpoint;
- (unsigned long long)getHash;
- (const char *)domainForPolicy;
- (id)initWithHostname:(const char *)a0 port:(unsigned short)a1;

@end
