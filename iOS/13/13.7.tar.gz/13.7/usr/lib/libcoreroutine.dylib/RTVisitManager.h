@class RTVisitStore, NSMutableArray, RTLearnedLocationManager, NSString, RTPlatform, RTVisitMonitor, RTMotionActivityManager, RTDefaultsManager, RTLocationManager, RTMetricManager, RTLocationAwarenessManager, RTHintManager;

@interface RTVisitManager : RTService <RTVisitMonitorDelegate, RTPurgable>

@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTHintManager *hintManager;
@property (retain, nonatomic) RTLocationAwarenessManager *locationAwarenessManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTMotionActivityManager *motionActivityManager;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) RTVisitStore *visitStore;
@property (nonatomic) BOOL spoofMode;
@property (retain, nonatomic) NSMutableArray *spoofVisitIncidentTokens;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTVisitMonitor *visitMonitor;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)_setup;
- (void)_shutdown;
- (void)fetchStoredVisitsWithOptions:(id)a0 handler:(id /* block */)a1;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithQueue:(id)a0 defaultsManager:(id)a1 hintManager:(id)a2 learnedLocationManager:(id)a3 locationAwarenessManager:(id)a4 locationManager:(id)a5 metricManager:(id)a6 motionActivityManager:(id)a7 platform:(id)a8 visitStore:(id)a9;
- (void)performPurgeOfType:(long long)a0 referenceDate:(id)a1 completion:(id /* block */)a2;
- (void)fetchVisitsFromDate:(id)a0 toDate:(id)a1 handler:(id /* block */)a2;
- (void)onVisitIncident:(id)a0 error:(id)a1;
- (void)onLeechedVisitIncident:(id)a0 error:(id)a1;
- (void)onLowConfidenceVisitIncident:(id)a0 error:(id)a1;
- (void)simulateVisit:(id)a0 handler:(id /* block */)a1;
- (void)onVisitStoreNotification:(id)a0;
- (void)_setupVisitMonitorWithHandler:(id /* block */)a0;
- (void)_onVisitStoreNotification:(id)a0;
- (void)_updateStateForVisitIncidents;
- (void)_updateStateForLeechedVisitIncidents;
- (void)_updateStateForLowConfidenceVisitIncidents;
- (void)_fetchVisitsFromDate:(id)a0 toDate:(id)a1 handler:(id /* block */)a2;
- (void)_onVisitIncident:(id)a0 error:(id)a1;
- (void)_onLeechedVisitIncident:(id)a0 error:(id)a1;
- (void)_onLowConfidenceVisitIncident:(id)a0 error:(id)a1;
- (void)_performPurgeOfType:(long long)a0 referenceDate:(id)a1 completion:(id /* block */)a2;
- (id)registerForSpoofVisitIncidentOfCategory:(id)a0;
- (void)unregisterForSpoofVisitIncidentWithToken:(int)a0;
- (void)_simulateVisit:(id)a0 handler:(id /* block */)a1;

@end
