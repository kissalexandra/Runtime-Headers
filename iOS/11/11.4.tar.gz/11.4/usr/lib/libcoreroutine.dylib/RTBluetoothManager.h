@interface RTBluetoothManager : RTNotifier

+ (id)allocWithZone:(struct _NSZone { } *)a0;
+ (BOOL)supportsNotificationName:(id)a0;
+ (id)carKitConnectionStateToString:(long long)a0;

- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_shutdown;
- (void)_fetchCarKitConnectedStateWithHandler:(id /* block */)a0;
- (void)fetchCarKitConnectedStateWithHandler:(id /* block */)a0;
- (BOOL)interestedInDeviceType:(id)a0;

@end
