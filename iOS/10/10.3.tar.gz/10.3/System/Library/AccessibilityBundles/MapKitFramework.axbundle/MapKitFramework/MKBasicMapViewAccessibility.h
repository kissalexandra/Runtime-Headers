@interface MKBasicMapViewAccessibility : __MKBasicMapViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0 andGlobe:(BOOL)a1 shouldRasterize:(BOOL)a2;
- (id)accessibilityCustomRotorTitles;
- (id)accessibilityCustomRotorItemsAtIndex:(long long)a0;
- (void)_accessibilityLoadAccessibilityInformation;
- (id)accessibilityContainerElements;

@end
