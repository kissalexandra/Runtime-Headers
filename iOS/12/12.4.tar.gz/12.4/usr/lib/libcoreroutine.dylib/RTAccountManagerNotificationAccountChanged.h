@class RTAccount;

@interface RTAccountManagerNotificationAccountChanged : RTNotification

@property (readonly, nonatomic) RTAccount *latestAccount;
@property (readonly, nonatomic) RTAccount *oldAccount;

- (id)initWithLatestAccount:(id)a0 oldAccount:(id)a1;
- (id)init;
- (void).cxx_destruct;

@end
