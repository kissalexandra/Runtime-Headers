@interface RTPersistenceExpirationEnforcer : NSObject

- (id)entitiesWithDeviceAndExpirationProperty:(id)a0;
- (BOOL)removeRecordsOwnedByOtherDevicesExpiredBeforeDate:(id)a0 allowPropagation:(BOOL)a1 withContext:(id)a2 error:(id *)a3;

@end
