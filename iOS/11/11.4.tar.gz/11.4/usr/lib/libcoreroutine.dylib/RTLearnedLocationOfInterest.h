@class NSString, NSUUID, NSArray, RTLearnedLocation, RTLearnedPlace;

@interface RTLearnedLocationOfInterest : NSObject <RTCoreDataTransformable>

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;
@property (readonly, nonatomic) NSUUID *identifier;
@property (readonly, nonatomic) RTLearnedLocation *location;
@property (readonly, nonatomic) RTLearnedPlace *place;
@property (readonly, nonatomic) NSArray *visits;
@property (readonly, nonatomic) NSArray *transitions;

+ (unsigned long long)mapItemSourceFromGeoMapItemSource:(long long)a0;

- (id)init;
- (void).cxx_destruct;
- (BOOL)isEqual:(id)a0;
- (id)managedObjectWithContext:(id)a0;
- (id)initWithLocationOfInterest:(id)a0 creationDate:(id)a1;
- (id)initWithLocationOfInterestMO:(id)a0;
- (id)initWithLocationOfInterestMO:(id)a0 dateInterval:(id)a1;
- (id)initWithIdentifier:(id)a0 location:(id)a1 place:(id)a2 visits:(id)a3 transitions:(id)a4;

@end
