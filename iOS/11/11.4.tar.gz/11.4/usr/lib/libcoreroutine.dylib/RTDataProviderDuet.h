@class RTDefaultsManager, NSMutableArray, RTLocationTagger;

@interface RTDataProviderDuet : RTDataProviderEvent {
    RTLocationTagger *_locationTagger;
    RTDefaultsManager *_defaultsManager;
}

@property (retain, nonatomic) NSMutableArray *duetHelpers;

- (id)init;
- (void).cxx_destruct;
- (void)shutdown;
- (void)_purge;
- (id)supportedEventStreams;
- (id)initWithPurgeManager:(id)a0 locationTagger:(id)a1 defaultsManager:(id)a2;
- (id)duetHelperForDuetEventStream:(long long)a0;
- (void)_createDuetHelpersWithEventStreamTypes:(id)a0;
- (void)_destroyDuetHelpers;

@end
