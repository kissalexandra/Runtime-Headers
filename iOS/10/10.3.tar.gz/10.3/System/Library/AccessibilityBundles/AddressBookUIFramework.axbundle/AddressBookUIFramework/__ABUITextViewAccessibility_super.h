@interface __ABUITextViewAccessibility_super : UIAccessibilitySafeCategory

@end
