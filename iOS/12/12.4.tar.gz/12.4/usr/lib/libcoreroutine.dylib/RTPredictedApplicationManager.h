@class RTPredictionControllerHero, RTDataProtectionManager, RTPredictionControllerApplicationHome, NSDictionary, RTApplicationManager, RTDefaultsManager, RTMetricManager, RTPlatform, RTPersistenceManager, RTXPCActivityManager, RTLocationManager, RTPredictionControllerApplication, RTAuthorizationManager, RTLocationTagger, RTPredictionExpertApplicationDataSource;

@interface RTPredictedApplicationManager : RTService {
    BOOL _training;
}

@property (retain, nonatomic) RTPredictionControllerApplication *magicalMomentsPredictionController;
@property (retain, nonatomic) RTPredictionControllerApplicationHome *homeMagicalMomentsPredictionController;
@property (copy, nonatomic) id /* block */ dataProcessingFinalizeBlock;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) RTLocationTagger *locationTagger;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTPredictionControllerHero *heroAppPredictionController;
@property (retain, nonatomic) NSDictionary *dataProviders;
@property (retain, nonatomic) RTApplicationManager *applicationManager;
@property (retain, nonatomic) RTDataProtectionManager *dataProtectionManager;
@property (retain, nonatomic) RTPredictionExpertApplicationDataSource *dataSource;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) RTXPCActivityManager *xpcActivityManager;

- (void)shutdown;
- (void)_shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)simulateApplicationPredictionWithBundleIdentifier:(id)a0 reason:(long long)a1 handler:(id /* block */)a2;
- (void)fetchPredictedApplications:(id /* block */)a0;
- (void)fetchPredictedApplicationsAtLocation:(id)a0 handler:(id /* block */)a1;
- (void)fetchPredictedApplicationsWithPredicate:(id)a0 handler:(id /* block */)a1;
- (id)initWithDataProviders:(id)a0 predictionControllerApplication:(id)a1 predictionControllerApplicationHome:(id)a2 predictionControllerHero:(id)a3 metricManager:(id)a4 applicationManager:(id)a5 dataProtectionManager:(id)a6 dataSource:(id)a7 platform:(id)a8 xpcActivityMangaer:(id)a9;
- (void)fetchMagicalMomentsModelPropertyListRepresentation:(id /* block */)a0;
- (void)fetchPredictedApplicationsForEvent:(id)a0 withHandler:(id /* block */)a1;
- (void)processDataForPredictionModelWithHandler:(id /* block */)a0;
- (void)printMagicalMomentsModel:(id /* block */)a0;
- (void)_finalizeDataProcessingWithError:(id)a0;
- (void)onProtectedDataAvailabilityUpdate:(id)a0;
- (void)_stopMonitoringForPredictedApplications;
- (void)_startMonitoringForPredictedApplications;
- (void)onRealtimeEventNotification:(id)a0;
- (void)onHeroAppPrediction:(id)a0;
- (void)_processRealtimeEvent:(id)a0;
- (void)_submitRealtimeEventMetricWithEvent:(id)a0;
- (void)_onHeroAppPrediction:(id)a0;
- (id)init;
- (void).cxx_destruct;

@end
