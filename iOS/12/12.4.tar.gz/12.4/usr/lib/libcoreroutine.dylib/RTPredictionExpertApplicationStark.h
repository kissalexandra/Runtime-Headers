@interface RTPredictionExpertApplicationStark : RTPredictionExpertApplication

- (id)supportedEventClasses;
- (void)_processEventsWithAppLaunchEvents:(id)a0 handler:(id /* block */)a1;

@end
