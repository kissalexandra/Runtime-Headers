@protocol RTUserDefaults;

@interface RTDefaultsManager : RTService {
    id<RTUserDefaults> _userDefaults;
}

- (void)addDomain:(id)a0;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithUserDefaults:(id)a0 customDomain:(id)a1;
- (void)notifyUpdatedKeys:(id)a0;
- (void)registerDefault:(id)a0 forKey:(id)a1;
- (id)objectForKey:(id)a0 domain:(id)a1;
- (void)setObject:(id)a0 forKey:(id)a1 domain:(id)a2;
- (id)init;
- (void).cxx_destruct;
- (id)objectForKey:(id)a0;
- (void)setObject:(id)a0 forKey:(id)a1;
- (void)registerDefaults:(id)a0;

@end
