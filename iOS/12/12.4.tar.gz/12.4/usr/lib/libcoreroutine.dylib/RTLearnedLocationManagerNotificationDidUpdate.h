@interface RTLearnedLocationManagerNotificationDidUpdate : RTNotification

@property (nonatomic) double intervalSinceLastUpdate;

- (id)initWithIntervalSinceLastUpdate:(double)a0;
- (id)description;

@end
