@interface _MKNanoPillTableViewLabelCellAccessibility : ___MKNanoPillTableViewLabelCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (unsigned long long)accessibilityTraits;

@end
