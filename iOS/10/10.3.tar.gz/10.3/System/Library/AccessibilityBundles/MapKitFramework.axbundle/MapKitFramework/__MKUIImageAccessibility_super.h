@interface __MKUIImageAccessibility_super : UIAccessibilitySafeCategory

@end
