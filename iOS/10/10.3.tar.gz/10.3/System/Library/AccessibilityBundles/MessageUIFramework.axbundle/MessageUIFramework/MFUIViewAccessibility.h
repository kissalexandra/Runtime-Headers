@interface MFUIViewAccessibility : __MFUIViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (BOOL)_accessibilityOverridesInvisibility;

@end
