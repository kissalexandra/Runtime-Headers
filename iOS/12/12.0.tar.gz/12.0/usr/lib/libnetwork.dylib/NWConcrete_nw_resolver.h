@class NSString, NSObject;
@protocol OS_dispatch_group, OS_nw_context, OS_nw_endpoint, OS_nw_parameters, OS_dispatch_queue, OS_nw_array;

@interface NWConcrete_nw_resolver : NSObject <OS_nw_resolver> {
    int status;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } lock;
    NSObject<OS_nw_parameters> *parameters;
    NSObject<OS_nw_endpoint> *endpoint;
    NSObject<OS_nw_context> *context;
    NSObject<OS_dispatch_group> *cancel_group;
    unsigned int dns_service_id;
    struct _DNSServiceRef_t { } *dns_service;
    struct _DNSServiceRef_t { } *dns_service_secondary_pointer;
    unsigned int forced_protocol;
    int dns_error;
    unsigned char flags;
    id /* block */ update_block;
    id /* block */ cancel_handler;
    NSObject<OS_dispatch_queue> *client_queue;
    void *query_timer;
    void *crazy_eyeballs_timer;
    NSObject<OS_nw_array> *endpoint_array;
    void *internally_retained_object;
    char log_str[84];
    unsigned char is_custom_resolver : 1;
    unsigned char used_cached_results : 1;
    unsigned char local_only : 1;
    unsigned char suppress_logging : 1;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)initWithEndpoint:(id)a0 parameters:(id)a1 dns_service_id:(unsigned int)a2 localOnly:(BOOL)a3;
- (void).cxx_destruct;
- (void)dealloc;

@end
