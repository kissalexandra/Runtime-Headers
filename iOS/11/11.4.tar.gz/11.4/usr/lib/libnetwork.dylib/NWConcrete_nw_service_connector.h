@class NSString, NSObject;
@protocol OS_nw_dictionary, OS_nw_parameters, OS_dispatch_queue, OS_nw_listener;

@interface NWConcrete_nw_service_connector : NSObject <OS_nw_service_connector> {
    NSObject<OS_nw_listener> *listener;
    unsigned int state;
    NSObject<OS_nw_parameters> *clientParameters;
    NSObject<OS_dispatch_queue> *serviceConnectorQueue;
    unsigned long long serviceConnectorSequenceNumber;
    unsigned short localPortHBO;
    id /* block */ serviceAvailableBlock;
    NSObject<OS_nw_dictionary> *pendingConnectionRequests;
    NSObject<OS_nw_dictionary> *activeConnections;
    NSObject<OS_nw_dictionary> *activeConnectionRequests;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
