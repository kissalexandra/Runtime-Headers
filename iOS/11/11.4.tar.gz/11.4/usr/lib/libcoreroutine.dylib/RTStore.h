@class RTPersistenceManager, NSMutableDictionary, RTInvocationDispatcher;

@interface RTStore : RTService

@property (retain, nonatomic) NSMutableDictionary *contexts;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (nonatomic) unsigned long long availability;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;

- (id)init;
- (void).cxx_destruct;
- (void)_setup;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_shutdown;
- (id)initWithPersistenceManager:(id)a0;
- (void)_setupContextsHandler:(id /* block */)a0;
- (void)_onPersistenceManagerNotification:(id)a0;
- (void)onPersistenceManagerNotification:(id)a0;
- (void)storeTransformableObjects:(id)a0 handler:(id /* block */)a1;
- (void)_storeTransformableObjects:(id)a0 handler:(id /* block */)a1;
- (void)_updateTransformableObjects:(id)a0 handler:(id /* block */)a1;
- (void)updateTransformableObjects:(id)a0 handler:(id /* block */)a1;
- (void)_performBlock:(id /* block */)a0 contextType:(unsigned long long)a1 errorHandler:(id /* block */)a2;
- (void)removeAll:(id)a0 handler:(id /* block */)a1;
- (void)_removeAll:(id)a0 handler:(id /* block */)a1;
- (void)purgePredating:(id)a0 predicateMappings:(id)a1 handler:(id /* block */)a2;
- (void)_purgePredating:(id)a0 predicateMappings:(id)a1 handler:(id /* block */)a2;
- (void)executeDeleteRequests:(id)a0 context:(id)a1 handler:(id /* block */)a2;

@end
