@interface ExpressMode : NSObject

+ (id)MakeInternalConfiguration:(id)a0 outError:(id *)a1;
+ (id)checkAppletCompatibilityInternal:(id)a0 fastPath:(BOOL *)a1 error:(id *)a2;
+ (id)SerializeConfigurationDataForSE:(id)a0 fastPath:(BOOL)a1 error:(id *)a2;
+ (void)getDebugExpressLog:(id)a0;
+ (BOOL)PerformActivations:(id)a0 transceiver:(id)a1 fastPath:(BOOL)a2 seHasActivatedApplets:(BOOL *)a3 error:(id *)a4;
+ (id)checkAppletCompatibility:(id *)a0 fastPath:(BOOL *)a1 error:(id *)a2;
+ (BOOL)configureSE:(id)a0 transceiver:(id)a1 seHasActivatedApplets:(BOOL *)a2 skipAllActivations:(BOOL)a3 fastPath:(BOOL)a4 expressLogging:(BOOL)a5 error:(id *)a6;

@end
