@class RTHintManager, NSString, RTLearnedLocationManager, RTVisitHyperParameter, RTVisitSCIStayCluster, NSMutableArray;

@interface RTVisitPipelineModuleSCI : NSObject <RTVisitPipelineModule> {
    BOOL _useLowConfidence;
    BOOL _checkedForHintNearEntryLocation;
    NSMutableArray *_clusters;
}

@property (readonly, nonatomic) unsigned long long fsmState;
@property (readonly, nonatomic) unsigned long long lcFSMState;
@property (retain, nonatomic) RTHintManager *hintManager;
@property (retain, nonatomic) RTVisitHyperParameter *hyperParameter;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (readonly, nonatomic) RTVisitSCIStayCluster *workingHypothesis;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (double)MinStaticIntervalForSLVArrivalWithHint;
+ (double)MinStaticIntervalForSLVArrival;
+ (id)FSMStateToString:(unsigned long long)a0;
+ (id)LCFSMStateToString:(unsigned long long)a0;
+ (id)FSMEventToString:(unsigned long long)a0;

- (id)init;
- (void).cxx_destruct;
- (id)process:(id)a0;
- (id)initWithHintManager:(id)a0 hyperParameter:(id)a1 learnedLocationManager:(id)a2 useLowConfidence:(BOOL)a3;
- (void)resetWorkingHypothesis;
- (id)handleFSM:(unsigned long long)a0 point:(id)a1;
- (void)processPoints:(id)a0;
- (BOOL)isInWorkingHypothesis;
- (void)exitFromWorkingHypothesis;
- (BOOL)isVisitInFlight;
- (void)addToClusters:(id)a0;
- (void)addVisitFromWorkingHypothesis:(long long)a0 confidence:(double)a1;
- (id)fetchKnownLOINearLocation:(id)a0;
- (BOOL)isNearHint:(id)a0;
- (void)exitUntilNotInWorkingHypotheisWithBlock:(id /* block */)a0;

@end
