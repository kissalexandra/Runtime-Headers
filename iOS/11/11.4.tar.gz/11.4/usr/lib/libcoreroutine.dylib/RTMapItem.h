@class NSUUID, NSData, NSDate, NSNumber;
@protocol GEOMapItem;

@interface RTMapItem : NSObject <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly, nonatomic) NSUUID *identifier;
@property (readonly, nonatomic) id<GEOMapItem> geoMapItem;
@property (readonly, nonatomic) NSData *geoMapItemHandle;
@property (readonly, nonatomic) unsigned long long source;
@property (readonly, nonatomic) NSDate *creationDate;
@property (readonly, nonatomic) NSNumber *weight;

+ (id)sourceToString:(unsigned long long)a0;
+ (id)geoMapItemToString:(id)a0;
+ (id)compoundWeightForMapItem:(id)a0;
+ (double)weightForSource:(unsigned long long)a0;
+ (double)weightForGeoMapItem:(id)a0;
+ (BOOL)hasKnownTypeItem:(id)a0;
+ (id)dedupeMapItems:(id)a0;
+ (id)heaviestMapItemFrom:(id)a0 closestToLocation:(id)a1 distanceCalculator:(id)a2 error:(id *)a3;

- (BOOL)isEqualToMapItem:(id)a0;
- (id)init;
- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (BOOL)isEqual:(id)a0;
- (unsigned long long)hash;
- (id)description;
- (long long)compare:(id)a0;
- (BOOL)isValid;
- (id)initWithIdentifier:(id)a0 geoMapItem:(id)a1 source:(unsigned long long)a2 creationDate:(id)a3;
- (id)initWithIdentifier:(id)a0 geoMapItem:(id)a1 geoMapItemHandle:(id)a2 source:(unsigned long long)a3 creationDate:(id)a4;
- (id)toLocation;
- (id)initWithLocationOfInterestMO:(id)a0;
- (id)initWithPlaceMO:(id)a0;
- (id)mapItemAppendingSource:(unsigned long long)a0;

@end
