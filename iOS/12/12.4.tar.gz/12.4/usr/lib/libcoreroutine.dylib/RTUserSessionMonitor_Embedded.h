@interface RTUserSessionMonitor_Embedded : RTUserSessionMonitor

- (BOOL)activeUser;
- (unsigned int)uid;

@end
