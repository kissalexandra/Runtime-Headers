@interface RTPhotoLibraryManagerDelegateFactory : NSObject

+ (id)createDelegateWithNotifierBlock:(id /* block */)a0;
+ (id)_createDelegateWithPhotoLibrary:(id)a0 notifierBlock:(id /* block */)a1;

@end
