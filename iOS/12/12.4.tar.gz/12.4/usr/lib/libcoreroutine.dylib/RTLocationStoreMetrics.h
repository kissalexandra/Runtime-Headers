@interface RTLocationStoreMetrics : NSObject

@property (nonatomic) unsigned long long count;
@property (nonatomic) double maxIntervalBetweenLocations;

@end
