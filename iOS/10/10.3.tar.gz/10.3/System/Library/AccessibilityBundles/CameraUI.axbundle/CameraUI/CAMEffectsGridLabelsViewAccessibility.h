@interface CAMEffectsGridLabelsViewAccessibility : __CAMEffectsGridLabelsViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityElementsHidden;

@end
