@interface RTEventPair : NSObject

@property (readonly, nonatomic) id firstObject;
@property (readonly, nonatomic) id secondObject;

- (id)init;
- (void).cxx_destruct;
- (BOOL)isEqual:(id)a0;
- (unsigned long long)hash;
- (id)description;
- (id)initWithFirstObject:(id)a0 secondObject:(id)a1;
- (BOOL)isEqualToEventPair:(id)a0;

@end
