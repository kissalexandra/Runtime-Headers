@class NSArray, RTLocation;

@interface RTRouteFinderViterbiStep : NSObject

@property (readonly, nonatomic) BOOL valid;
@property (copy, nonatomic) RTLocation *waypoint;
@property (retain, nonatomic) NSArray *items;

- (id)init;
- (void).cxx_destruct;
- (id)initWithRoad:(id)a0;
- (id)initWithWaypoint:(id)a0;

@end
