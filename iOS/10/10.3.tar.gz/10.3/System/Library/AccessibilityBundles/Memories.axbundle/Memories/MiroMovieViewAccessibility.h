@interface MiroMovieViewAccessibility : __MiroMovieViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;
- (BOOL)isAccessibilityElement;

@end
