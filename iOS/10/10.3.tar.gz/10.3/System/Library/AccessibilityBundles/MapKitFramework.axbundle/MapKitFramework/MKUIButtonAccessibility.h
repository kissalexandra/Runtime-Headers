@interface MKUIButtonAccessibility : __MKUIButtonAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)_accessibilityInfoButtonContext;

@end
