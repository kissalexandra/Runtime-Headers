@class NSObject;
@protocol OS_nw_txt_record;

@interface NWConcrete_nw_bonjour_service_endpoint : NWConcrete_nw_endpoint {
    char *service_name;
    char *service_type;
    char *service_domain;
    char *service_composite;
    NSObject<OS_nw_txt_record> *txt_record;
}

- (void)dealloc;
- (unsigned int)type;
- (id)copyDictionary;
- (void).cxx_destruct;
- (char *)createDescription:(BOOL)a0;
- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1 matchParent:(BOOL)a2;
- (id)copyEndpoint;
- (unsigned long long)getHash;
- (const char *)domainForPolicy;
- (id)initWithName:(const char *)a0 type:(const char *)a1 domain:(const char *)a2;

@end
