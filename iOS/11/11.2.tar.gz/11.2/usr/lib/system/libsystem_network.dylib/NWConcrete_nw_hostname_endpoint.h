@class NSObject;
@protocol OS_xpc_object;

@interface NWConcrete_nw_hostname_endpoint : NWConcrete_nw_endpoint {
    char *hostname;
    unsigned short port;
    NSObject<OS_xpc_object> *txt_record;
}

- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1;
- (unsigned long long)getHash;
- (const char *)domainForPolicy;
- (id)initWithHostname:(const char *)a0 port:(unsigned short)a1;
- (id)copyDictionary;
- (void).cxx_destruct;
- (void)dealloc;
- (unsigned int)type;
- (unsigned short)port;
- (const char *)getDescription;

@end
