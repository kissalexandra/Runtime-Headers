@interface ABPersonTableHeaderViewAccessibility : __ABPersonTableHeaderViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)reloadData;

@end
