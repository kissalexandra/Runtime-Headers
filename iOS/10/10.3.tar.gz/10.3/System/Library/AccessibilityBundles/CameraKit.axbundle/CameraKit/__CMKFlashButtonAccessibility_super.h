@interface __CMKFlashButtonAccessibility_super : UIAccessibilitySafeCategory

@end
