@class NSArray;

@interface RTVehicleEventNotification : RTNotification

@property (readonly, nonatomic) NSArray *vehicleEvents;

- (id)initWithVehicleEvents:(id)a0;
- (void).cxx_destruct;

@end
