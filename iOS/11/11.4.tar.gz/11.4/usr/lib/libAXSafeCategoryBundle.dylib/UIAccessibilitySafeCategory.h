@class NSString;

@interface UIAccessibilitySafeCategory : NSObject

@property (copy, nonatomic) NSString *accessibilityIdentifier;

+ (id)_installSafeCategoryOnClassNamed:(id)a0 isManaged:(BOOL)a1;
+ (id)_installLocalValidationMethodOnClassNamed:(id)a0;
+ (void)_addCategoryMethod:(struct objc_method { } *)a0 toClass:(Class)a1 isClass:(BOOL)a2;
+ (id)_installSafeCategoryOnClass:(Class)a0 isManaged:(BOOL)a1;
+ (Class)safeCategoryTargetClass;
+ (void)safeCategoryAddDependenciesToCollection:(id)a0;
+ (void)_installSafeCategoryOnClassNamed:(id)a0;
+ (id)safeCategoryTargetClassName;
+ (id)_installSafeCategoryValidationMethod;
+ (Class)safeCategoryBaseClass;
+ (id)_initializeSafeCategoryFromValidationManager;

@end
