@interface RTDataProviderHeroApp_Embedded : RTDataProviderHeroApp

- (void)populateDataProviderWithHandler:(id /* block */)a0;
- (void)_fetchPredictedApplicationsAtLocation:(id)a0 handler:(id /* block */)a1;
- (id)_processLocationApplicationPredictions:(id)a0;

@end
