@class NSString, NSArray, NSMutableDictionary, NSDate, RTVisit, RTVisitHyperParameter;

@interface RTVisitPipeline : NSObject {
    NSArray *_modules;
    NSMutableDictionary *_moduleStats;
    unsigned long long _iteration;
    RTVisitHyperParameter *_hyperParameter;
}

@property (retain, nonatomic) NSDate *lastProcessedLocationDate;
@property (readonly, nonatomic) NSString *name;
@property (readonly, nonatomic) unsigned long long type;
@property (readonly, nonatomic) RTVisit *lastVisit;
@property (nonatomic) BOOL bootStrappingDone;

+ (id)typeToString:(unsigned long long)a0;

- (id)init;
- (void)dealloc;
- (id)description;
- (void).cxx_destruct;
- (id)initWithModules:(id)a0 name:(id)a1 type:(unsigned long long)a2 lastVisit:(id)a3 hyperParameter:(id)a4;
- (id)filterLocations:(id)a0;
- (id)processVisitCluster:(id)a0;
- (id)filterVisit:(id)a0;
- (id)processLocations:(id)a0;

@end
