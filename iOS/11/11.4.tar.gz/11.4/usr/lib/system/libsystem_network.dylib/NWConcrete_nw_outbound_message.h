@class NSString, NSObject;
@protocol OS_nw_dictionary, OS_dispatch_data, OS_nw_array;

@interface NWConcrete_nw_outbound_message : NSObject <OS_nw_outbound_message> {
    NSObject<OS_dispatch_data> *content;
    NSObject<OS_nw_array> *antecedents;
    NSObject<OS_nw_dictionary> *values;
    unsigned long long deadline_milliseconds;
    unsigned int relative_priority;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void).cxx_destruct;
- (void)dealloc;
- (id)initWithContent:(id)a0;

@end
