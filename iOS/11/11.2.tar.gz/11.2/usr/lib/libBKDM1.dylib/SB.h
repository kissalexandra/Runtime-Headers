@class NSObject;
@protocol OS_dispatch_queue;

@interface SB : SBBase {
    NSObject<OS_dispatch_queue> *_sbQueue;
}

- (id)init;
- (void)dealloc;
- (void)timeZoneChanged;
- (void)refreshTimeBox;
- (void)currentStatus:(id)a0;
- (void)removeIdentity:(id)a0 withTimestamp:(unsigned long long)a1;
- (void)homeButtonState:(BOOL)a0 withTimestamp:(unsigned long long)a1;
- (void)startBioOperation:(id)a0;
- (void)enrollResultIdentity:(id)a0 withTimestamp:(unsigned long long)a1;
- (void)matchResultIdentity:(id)a0 withDetails:(id)a1 timestamp:(unsigned long long)a2;
- (void)statusMessage:(int)a0 withData:(id)a1 timestamp:(unsigned long long)a2;
- (void)sensorStatus:(id)a0;
- (void)kernelMessage:(id)a0;
- (void)sensorRecoveryReason:(unsigned int)a0 withTimestamp:(unsigned long long)a1;
- (void)sksLockState:(unsigned short)a0 forUser:(unsigned int)a1 withTimestamp:(unsigned long long)a2;
- (void)displayState:(BOOL)a0 withTimestamp:(unsigned long long)a1;
- (void)dispatchLogEventAsync:(id /* block */)a0 withCurrentTimestamp:(BOOL)a1;
- (void)powerEventChargerStateAsync:(BOOL)a0 willHibernate:(BOOL)a1 withTimestamp:(unsigned long long)a2;
- (void)powerState:(BOOL)a0 withTimestamp:(unsigned long long)a1;
- (void)dispatchLogEventSync:(id /* block */)a0 withCurrentTimestamp:(BOOL)a1;

@end
