@interface AddressBookUIAccessibilityUITableView : __AddressBookUIAccessibilityUITableView_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;

@end
