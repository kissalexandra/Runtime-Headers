@interface MKPlacePhotosViewControllerAccessibility : __MKPlacePhotosViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)loadView;
- (void)_axAnnotateView;
- (void)_accessibilityLoadAccessibilityInformation;

@end
