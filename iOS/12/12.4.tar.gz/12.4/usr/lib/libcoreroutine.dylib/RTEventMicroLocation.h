@class NSArray;

@interface RTEventMicroLocation : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly, nonatomic) NSArray *microLocations;

- (id)initWithStartDate:(id)a0 endDate:(id)a1 source:(long long)a2 identifier:(id)a3 microLocations:(id)a4;
- (id)initWithStartDate:(id)a0 endDate:(id)a1 source:(long long)a2 identifier:(id)a3;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (id)description;

@end
