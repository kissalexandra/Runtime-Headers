@interface RTDataProviderNowPlaying : RTDataProviderDuet

- (id)init;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)supportedEventClasses;
- (id)supportedEventStreams;
- (void)populateDataProviderWithHandler:(id /* block */)a0;
- (id)initWithPurgeManager:(id)a0 locationTagger:(id)a1 defaultsManager:(id)a2;

@end
