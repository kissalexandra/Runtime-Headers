@interface MFModernLabelledAtomListAccessibility : __MFModernLabelledAtomListAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (unsigned long long)accessibilityTraits;
- (BOOL)shouldGroupAccessibilityChildren;
- (BOOL)_accessibilitySpeakThisIgnoresAccessibilityElementStatus;
- (BOOL)_accessibilityIsSpeakThisElement;
- (id)_accessibilitySpeakThisString;

@end
