@class RTPersistenceManager, RTEventAgentManager, RTDeviceLocationPredictor, RTLocationStore, RTMapServiceManager, RTAssetManager, RTLocationManager, RTFingerprintManager, RTWiFiManager, RTLearnedLocationManager, RTAuthorizationManager, RTVisitManager, RTAccountManager, NSString, RTScenarioTriggerManager, RTPlatform, RTActionManager, RTRouteManager, RTPredictedApplicationManager, RTEventModelProvider, RTVehicleLocationProvider, RTPurgeManager;

@interface RTInternalClientListener : RTXPCListener <NSXPCListenerDelegate>

@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) RTPredictedApplicationManager *predictedApplicationManager;
@property (retain, nonatomic) RTScenarioTriggerManager *scenarioTriggerManager;
@property (retain, nonatomic) RTVehicleLocationProvider *vehicleLocationProvider;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTDeviceLocationPredictor *deviceLocationPredictor;
@property (retain, nonatomic) RTPurgeManager *purgeManager;
@property (retain, nonatomic) RTActionManager *actionManager;
@property (retain, nonatomic) RTEventModelProvider *eventModelProvider;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) RTAssetManager *assetManager;
@property (retain, nonatomic) RTLocationStore *locationStore;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTEventAgentManager *eventAgentManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTRouteManager *routeManager;
@property (retain, nonatomic) RTAccountManager *accountManager;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) RTFingerprintManager *fingerprintManager;
@property (retain, nonatomic) RTWiFiManager *wifiManager;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (BOOL)listener:(id)a0 shouldAcceptNewConnection:(id)a1;
- (id)handleClientConnection:(id)a0;
- (id)initWithDeviceLocationPredictor:(id)a0 scenarioTriggerManager:(id)a1 vehicleLocationProvider:(id)a2 predictedApplicationManager:(id)a3 actionManager:(id)a4 eventModelProvider:(id)a5 visitManager:(id)a6 authorizationManager:(id)a7 purgeManager:(id)a8 assetManager:(id)a9 locationStore:(id)a10 locationManager:(id)a11 eventAgentManager:(id)a12 platform:(id)a13 learnedLocationManager:(id)a14 routeManager:(id)a15 accountManager:(id)a16 fingerprintManager:(id)a17 persistenceManager:(id)a18;

@end
