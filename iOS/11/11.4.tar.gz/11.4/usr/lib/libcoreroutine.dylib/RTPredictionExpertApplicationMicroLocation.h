@interface RTPredictionExpertApplicationMicroLocation : RTPredictionExpertApplication

@property (nonatomic) double maxMicroLocationEventAge;

- (id)supportedEventClasses;
- (void)_processEventsWithAppLaunchEvents:(id)a0 handler:(id /* block */)a1;
- (id)initWithQueue:(id)a0 category:(long long)a1 dataSource:(id)a2 defaultsManager:(id)a3 mediaRemote:(id)a4 featureAddons:(id)a5;
- (id)dateIntervalForAppLaunchEvent:(id)a0;

@end
