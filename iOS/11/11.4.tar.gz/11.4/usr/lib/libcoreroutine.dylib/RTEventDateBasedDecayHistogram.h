@class NSNumber, NSString, NSMutableOrderedSet;

@interface RTEventDateBasedDecayHistogram : RTEventWeightedHistogram <RTEventHistogram>

@property (retain, nonatomic) NSMutableOrderedSet *dateSet;
@property (retain, nonatomic) NSNumber *decayRate;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (BOOL)supportsSecureCoding;
+ (void)resetDateSet:(id)a0 forEventArray:(id)a1;
+ (id)dateSetForEventArray:(id)a0;

- (id)init;
- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (void)reset;
- (void)clear;
- (void)addEvent:(id)a0 weight:(double)a1;
- (double)decayTimeExponent:(id)a0;
- (id)initWithDateSet:(id)a0 decayRate:(id)a1;
- (id)initWithEventArray:(id)a0 decayRate:(id)a1;
- (id)initWithDecayRate:(id)a0;
- (void)resetWithEventArray:(id)a0;

@end
