@interface MiroSmartMusicMenuCellAccessibility : __MiroSmartMusicMenuCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)awakeFromNib;
- (void)prepareForReuse;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;
- (BOOL)_axRequiresDownload;

@end
