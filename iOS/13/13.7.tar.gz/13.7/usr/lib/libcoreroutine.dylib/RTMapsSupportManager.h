@class RTTimerManager, RTMapServiceManager, NSObject;
@protocol OS_dispatch_queue;

@interface RTMapsSupportManager : NSObject

@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) RTTimerManager *timerManager;

+ (id)allocWithZone:(struct _NSZone { } *)a0;

- (id)init;
- (void).cxx_destruct;
- (void)showParkedCarBulletinForEvent:(id)a0;
- (void)showParkedCarReplacementBulletinForEvent:(id)a0 replacingEvent:(id)a1;
- (void)clearParkedCarBulletin;
- (id)initWithMapServiceManager:(id)a0;
- (void)_showParkedCarBulletinForEvent:(id)a0;
- (void)_showParkedCarReplacementBulletinForEvent:(id)a0 replacingEvent:(id)a1;
- (void)_clearParkedCarBulletin;
- (id)initWithMapServiceManager:(id)a0 timerManager:(id)a1;
- (void)_fetchFavoritePlacesWithHandler:(id /* block */)a0;
- (void)_fetchPinnedPlacesWithHandler:(id /* block */)a0;
- (void)_fetchHistoryEntryPlaceDisplaysWithHandler:(id /* block */)a0;
- (void)_fetchHistoryEntryRoutesWithHandler:(id /* block */)a0;
- (void)fetchFavoritePlacesWithHandler:(id /* block */)a0;
- (void)fetchPinnedPlacesWithHandler:(id /* block */)a0;
- (void)fetchHistoryEntryPlaceDisplaysWithHandler:(id /* block */)a0;
- (void)fetchHistoryEntryRoutesWithHandler:(id /* block */)a0;

@end
