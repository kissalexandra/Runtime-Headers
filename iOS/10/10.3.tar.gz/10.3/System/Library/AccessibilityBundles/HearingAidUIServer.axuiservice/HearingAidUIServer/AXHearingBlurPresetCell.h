@class UIImageView, AXHearingAidMode;

@interface AXHearingBlurPresetCell : AXHearingBlurCell {
    UIImageView *_checkedView;
    BOOL _isUsingStreamingIcon;
}

@property (retain, nonatomic) AXHearingAidMode *preset;

+ (id)cellWithPreset:(id)a0;

- (id)init;
- (void)layoutSubviews;
- (void)dealloc;
- (void)setSelected:(BOOL)a0 animated:(BOOL)a1;
- (void)updateCell;

@end
