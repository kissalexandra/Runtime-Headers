@interface MFComposeMultiViewAccessibility : __MFComposeMultiViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityElementsHidden;

@end
