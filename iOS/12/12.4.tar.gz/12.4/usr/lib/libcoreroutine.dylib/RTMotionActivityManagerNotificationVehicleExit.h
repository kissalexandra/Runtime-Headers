@interface RTMotionActivityManagerNotificationVehicleExit : RTNotification

@end
