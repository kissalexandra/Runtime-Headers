@class CHManager, NSObject;
@protocol OS_dispatch_queue;

@interface RTCallHistoryManager : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) CHManager *callHistoryManager;

- (id)init;
- (void).cxx_destruct;
- (void)dumpCallHistoryFromDate:(id)a0 toDate:(id)a1 completionHandler:(id /* block */)a2;
- (id)_buildPredicateWithFromDate:(id)a0 toDate:(id)a1;
- (void)_dumpCallHistoryFromDate:(id)a0 toDate:(id)a1 completionHandler:(id /* block */)a2;

@end
