@interface ACUIAppInstallCellAccessibility : __ACUIAppInstallCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (struct CGPoint { double x0; double x1; })accessibilityActivationPoint;

@end
