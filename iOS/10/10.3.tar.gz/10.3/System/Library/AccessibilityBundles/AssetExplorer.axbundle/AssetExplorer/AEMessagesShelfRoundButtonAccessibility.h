@interface AEMessagesShelfRoundButtonAccessibility : __AEMessagesShelfRoundButtonAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_commonAEMessagesRoundButtonInitializationWithStyle:(long long)a0;

@end
