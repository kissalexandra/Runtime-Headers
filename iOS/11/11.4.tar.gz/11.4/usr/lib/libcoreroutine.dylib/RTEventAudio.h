@class NSString;

@interface RTEventAudio : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly, nonatomic) NSString *deviceIdentifier;
@property (readonly, nonatomic) NSString *deviceName;
@property (readonly, nonatomic) long long audioState;
@property (readonly, nonatomic) long long audioSource;

+ (id)stringFromAudioState:(long long)a0;

- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (id)description;
- (id)initWithDeviceIdentifier:(id)a0 deviceName:(id)a1 audioState:(long long)a2 audioSource:(long long)a3 source:(long long)a4 startDate:(id)a5 endDate:(id)a6;

@end
