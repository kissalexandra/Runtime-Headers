@interface CMKZoomSliderAccessibility : __CMKZoomSliderAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (BOOL)isAccessibilityElement;
- (void)_hideZoomSlider:(id)a0;

@end
