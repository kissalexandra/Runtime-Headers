@interface HashHelper : NSObject {
    struct CC_SHA256state_st { unsigned int count[2]; unsigned int hash[8]; unsigned int wbuf[16]; } ctx;
}

+ (id)hashHelper;

- (id)init;
- (id)addObject:(id)a0;
- (id)getHash;
- (id)addData:(id)a0;
- (id)addDictionary:(id)a0;
- (id)addData:(void *)a0 withLength:(unsigned long long)a1;
- (id)addNumber:(id)a0;
- (id)addString:(id)a0;
- (id)addArray:(id)a0;
- (id)addDateComponents:(id)a0;

@end
