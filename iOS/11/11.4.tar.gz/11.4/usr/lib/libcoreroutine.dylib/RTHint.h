@class CLLocation, NSDate;

@interface RTHint : NSObject

@property (retain, nonatomic) CLLocation *location;
@property (nonatomic) long long source;
@property (readonly, nonatomic) NSDate *date;

+ (id)hintSourceToString:(long long)a0;

- (void).cxx_destruct;
- (BOOL)isEqual:(id)a0;
- (unsigned long long)hash;
- (id)description;
- (id)initWithLocation:(id)a0 source:(long long)a1 date:(id)a2;

@end
