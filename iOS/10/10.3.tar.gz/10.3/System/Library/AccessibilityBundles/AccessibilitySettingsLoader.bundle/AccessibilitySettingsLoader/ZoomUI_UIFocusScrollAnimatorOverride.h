@interface ZoomUI_UIFocusScrollAnimatorOverride : __ZoomUI_UIFocusScrollAnimatorOverride_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)setTargetContentOffset:(struct CGPoint { double x0; double x1; })a0 forScrollView:(id)a1 convergenceRate:(double)a2 completion:(id /* block */)a3;

@end
