@class NSUserDefaults;

@interface RTPlatform_MobileGestalt : RTPlatform {
    NSUserDefaults *_userDefaults;
}

- (id)deviceClass;
- (BOOL)internalInstall;
- (id)init;
- (void).cxx_destruct;
- (id)systemVersion;
- (id)initWithUserDefaults:(id)a0;
- (id)productType;
- (id)userAssignedDeviceName;
- (id)systemModel;
- (BOOL)lowEndHardware;
- (BOOL)supportsCoreRoutineCapability;
- (BOOL)supportsMultiUser;
- (BOOL)simulatorPlatform;
- (BOOL)iPhonePlatform;
- (BOOL)watchPlatform;
- (BOOL)macOSPlatform;
- (BOOL)iPhoneDevice;
- (BOOL)supportsMicroLocations;
- (BOOL)supportsMagicalMomentsCapability;
- (BOOL)supportsRoutes;

@end
