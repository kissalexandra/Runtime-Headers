@interface ABContactCellAccessibility : __ABContactCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (BOOL)_accessibilityHitTestReverOrder;
- (BOOL)_accessibilityHitTestShouldFallbackToNearestChild;
- (BOOL)_accessibilityTableViewCellSubclassShouldExist;

@end
