@class NSDate;

@interface BLTimeBox : NSObject

@property (readonly, retain) NSDate *systemStartDate;
@property (readonly) BOOL clockChanged;
@property double lastMachCorrection;
@property (retain) NSDate *idleStartDate;

- (id)init;
- (void)dealloc;
- (id)date;
- (id)dateFromAbsoluteTime:(unsigned long long)a0 hasNanoseconds:(unsigned long long *)a1;
- (double)clockOffset;
- (double)idleTimeAtDate:(id)a0;
- (double)synchronizeToClock;
- (double)machCorrectionWithCheck;
- (id)getSystemStartDate;
- (void)systemClockChanged:(id)a0;

@end
