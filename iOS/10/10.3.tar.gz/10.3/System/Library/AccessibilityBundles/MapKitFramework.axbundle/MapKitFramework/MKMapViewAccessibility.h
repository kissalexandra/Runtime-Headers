@interface MKMapViewAccessibility : __MKMapViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityScroll:(long long)a0;
- (id)accessibilityElements;
- (void)_setCompassVisible:(BOOL)a0 animated:(BOOL)a1;

@end
