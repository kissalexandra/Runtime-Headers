@class AWDCoreRoutineTrafficConditions, RTLocationOfInterest;

@interface RTTrafficConditionsMetric : NSObject

@property (readonly, nonatomic) RTLocationOfInterest *locationOfInterest;
@property (readonly, nonatomic) AWDCoreRoutineTrafficConditions *metric;

- (id)initWithPLOIETA:(id)a0;
- (void)updatePrecisionRecallWithVisitedLocation:(id)a0;
- (id)init;
- (void).cxx_destruct;
- (id)description;

@end
