@interface MiroVideoScrubberViewAccessibility : __MiroVideoScrubberViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)scrollViewDidScroll:(id)a0;
- (void)scrollViewDidEndDragging:(id)a0 willDecelerate:(BOOL)a1;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;
- (BOOL)isAccessibilityElement;
- (double)_axCurrentProgress;
- (double)_axLastScrolledTimeInterval;
- (void)_setAXLastScrolledTimeInterval:(double)a0;

@end
