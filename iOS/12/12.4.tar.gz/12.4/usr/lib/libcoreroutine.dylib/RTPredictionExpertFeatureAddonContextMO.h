@class NSString;

@interface RTPredictionExpertFeatureAddonContextMO : RTPredictionExpertFeatureAddonMO

@property (retain, nonatomic) NSString *key;
@property (retain, nonatomic) id value;

+ (id)managedObjectWithKey:(id)a0 value:(id)a1 inManagedObjectContext:(id)a2;

@end
