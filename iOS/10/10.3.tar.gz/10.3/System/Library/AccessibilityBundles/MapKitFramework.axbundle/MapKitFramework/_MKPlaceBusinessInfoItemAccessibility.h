@interface _MKPlaceBusinessInfoItemAccessibility : ___MKPlaceBusinessInfoItemAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)displayString;

@end
