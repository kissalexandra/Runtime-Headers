@class NSString, NSSet, NSDate;

@interface RTPredictionTableMO : NSManagedObject

@property (retain, nonatomic) NSDate *creationDate;
@property (retain, nonatomic) NSString *name;
@property (retain, nonatomic) NSSet *predictions;

+ (id)managedObjectWithName:(id)a0 inManagedObjectContext:(id)a1;

- (void)awakeFromInsert;

@end
