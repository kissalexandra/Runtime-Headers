@class RTDefaultsManager, NSMutableDictionary, NSMutableArray, RTDiagnostics;

@interface RTXPCActivityManager : RTService

@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) RTDiagnostics *diagnosgtics;
@property (retain, nonatomic) NSMutableDictionary *registrants;
@property (nonatomic) BOOL runningTask;
@property (retain, nonatomic) NSMutableArray *pendingTasks;

+ (void)xpcActivityUnregisterIdentifier:(const char *)a0;
+ (id)lastAttemptDateKeyForIdentifier:(id)a0;
+ (id)lastCompleteDateKeyForIdentifier:(id)a0;
+ (id)criteriaDictionaryWithCriteria:(id)a0;
+ (long long)xpcActivityGetStateActivity:(id)a0;
+ (id)xpcActivityCopyCriteriaActivity:(id)a0;
+ (void)xpcActivitySetCriteriaActivity:(id)a0 criteria:(id)a1;
+ (BOOL)xpcActivitySetStateActivity:(id)a0 state:(long long)a1;
+ (void)xpcActivityRegisterIdentifier:(const char *)a0 criteria:(id)a1 handler:(id /* block */)a2;

- (void)_setup;
- (id)initWithDefaultsManager:(id)a0 diagnostics:(id)a1;
- (void)registerActivityWithIdentifier:(id)a0 criteria:(id)a1 handler:(id /* block */)a2;
- (void)unregisterActivityWithIdentifier:(id)a0 handler:(id /* block */)a1;
- (id)_lastAttemptDateForIdentifier:(id)a0;
- (id)_registerRegistrant:(id)a0;
- (void)_scheduleNextTask;
- (void)_runRegistrantWithIdentifier:(id)a0 handler:(id /* block */)a1;
- (void)_updateLastCompleteDateForIdentifier:(id)a0;
- (BOOL)_takeSnapshotSinceDate:(id)a0 description:(id)a1 error:(id *)a2;
- (id)_lastCompleteDateForIdentifier:(id)a0;
- (void)_updateLastAttemptDateForIdentifier:(id)a0;
- (void)runRegistrantWithIdentifier:(id)a0 handler:(id /* block */)a1;
- (void)_registerActivityWithIdentifier:(id)a0 criteria:(id)a1 handler:(id /* block */)a2;
- (void)_unregisterActivityWithIdentifier:(id)a0 handler:(id /* block */)a1;
- (id)init;
- (void).cxx_destruct;

@end
