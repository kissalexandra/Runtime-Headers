@class GEOMapFeatureAccess, NSObject;
@protocol OS_dispatch_queue;

@interface RTMapAccess : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) GEOMapFeatureAccess *mapFeatureAccess;

+ (struct { double x0; double x1; })coordinateOnRoad:(id)a0 fromPolylineCoordinate:(struct { unsigned int x0; float x1; })a1;
+ (struct { double x0; double x1; })closestCoordinateOnRoad:(id)a0 fromCoordinate:(struct { double x0; double x1; })a1;

- (id)_findRoadsNear:(struct { double x0; double x1; })a0 radius:(double)a1 handler:(id /* block */)a2 completionHandler:(id /* block */)a3;
- (void)_findRoadFromLocation:(id)a0 toLocation:(id)a1 handler:(id /* block */)a2;
- (id)initWithQueue:(id)a0 allowsNetworkTileLoad:(BOOL)a1;
- (id)_findPositiveDirectionRoadsAtLocation:(id)a0 handler:(id /* block */)a1;
- (id)_findRoadsFromNextIntersectionOf:(id)a0 handler:(id /* block */)a1 completionHandler:(id /* block */)a2;
- (id)_findRoadsToPreviousIntersectionOf:(id)a0 handler:(id /* block */)a1 completionHandler:(id /* block */)a2;
- (id)_findRoadsFromJunction:(id)a0 handler:(id /* block */)a1 completionHandler:(id /* block */)a2;
- (id)_findRoadsToJunction:(id)a0 handler:(id /* block */)a1 completionHandler:(id /* block */)a2;
- (void).cxx_destruct;

@end
