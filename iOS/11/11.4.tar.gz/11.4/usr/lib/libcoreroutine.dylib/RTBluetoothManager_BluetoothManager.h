@class BluetoothManager, NSSet;

@interface RTBluetoothManager_BluetoothManager : RTBluetoothManager

@property (readonly, nonatomic) BluetoothManager *bluetoothManager;
@property (retain, nonatomic) NSSet *connectedDevices;
@property (nonatomic) BOOL observingConnections;
@property (nonatomic) long long carKitConnectionState;

- (void).cxx_destruct;
- (void)dealloc;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_shutdown;
- (void)updateConnections;
- (void)shouldObserveConnections;
- (long long)getCarKitConnectionStateFromConnectedDevices:(id)a0;
- (void)_fetchCarKitConnectedStateWithHandler:(id /* block */)a0;

@end
