@class NSObject;
@protocol nw_listener_inbox_delegate, OS_nw_interface, OS_nw_endpoint, OS_nw_parameters;

@interface nw_listener_inbox : NSObject {
    NSObject<nw_listener_inbox_delegate> *_delegate;
    NSObject<OS_nw_parameters> *_parameters;
    unsigned char _suspended : 1;
}

@property (readonly, nonatomic) NSObject<OS_nw_endpoint> *local_endpoint;
@property (readonly, nonatomic) NSObject<OS_nw_interface> *interface;

- (void).cxx_destruct;
- (BOOL)cancel;
- (BOOL)resume;
- (id)start;
- (BOOL)isSuspended;
- (BOOL)suspend;
- (id)initWithDelegate:(id)a0;

@end
