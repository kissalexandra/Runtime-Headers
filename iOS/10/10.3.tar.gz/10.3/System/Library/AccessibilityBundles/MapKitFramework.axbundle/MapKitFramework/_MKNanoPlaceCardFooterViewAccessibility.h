@interface _MKNanoPlaceCardFooterViewAccessibility : ___MKNanoPlaceCardFooterViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityHint;

@end
