@interface UIABSegmentAccessibility : __UIABSegmentAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;

@end
