@class RTDefaultsManager, RTPlatform, NSMutableArray;

@interface RTDiagnostics : RTService {
    RTDefaultsManager *_defaultsManager;
    RTPlatform *_platform;
    NSMutableArray *_diagnosticProviders;
}

+ (id)createDiagnosticsURLWithError:(id *)a0;
+ (id)crashReports;
+ (BOOL)collectArchiveSinceDate:(id)a0 path:(id)a1 error:(id *)a2;
+ (id)stringFromDateWithFormat;
+ (BOOL)createArchiveSourceURL:(id)a0 destinationURL:(id)a1 error:(id *)a2;
+ (void)rolloverSnapshots;

- (void)_shutdown;
- (void)fetchPathToDiagnosticFilesWithHandler:(id /* block */)a0;
- (id)initWithDefaultsManager:(id)a0 platform:(id)a1;
- (void)logProcessDiagnosticInformation;
- (void)addDiagnosticProvider:(id)a0;
- (void)takeSnapshotSinceDate:(id)a0 description:(id)a1 handler:(id /* block */)a2;
- (void)fetchPathToBackupWithHandler:(id /* block */)a0;
- (id)_collectDiagnosticFilesWithError:(id *)a0;
- (void)_fetchPathToDiagnosticFilesWithHandler:(id /* block */)a0;
- (id)_collectBackupWithError:(id *)a0;
- (void)_fetchPathToBackupWithHandler:(id /* block */)a0;
- (id)init;
- (void).cxx_destruct;

@end
