@interface SpeakTypingManager : NSObject

@property (nonatomic, getter=isRegisteredForAppNotifications) BOOL registeredForAppNotifications;

+ (id)sharedInstance;
+ (void)initializeMonitoring;

- (void)_registerForLetterFeedbackAXSettingsUpdate;
- (void)updateForCurrentTypingFeedbackStatus;
- (void)_registerForPhoneticFeedbackAXSettingsUpdate;
- (void)_registerForQuickTypePredictionFeedbackAXSettingsUpdate;
- (void)updateForCurrentQuickTypeFeedbackStatus;
- (void)_registerForWordFeedbackAXSettingsUpdate;
- (void)updateForCurrentWordFeedbackStatus;
- (void)_installSpeakTypingSafeCategoriesIfNeeded;

@end
