@interface MiroTimelineClipCollectionViewControllerAccessibility : __MiroTimelineClipCollectionViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)viewDidLoad;
- (void)_accessibilityLoadAccessibilityInformation;
- (id)_axMiroPhotoScrubber;
- (void)_setAXMiroPhotoScrubber:(id)a0;

@end
