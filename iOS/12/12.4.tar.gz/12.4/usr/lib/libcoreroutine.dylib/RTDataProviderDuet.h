@class RTDefaultsManager, NSMutableArray, RTLocationTagger;

@interface RTDataProviderDuet : RTDataProviderEvent {
    RTLocationTagger *_locationTagger;
    RTDefaultsManager *_defaultsManager;
}

@property (retain, nonatomic) NSMutableArray *duetHelpers;

- (void)_purge;
- (void)_shutdown;
- (id)initWithPurgeManager:(id)a0 locationTagger:(id)a1 defaultsManager:(id)a2;
- (id)duetHelperForDuetEventStream:(long long)a0;
- (id)supportedEventStreams;
- (void)_destroyDuetHelpers;
- (void)_createDuetHelpersWithEventStreamTypes:(id)a0;
- (id)init;
- (void).cxx_destruct;

@end
