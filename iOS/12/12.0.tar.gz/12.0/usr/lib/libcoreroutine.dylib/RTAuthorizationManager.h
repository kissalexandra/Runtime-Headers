@class RTPlatform, RTInvocationDispatcher, RTUserSessionMonitor, RTMetricManager;

@interface RTAuthorizationManager : RTService {
    RTMetricManager *_metricManager;
}

@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (nonatomic, getter=isSupported) BOOL supported;
@property (nonatomic, getter=isEnabled) BOOL enabled;
@property (nonatomic, getter=isReady) BOOL ready;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain) RTUserSessionMonitor *userSessionMonitor;

+ (BOOL)supportsNotificationName:(id)a0;
+ (id)allocWithZone:(struct _NSZone { } *)a0;

- (void)setup;
- (BOOL)isLocationServicesEnabled;
- (void)fetchRoutineEnabledWithHandler:(id /* block */)a0;
- (void)_setup;
- (void)fetchMagicalMomentsLocationUsageEnabled:(id /* block */)a0;
- (id)initWithMetricManager:(id)a0 platform:(id)a1 userSessionMonitor:(id)a2;
- (void)onUserSessionChangeNotification:(id)a0;
- (BOOL)isCoreRoutineLocationClientEnabled;
- (void)_logRoutineEnabled:(BOOL)a0;
- (void)_fetchMagicalMomentsLocationUsageEnabled:(id /* block */)a0;
- (void)_shutdown;
- (void)fetchBBPluginSupportedWithHandler:(id /* block */)a0;
- (void)fetchRoutineSupportedWithHandler:(id /* block */)a0;
- (BOOL)shouldPersistLocations;
- (void)setRoutineEnabled:(BOOL)a0 withHandler:(id /* block */)a1;
- (void)updateRoutineEnabled:(BOOL)a0;
- (void)handleAppResetChangeNotification;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;

@end
