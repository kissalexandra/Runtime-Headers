@interface NWConcrete_nw_address_endpoint : NWConcrete_nw_endpoint {
    struct sockaddr_storage { unsigned char ss_len; unsigned char ss_family; char __ss_pad1[6]; long long __ss_align; char __ss_pad2[112]; } address;
    struct ether_addr { unsigned char octet[6]; } ethernet_address;
    char *hostname;
    unsigned char calculated_hostname : 1;
}

- (void)dealloc;
- (unsigned int)type;
- (id)copyDictionary;
- (unsigned short)port;
- (const char *)hostname;
- (id)initWithAddress:(const struct sockaddr { unsigned char x0; unsigned char x1; char x2[14]; } *)a0 overridePort:(const char *)a1;
- (char *)createDescription:(BOOL)a0;
- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1 matchParent:(BOOL)a2;
- (id)copyEndpoint;
- (unsigned long long)getHash;

@end
