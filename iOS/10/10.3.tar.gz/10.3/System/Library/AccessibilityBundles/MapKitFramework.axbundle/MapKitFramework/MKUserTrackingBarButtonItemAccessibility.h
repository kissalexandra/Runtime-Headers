@interface MKUserTrackingBarButtonItemAccessibility : __MKUserTrackingBarButtonItemAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;

@end
