@class NSMutableDictionary, RTAssetManager, NSObject, NSUserDefaults;
@protocol OS_dispatch_queue;

@interface RTDefaultsManager : RTNotifier

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *serviceQueue;
@property (retain, nonatomic) NSMutableDictionary *remoteDefaultsDictionary;
@property (retain, nonatomic) RTAssetManager *assetsManager;
@property (retain, nonatomic) NSUserDefaults *userDefaults;

- (id)init;
- (void).cxx_destruct;
- (id)objectForKey:(id)a0;
- (void)setObject:(id)a0 forKey:(id)a1;
- (void)_unregisterForNotifications;
- (void)_registerForNotifications;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithAssetsManager:(id)a0;
- (id)initWithUserDefaults:(id)a0 assetsManager:(id)a1;
- (void)_loadRemoteDefaults;
- (void)_installDefaults:(id)a0 toDefaultsDictionary:(id)a1;
- (void)_printCurrentEffectiveDefaults;
- (id)_objectForKey:(id)a0;
- (void)_setObject:(id)a0 forKey:(id)a1;
- (void)onAssetDownloadNotification:(id)a0;
- (void)_onAssetDownloadNotification:(id)a0;
- (id)objectForKey:(id)a0 domain:(id)a1;
- (void)setObject:(id)a0 forKey:(id)a1 domain:(id)a2;

@end
