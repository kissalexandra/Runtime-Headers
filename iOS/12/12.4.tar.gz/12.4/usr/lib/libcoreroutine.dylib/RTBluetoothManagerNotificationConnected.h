@class NSString;

@interface RTBluetoothManagerNotificationConnected : RTNotification

@property (readonly, nonatomic) NSString *deviceName;
@property (readonly, nonatomic) NSString *deviceAddress;

- (id)initWithDeviceName:(id)a0 andDeviceAddress:(id)a1;
- (void).cxx_destruct;

@end
