@interface MPUControlCenterMediaControlsViewAccessibility : __MPUControlCenterMediaControlsViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_reloadNowPlayingInfoLabels;

@end
