@class NSArray;

@interface RTLocationManagerNotificationMicroLocations : RTNotification

@property (readonly, nonatomic) NSArray *microLocations;

- (void).cxx_destruct;
- (id)initWithMicroLocations:(id)a0;

@end
