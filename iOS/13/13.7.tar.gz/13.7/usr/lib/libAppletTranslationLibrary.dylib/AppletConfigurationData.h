@class NSMutableDictionary, NSDictionary, NSObject, NSUserDefaults;
@protocol OS_dispatch_queue;

@interface AppletConfigurationData : NSObject {
    NSObject<OS_dispatch_queue> *queue;
    NSUserDefaults *userDefaults;
    NSDictionary *config;
    NSMutableDictionary *pluginCache;
    unsigned long long maErrorCount;
    BOOL retryInProgress;
    double maMetadataQueryInterval;
}

+ (void)init;
+ (BOOL)setConfiguration:(id)a0;
+ (struct os_state_data_s { unsigned int x0; union { unsigned int x0 : 32; unsigned int x1; } x1; struct os_state_data_decoder_s { char x0[64]; char x1[64]; } x2; char x3[64]; unsigned char x4[0]; } *)dumpState;
+ (id)getInstance;
+ (id)getWuluSettings;
+ (id)extraDebugScriptForModule:(id)a0;
+ (BOOL)isValidConfigData:(id)a0;
+ (id)getOverrideConfig;
+ (id)getStaticConfig;
+ (id)getConfig;
+ (void)registerStateHandler;
+ (id)pluginDecoderForMid:(id)a0;
+ (id)dataHash;
+ (id)scriptForModule:(id)a0;
+ (id)plasticCardScriptForModule:(id)a0;
+ (id)getNFCSettings;
+ (id)getHerculesSettings;
+ (id)getExpressModeSettings;
+ (id)getStaticNFCSettings;
+ (id)getStaticWuluSettings;
+ (id)getStaticExpressModeSettings;
+ (id)getStaticHerculesSettings;

- (id)init;
- (void).cxx_destruct;
- (void)tsmScriptPerformed:(id)a0;
- (void)queryMA;
- (void)maybeQueryMetadata;
- (void)queryMetadata;
- (id)optionsForInterval:(double)a0;
- (void)retryWithBackoff:(id /* block */)a0;
- (void)handleQueryResult:(long long)a0 query:(id)a1;
- (void)handleQuerySuccess:(id)a0;
- (BOOL)isEligibleAsset:(id)a0;
- (void)downloadAsset:(id)a0;
- (void)handleAvailableAsset:(id)a0;
- (id)pluginDecoderForMid:(id)a0 depth:(int)a1;

@end
