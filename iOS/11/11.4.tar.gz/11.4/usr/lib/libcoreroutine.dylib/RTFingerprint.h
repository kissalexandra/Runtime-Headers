@class NSString, NSUUID, NSArray, NSDate;

@interface RTFingerprint : NSObject <RTCoreDataTransformable>

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;
@property (readonly, nonatomic) NSUUID *identifier;
@property (readonly, nonatomic) unsigned long long settledState;
@property (readonly, nonatomic) NSDate *start;
@property (readonly, nonatomic) NSArray *accessPoints;

+ (id)createWithFingerprintMO:(id)a0;

- (id)init;
- (void).cxx_destruct;
- (id)managedObjectWithContext:(id)a0;
- (id)initWithIdentifier:(id)a0 settledState:(unsigned long long)a1 start:(id)a2 accessPoints:(id)a3;

@end
