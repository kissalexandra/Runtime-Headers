@interface ABImagePickerControllerAccessibility : __ABImagePickerControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)deletePhoto:(BOOL)a0;

@end
