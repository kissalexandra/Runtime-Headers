@class RTInvocationDispatcher, NSString, NSPredicate, RTPredictedApplicationManager, NSObject;
@protocol OS_dispatch_queue, RTDaemonClientRegistrarApplicationPredictionProtocol;

@interface RTDaemonClientRegistrarApplicationPrediction : RTDaemonClientRegistrar <NSSecureCoding, RTDaemonClientRegistrarProtocol> {
    BOOL _registered;
}

@property (class, readonly) BOOL supportsSecureCoding;

@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) RTPredictedApplicationManager *predictedApplicationManager;
@property (retain, nonatomic) NSPredicate *applicationPredicate;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (weak, nonatomic) id<RTDaemonClientRegistrarApplicationPredictionProtocol> delegate;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (BOOL)registered;
- (long long)countOfPendingInvocations;
- (BOOL)invocationsPending;
- (void)startMonitoringForPredictedApplicationsUsingPredicate:(id)a0;
- (void)stopMonitoringForPredictedApplications;
- (id)initWithPredictedApplicationManager:(id)a0 queue:(id)a1;
- (void)onPredictedApplicationNotification:(id)a0;
- (void)addPendingApplicationPredictionBlock:(id /* block */)a0 failBlock:(id /* block */)a1 description:(id)a2;
- (BOOL)evaluatePredicateKeyPath;

@end
