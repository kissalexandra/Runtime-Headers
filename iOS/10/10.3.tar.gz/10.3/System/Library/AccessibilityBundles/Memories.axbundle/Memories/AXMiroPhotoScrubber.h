@interface AXMiroPhotoScrubber : UIAccessibilityElement

- (struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })accessibilityFrame;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (unsigned long long)accessibilityTraits;
- (void)accessibilityIncrement;
- (void)accessibilityDecrement;
- (id)_axContainerCollectionView;
- (id)_axCurrentIndexPath;

@end
