@interface ATLGetDecoder : NSObject

+ (Class)getDecoderForApplet:(id)a0 withPackage:(id)a1 withModule:(id)a2;

@end
