@interface ZoomUI_SBLockScreenViewControllerOverride : __ZoomUI_SBLockScreenViewControllerOverride_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)finishUIUnlockFromSource:(int)a0;

@end
