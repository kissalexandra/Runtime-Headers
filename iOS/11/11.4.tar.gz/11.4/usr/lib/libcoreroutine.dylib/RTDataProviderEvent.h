@class NSString;

@interface RTDataProviderEvent : RTDataProvider <RTDataProviderEventProtocol>

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)supportedEventClasses;
- (BOOL)supportsEventClass:(Class)a0;
- (void)fetchAllEventsWithHandler:(id /* block */)a0;
- (void)fetchEventsBetweenStartDate:(id)a0 endDate:(id)a1 filterPredicate:(id)a2 sortDescriptors:(id)a3 handler:(id /* block */)a4;
- (void)fetchEventsWithFilterPredicate:(id)a0 sortDescriptors:(id)a1 handler:(id /* block */)a2;
- (void)__fetchEventsBetweenStartDate:(id)a0 endDate:(id)a1 filterPredicate:(id)a2 sortDescriptors:(id)a3 handler:(id /* block */)a4;

@end
