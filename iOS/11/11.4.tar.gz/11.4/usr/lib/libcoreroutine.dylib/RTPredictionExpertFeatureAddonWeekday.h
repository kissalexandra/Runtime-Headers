@interface RTPredictionExpertFeatureAddonWeekday : RTPredictionExpertFeatureAddon

@property (readonly, nonatomic) long long targetDays;

- (id)description;
- (long long)addonType;
- (id)initWithTargetDays:(long long)a0;
- (id)weekdayStringFromMask:(long long)a0;

@end
