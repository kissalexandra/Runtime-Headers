@interface AccessibilitySettingsLoader : NSObject

+ (void)initialize;
+ (void)_update;
+ (void)update;
+ (void)updateITunesSettings;
+ (void)_registerZoomNotificationListeners;
+ (void)_updateAccessibilitySpeakCorrections;
+ (void)_webKitInitialized;
+ (void)_accessibilityUserChangedRouteNotification:(id)a0;
+ (void)_updateITunesSettings;
+ (void)_updateAssistiveTouchInformation;

@end
