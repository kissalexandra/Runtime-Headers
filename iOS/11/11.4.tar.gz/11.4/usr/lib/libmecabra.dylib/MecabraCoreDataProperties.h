@class NSString, NSMutableDictionary;

@interface MecabraCoreDataProperties : NSObject

@property (retain, nonatomic) NSMutableDictionary *descriptionDictionary;
@property (readonly, retain, nonatomic) NSString *type;
@property (readonly, nonatomic) NSString *ubiquityContainerIdentifier;

+ (id)sharedInstanceForType:(id)a0;
+ (void)setDefaultDescriptionPath:(id)a0;
+ (id)defaultDescriptionPath;
+ (id)ubiquityContainerURL;

- (id)valueForKey:(id)a0;
- (void)dealloc;
- (id)initWithIdentifier:(id)a0;
- (id)sortDescriptors;
- (id)entityModelName;
- (id)uniqueKeys;
- (BOOL)databaseSyncs;
- (id)entityDescriptionURL;
- (id)ubiquitousURLWithSuffix:(id)a0;
- (id)ubiquitousStoreDirectoryURLForIdentifier:(id)a0;
- (id)ubiquitousTransactionURLForIdentifier:(id)a0;
- (void)forceNoSync;
- (id)requiredKeys;

@end
