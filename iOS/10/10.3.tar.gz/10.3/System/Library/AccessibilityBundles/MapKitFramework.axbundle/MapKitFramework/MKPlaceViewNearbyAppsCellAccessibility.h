@interface MKPlaceViewNearbyAppsCellAccessibility : __MKPlaceViewNearbyAppsCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityElements;

@end
