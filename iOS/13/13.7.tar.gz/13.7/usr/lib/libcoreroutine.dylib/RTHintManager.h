@class NSObject, RTNavigationManager, RTMetricManager, RTDarwinNotificationHelper, RTBatteryManager, NSString, RTReachabilityManager, RTPersistenceManager, RTWalletManager, RTLearnedLocationManager, RTCameraManager, RTLocationManager, RTBluetoothManager;
@protocol OS_dispatch_queue;

@interface RTHintManager : NSObject <RTPurgable>

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) RTBatteryManager *batteryManager;
@property (retain, nonatomic) RTBluetoothManager *bluetoothManager;
@property (retain, nonatomic) RTCameraManager *cameraManager;
@property (retain, nonatomic) RTDarwinNotificationHelper *notificationHelper;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTNavigationManager *navigationManager;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) RTReachabilityManager *reachabilityManager;
@property (retain, nonatomic) RTWalletManager *walletManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)boundingBoxPredicateForLocation:(id)a0;

- (id)init;
- (void).cxx_destruct;
- (void)_registerForNotifications;
- (void)_unregisterForNotifications;
- (void)shutdown;
- (id)initWithBatteryManager:(id)a0 bluetoothManager:(id)a1 cameraManager:(id)a2 learnedLocationManager:(id)a3 locationManager:(id)a4 metricManager:(id)a5 navigationManager:(id)a6 persistenceManager:(id)a7 reachabilityManager:(id)a8 walletManager:(id)a9;
- (void)performPurgeOfType:(long long)a0 referenceDate:(id)a1 completion:(id /* block */)a2;
- (void)onReachabilityChange:(id)a0;
- (void)_onReachabilityChange:(id)a0;
- (void)fetchHintStatsNearLocation:(id)a0 handler:(id /* block */)a1;
- (void)submitHintFromSource:(long long)a0 location:(id)a1;
- (void)_submitHintFromSource:(long long)a0;
- (void)onBluetoothNotification:(id)a0;
- (void)onBatteryNotification:(id)a0;
- (void)onNavigationNotification:(id)a0;
- (void)onCameraNotification:(id)a0;
- (void)onWalletNotification:(id)a0;
- (void)_submitHintFromSource:(long long)a0 location:(id)a1;
- (void)_submitHintFromSource:(long long)a0 location:(id)a1 managedObjectContext:(id)a2;
- (void)_fetchHintStatsNearLocation:(id)a0 managedObjectContext:(id)a1 handler:(id /* block */)a2;
- (void)_clearHintsPredating:(id)a0 managedObjectContext:(id)a1 handler:(id /* block */)a2;
- (void)_clearHintsPredating:(id)a0 handler:(id /* block */)a1;
- (void)_onBluetoothNotification:(id)a0;
- (void)_onBatteryNotification:(id)a0;
- (void)_onNavigationNotification:(id)a0;
- (void)_onCameraNotification:(id)a0;
- (void)_onWalletNotification:(id)a0;
- (void)fetchIsHintNearLocation:(id)a0 withHandler:(id /* block */)a1;

@end
