@interface OS_nw_protocol_socket : OS_object

- (void)_dispose;

@end
