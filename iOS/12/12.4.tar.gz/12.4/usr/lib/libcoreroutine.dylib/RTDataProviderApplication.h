@class NSString;

@interface RTDataProviderApplication : RTDataProviderDuet <RTDataProviderEventProtocol>

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)supportedEventClasses;
- (void)populateDataProviderWithHandler:(id /* block */)a0;
- (id)supportedEventStreams;

@end
