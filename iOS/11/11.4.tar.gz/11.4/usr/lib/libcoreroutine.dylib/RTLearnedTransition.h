@class NSString, NSUUID, NSDate;

@interface RTLearnedTransition : NSObject <RTCoreDataTransformable>

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;
@property (readonly, nonatomic) NSUUID *identifier;
@property (readonly, nonatomic) NSDate *startDate;
@property (readonly, nonatomic) NSDate *stopDate;
@property (readonly, nonatomic) NSUUID *visitIdentifierOrigin;
@property (readonly, nonatomic) NSUUID *visitIdentifierDestination;
@property (readonly, nonatomic) NSDate *creationDate;
@property (readonly, nonatomic) NSDate *expirationDate;

- (id)init;
- (void).cxx_destruct;
- (BOOL)isEqual:(id)a0;
- (id)managedObjectWithContext:(id)a0;
- (id)initWithTransitionMO:(id)a0;
- (id)initWithlocationOfInterestTransitionMO:(id)a0;
- (id)initWithIdentifier:(id)a0 startDate:(id)a1 stopDate:(id)a2 visitIdentifierOrigin:(id)a3 visitIdentifierDestination:(id)a4 creationDate:(id)a5 expirationDate:(id)a6;

@end
