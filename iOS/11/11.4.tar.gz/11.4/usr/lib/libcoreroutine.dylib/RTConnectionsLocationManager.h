@class NSObject;
@protocol OS_dispatch_queue;

@interface RTConnectionsLocationManager : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;

- (id)init;
- (void).cxx_destruct;
- (void)fetchRecentLocationsSince:(id)a0 withHandler:(id /* block */)a1;

@end
