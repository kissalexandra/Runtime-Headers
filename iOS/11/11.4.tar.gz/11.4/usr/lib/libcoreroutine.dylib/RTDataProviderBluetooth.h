@interface RTDataProviderBluetooth : RTDataProviderDuet

- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)supportedEventClasses;
- (id)supportedEventStreams;
- (void)populateDataProviderWithHandler:(id /* block */)a0;

@end
