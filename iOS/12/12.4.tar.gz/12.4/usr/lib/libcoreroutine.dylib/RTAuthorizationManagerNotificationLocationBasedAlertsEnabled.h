@interface RTAuthorizationManagerNotificationLocationBasedAlertsEnabled : RTNotification

@property (readonly, nonatomic) BOOL enabled;

- (id)initWithEnabled:(BOOL)a0;

@end
