@class RTEventModelProvider, RTLearnedLocationManager, EKEventStore, NSObject;
@protocol OS_dispatch_queue;

@interface RTEventManager : NSObject

@property (retain, nonatomic) EKEventStore *eventStore;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (nonatomic) BOOL accessToEventsGranted;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTEventModelProvider *eventModelProvider;

+ (BOOL)reasonableDistanceBetweenEventLocation:(id)a0 andLocation:(id)a1;

- (id)init;
- (void).cxx_destruct;
- (void)fetchPredictedLocationsOfInterestOnDate:(id)a0 withHandler:(id /* block */)a1;
- (void)fetchNextPredictedLocationsOfInterestFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 withHandler:(id /* block */)a3;
- (void)_fetchPredictedLocationsOfInterestBetweenStartDate:(id)a0 endDate:(id)a1 withHandler:(id /* block */)a2;
- (void)fetchPredictedLocationsOfInterestBetweenStartDate:(id)a0 endDate:(id)a1 withHandler:(id /* block */)a2;
- (id)initWithEventModelProvider:(id)a0 learnedLocationManager:(id)a1 queue:(id)a2;
- (id)accessDeniedError;
- (id)eventsBetweenStartDate:(id)a0 andEndDate:(id)a1 calendars:(id)a2;
- (id)eventsBetweenStartDate:(id)a0 andEndDate:(id)a1;
- (id)eventsSortedByEndDateBetweenStartDate:(id)a0 andEndDate:(id)a1;
- (id)eventsSortedByStartDateBetweenStartDate:(id)a0 andEndDate:(id)a1;
- (id)eventsSortedByStartDateBetweenStartDate:(id)a0 andEndDate:(id)a1 calendars:(id)a2;
- (id)calendars;
- (id)nextPredictedLocationsOfInterestCalendars;
- (void)fetchCurrentlyInEventWithHandler:(id /* block */)a0;
- (void)fetchNextFreeStartDateWithHandler:(id /* block */)a0;
- (void)fetchLastEventEndDateWithHandler:(id /* block */)a0;
- (void)fetchFreeDateIntervalsBetweenStartDate:(id)a0 endDate:(id)a1 filterAllDayEvents:(BOOL)a2 filterFreeTimeEvents:(BOOL)a3 handler:(id /* block */)a4;
- (void)fetchEventsBetweenStartDate:(id)a0 andEndDate:(id)a1 withHandler:(id /* block */)a2;
- (void)_fetchEventsBetweenStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)fetchEventsBetweenStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_fetchPredictedLocationsOfInterestOnDate:(id)a0 withHandler:(id /* block */)a1;
- (void)_fetchLocationOfInterestForEvent:(id)a0 withHandler:(id /* block */)a1;
- (void)_fetchPredictedLocationOfInterestAtEvent:(id)a0 withHandler:(id /* block */)a1;

@end
