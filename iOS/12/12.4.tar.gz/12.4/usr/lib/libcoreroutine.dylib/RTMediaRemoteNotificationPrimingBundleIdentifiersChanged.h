@class NSSet;

@interface RTMediaRemoteNotificationPrimingBundleIdentifiersChanged : RTNotification

@property (readonly, copy, nonatomic) NSSet *bundleIdentifiers;

- (id)initWithBundleIdentifiers:(id)a0;
- (void).cxx_destruct;

@end
