@class NSString, RTPersistenceManager, RTPowerAssertion, RTKeepAliveTransaction, RTDefaultsManager, NSObject, RTInvocationDispatcher, RTMemoryTransaction;
@protocol OS_dispatch_queue;

@interface RTPersistenceMirroringManager : NSObject <RTPersistenceMirroringDelegate> {
    NSObject<OS_dispatch_queue> *_queue;
    RTPersistenceManager *_persistenceManager;
    RTDefaultsManager *_defaultsManager;
    RTPowerAssertion *_powerAssertion;
    RTMemoryTransaction *_memoryTransaction;
    RTKeepAliveTransaction *_keepAliveTransaction;
    RTInvocationDispatcher *_dispatcher;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)performMirroringRequestWithType:(long long)a0 affectedStore:(id)a1 qualityOfService:(long long)a2 handler:(id /* block */)a3;
- (id)initWithPersistenceManager:(id)a0 defaultsManager:(id)a1;
- (void)performMirroringRequestWithType:(long long)a0 affectedStore:(id)a1 qualityOfService:(long long)a2 managedObjectContext:(id)a3 handler:(id /* block */)a4;
- (void)_performMirroringRequestWithType:(long long)a0 affectedStore:(id)a1 qualityOfService:(long long)a2 managedObjectContext:(id)a3 handler:(id /* block */)a4;
- (void)persistenceAvailabilityDidChange:(id)a0;
- (void)_persistenceAvailabilityDidChange:(id)a0;

@end
