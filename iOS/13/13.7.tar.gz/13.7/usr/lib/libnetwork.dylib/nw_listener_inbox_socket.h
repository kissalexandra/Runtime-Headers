@interface nw_listener_inbox_socket : nw_listener_inbox {
    void *_source;
    int _sockfd_for_logging_only_do_not_close_or_use;
    int _sockfd_from_client;
    unsigned char _ipProtocol;
    unsigned char _listenUUID[16];
}

- (id)description;
- (BOOL)cancel;
- (BOOL)resume;
- (id)start;
- (BOOL)suspend;
- (id)initWithParameters:(id)a0 delegate:(id)a1;
- (id)initWithSocket:(int)a0 parameters:(id)a1 delegate:(id)a2;
- (id)initWithParameters:(id)a0 delegate:(id)a1 necpUUID:(unsigned char[16])a2;

@end
