@class NSNumber, RTPredictionTableEntryMO;

@interface RTPredictionItemMO : NSManagedObject

@property (retain, nonatomic) NSNumber *confidence;
@property (retain, nonatomic) RTPredictionTableEntryMO *entry;

@end
