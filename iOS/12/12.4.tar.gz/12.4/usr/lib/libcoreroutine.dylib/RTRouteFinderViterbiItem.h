@class GEOMapFeatureRoad, NSString, NSArray;

@interface RTRouteFinderViterbiItem : NSObject

@property (retain, nonatomic) GEOMapFeatureRoad *road;
@property (retain, nonatomic) NSString *uniqueRoadID;
@property (nonatomic) double cost;
@property (retain, nonatomic) RTRouteFinderViterbiItem *bestPrevItem;
@property (copy, nonatomic) NSArray *routeFromBestPreviousItem;

- (id)initWithRoad:(id)a0;
- (id)init;
- (void).cxx_destruct;
- (id)description;

@end
