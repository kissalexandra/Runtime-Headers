@interface NWConcrete_nw_srv_endpoint : NWConcrete_nw_endpoint {
    char *name;
}

- (void)dealloc;
- (unsigned int)type;
- (id)copyDictionary;
- (id)initWithName:(const char *)a0;
- (char *)createDescription:(BOOL)a0;
- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1 matchParent:(BOOL)a2;
- (id)copyEndpoint;
- (unsigned long long)getHash;
- (const char *)domainForPolicy;

@end
