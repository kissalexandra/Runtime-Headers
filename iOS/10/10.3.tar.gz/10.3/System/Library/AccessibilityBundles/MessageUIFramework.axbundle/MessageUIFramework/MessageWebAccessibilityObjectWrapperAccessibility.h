@interface MessageWebAccessibilityObjectWrapperAccessibility : __MessageWebAccessibilityObjectWrapperAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;
- (BOOL)_axIsAttachmentType;

@end
