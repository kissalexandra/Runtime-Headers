@class RTInvocationDispatcher, RTEventModelProvider, RTLearnedLocationManager, NSString, NSObject, RTMapServiceManager;
@protocol OS_dispatch_queue;

@interface RTEventManager : NSObject <RTTransientObjectProtocol>

@property (retain, nonatomic) RTInvocationDispatcher *invocationDispatcher;
@property (retain, nonatomic) RTEventModelProvider *eventModelProvider;
@property (retain, nonatomic) id eventStore;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (nonatomic) BOOL accessToEventsGranted;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (BOOL)reasonableDistanceBetweenEventLocation:(id)a0 andLocation:(id)a1;

- (void)fetchPredictedLocationsOfInterestOnDate:(id)a0 withHandler:(id /* block */)a1;
- (void)fetchNextPredictedLocationsOfInterestFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 withHandler:(id /* block */)a3;
- (void)fetchPredictedLocationsOfInterestBetweenStartDate:(id)a0 endDate:(id)a1 withHandler:(id /* block */)a2;
- (id)initWithEventModelProvider:(id)a0 learnedLocationManager:(id)a1 mapServiceManager:(id)a2 queue:(id)a3;
- (void)_fetchNextPredictedLocationsOfInterestFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 withHandler:(id /* block */)a3;
- (void)fetchEventsBetweenStartDate:(id)a0 andEndDate:(id)a1 withHandler:(id /* block */)a2;
- (void)_fetchPredictedLocationsOfInterestBetweenStartDate:(id)a0 endDate:(id)a1 withHandler:(id /* block */)a2;
- (void)transientObjectDidCreateBackingObject:(id)a0;
- (void)transientObjectDidReleaseBackingObject:(id)a0;
- (void)fetchNextFreeStartDateWithHandler:(id /* block */)a0;
- (void)fetchLastEventEndDateWithHandler:(id /* block */)a0;
- (void)fetchFreeDateIntervalsBetweenStartDate:(id)a0 endDate:(id)a1 filterAllDayEvents:(BOOL)a2 filterFreeTimeEvents:(BOOL)a3 handler:(id /* block */)a4;
- (id)initWithEventModelProvider:(id)a0 eventStore:(id)a1 learnedLocationManager:(id)a2 mapServiceManager:(id)a3 queue:(id)a4;
- (id)eventsBetweenStartDate:(id)a0 andEndDate:(id)a1 calendars:(id)a2;
- (id)eventsBetweenStartDate:(id)a0 andEndDate:(id)a1;
- (id)calendars;
- (void)_fetchCurrentlyInEventWithHandler:(id /* block */)a0;
- (id)eventsSortedByStartDateBetweenStartDate:(id)a0 andEndDate:(id)a1;
- (void)_fetchNextFreeStartDateWithHandler:(id /* block */)a0;
- (void)_fetchLastEventEndDateWithHandler:(id /* block */)a0;
- (id)eventsSortedByEndDateBetweenStartDate:(id)a0 andEndDate:(id)a1;
- (void)_fetchFreeDateIntervalsBetweenStartDate:(id)a0 endDate:(id)a1 filterAllDayEvents:(BOOL)a2 filterFreeTimeEvents:(BOOL)a3 handler:(id /* block */)a4;
- (void)_fetchEventsBetweenStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (void)_fetchEventsBetweenStartDate:(id)a0 andEndDate:(id)a1 withHandler:(id /* block */)a2;
- (id)nextPredictedLocationsOfInterestCalendars;
- (id)eventsSortedByStartDateBetweenStartDate:(id)a0 andEndDate:(id)a1 calendars:(id)a2;
- (void)_fetchLocationOfInterestForEvent:(id)a0 withHandler:(id /* block */)a1;
- (void)_fetchPredictedLocationsOfInterestOnDate:(id)a0 withHandler:(id /* block */)a1;
- (void)_fetchPredictedLocationOfInterestAtEvent:(id)a0 withHandler:(id /* block */)a1;
- (void)fetchCurrentlyInEventWithHandler:(id /* block */)a0;
- (void)fetchEventsBetweenStartDate:(id)a0 endDate:(id)a1 handler:(id /* block */)a2;
- (id)init;
- (void).cxx_destruct;

@end
