@interface MiroContentEditorViewControllerAccessibility : __MiroContentEditorViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)viewDidLoad;
- (void)_accessibilityLoadAccessibilityInformation;
- (void)clipCollection:(id)a0 didSnapToIndexPath:(id)a1;

@end
