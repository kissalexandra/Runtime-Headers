@class NSArray;

@interface RTLocationManagerNotificationPredictedApplications : RTNotification

@property (readonly, nonatomic) NSArray *predictedApplications;

- (id)init;
- (void).cxx_destruct;
- (id)initWithPredictedApplications:(id)a0;

@end
