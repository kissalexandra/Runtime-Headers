@class NSArray;

@interface RTEventMicroLocation : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly, nonatomic) NSArray *microLocations;

- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (id)description;
- (id)initWithStartDate:(id)a0 endDate:(id)a1 source:(long long)a2 identifier:(id)a3;
- (id)initWithStartDate:(id)a0 endDate:(id)a1 source:(long long)a2 identifier:(id)a3 microLocations:(id)a4;

@end
