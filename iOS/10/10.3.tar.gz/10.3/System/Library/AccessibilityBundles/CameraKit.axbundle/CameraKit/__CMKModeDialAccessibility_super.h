@interface __CMKModeDialAccessibility_super : UIAccessibilitySafeCategory

@end
