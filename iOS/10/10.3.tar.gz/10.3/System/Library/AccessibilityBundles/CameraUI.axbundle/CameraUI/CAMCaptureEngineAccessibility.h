@interface CAMCaptureEngineAccessibility : __CAMCaptureEngineAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_accessibilityDetectFaces:(BOOL)a0 completionBlock:(id /* block */)a1;
- (void)_accessibilityLoadAccessibilityInformation;
- (void)_handleSessionDidStartRunning:(id)a0;
- (void)_handleSessionDidStopRunning:(id)a0;

@end
