@class NSString, RTPersistenceStore, NSURL, NSArray, RTPersistenceContainer, NSManagedObjectModel;
@protocol RTPersistenceDelegate, RTPersistenceMirroringDelegate;

@interface RTPersistenceManager : RTNotifier <RTPersistenceModelProvider, RTPersistenceContextDelegate> {
    RTPersistenceStore *_stores[3];
    NSURL *_modelsDirectory;
    NSURL *_storesDirectory;
    NSArray *_sortedModelNames;
    RTPersistenceContainer *_container;
    NSManagedObjectModel *_latestModel;
}

@property unsigned long long availability;
@property (weak, nonatomic) id<RTPersistenceDelegate> delegate;
@property (weak, nonatomic) id<RTPersistenceMirroringDelegate> mirroringDelegate;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)defaultStoresDirectory;
+ (id)defaultModelsDirectory;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)setContainer:(id)a0;
- (id)managedObjectContext;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)performImportMirroringRequest:(id /* block */)a0;
- (void)performExportMirroringRequest:(id /* block */)a0;
- (void)performZoneResetMirroringRequest:(id /* block */)a0;
- (id)waitForPersistenceContext;
- (void)persistenceContext:(id)a0 encounteredError:(id)a1;
- (void)persistenceContextPerformedSave:(id)a0;
- (id)latestModel;
- (id)modelFollowingModel:(id)a0;
- (id)initWithModelsDirectory:(id)a0 storesDirectory:(id)a1;
- (BOOL)initializeContainer;
- (void)createManagedObjectContext:(id /* block */)a0;
- (void)setupPersistenceContainers:(id /* block */)a0;
- (BOOL)_setupPersistenceContainers;
- (id)URLForStoreType:(unsigned long long)a0;
- (unsigned long long)storeTypeForURL:(id)a0;
- (id)persistenceStoreConfigurations;
- (id)storeDescriptionForStoreWithType:(unsigned long long)a0;
- (void)_updateStoreAvailability:(unsigned long long)a0;
- (id)sortedModelNames;
- (id)modelNamed:(id)a0;
- (void)performMirroringRequestOfType:(long long)a0 qualityOfService:(long long)a1 handler:(id /* block */)a2;
- (void)performImportMirroringRequestWithQualityOfService:(long long)a0 handler:(id /* block */)a1;
- (void)performExportMirroringRequestWithQualityOfService:(long long)a0 handler:(id /* block */)a1;
- (void)performZoneResetMirroringRequestWithQualityOfService:(long long)a0 handler:(id /* block */)a1;
- (void)onCoreDataResetSync:(id)a0;
- (void)_onCoreDataResetSync:(id)a0;

@end
