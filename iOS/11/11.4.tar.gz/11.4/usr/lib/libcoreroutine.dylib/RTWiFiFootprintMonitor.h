@class RTWiFiManager, NSMutableArray, RTPersistentTimer;

@interface RTWiFiFootprintMonitor : RTNotifier

@property (nonatomic) long long footprintState;
@property (retain, nonatomic) RTPersistentTimer *scanTimer;
@property (retain, nonatomic) NSMutableArray *scanResults;
@property (retain, nonatomic) RTWiFiManager *wifiManager;

+ (id)footprintStateToString:(long long)a0;

- (id)init;
- (void).cxx_destruct;
- (void)_start;
- (void)_stop;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithWiFiManager:(id)a0;
- (void)onWiFiManagerNotificationScanResults:(id)a0;
- (void)onWiFiManagerNotificationPowerStatusChanged:(id)a0;
- (void)_handlePowerStatusChanged:(unsigned long long)a0;
- (void)fetchConstantFootprintStatusForScanResults:(id)a0 withHandler:(id /* block */)a1;
- (long long)_footprintStateForScanResults:(id)a0;
- (void)_checkFootprint;
- (void)_processScanResults:(id)a0;
- (void)_pruneScanResults;

@end
