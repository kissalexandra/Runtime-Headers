@interface __ABPersonTableViewAccessibility_super : UIAccessibilitySafeCategory

@end
