@interface RTPredictionItem : NSObject <NSCopying>

@property (readonly, nonatomic) double confidence;

- (id)initWithConfidence:(double)a0;
- (id)init;
- (id)copyWithZone:(struct _NSZone { } *)a0;

@end
