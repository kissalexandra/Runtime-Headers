@interface RTReachabilityManager : RTService

@property (nonatomic) struct __SCNetworkReachability { } *reachabilityRef;
@property (readonly, nonatomic) long long currentReachability;

+ (long long)_processReachabilityChange:(unsigned int)a0;
+ (id)reachabilityToString:(long long)a0;

- (void)setCurrentReachability:(long long)a0;
- (void)_shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_startMonitoringReachability;
- (void)_stopMonitoringReachability;
- (BOOL)_getCurrentReachability:(unsigned int *)a0;
- (id)currentReachabilityString;
- (void)_fetchCurrentReachability:(id /* block */)a0;
- (void)processReachabilityChange:(unsigned int)a0;
- (void)fetchCurrentReachability:(id /* block */)a0;
- (id)init;
- (id)description;

@end
