@class NSString, NSDate;

@interface RTWiFiAccessPoint : NSObject

@property (readonly, nonatomic) NSString *mac;
@property (readonly, nonatomic) NSString *ssid;
@property (readonly, nonatomic) long long rssi;
@property (readonly, nonatomic) long long mode;
@property (readonly, nonatomic) long long channel;
@property (readonly, nonatomic) BOOL adHoc;
@property (readonly, nonatomic) BOOL captiveNetwork;
@property (readonly, nonatomic) BOOL applePersonalHotspot;
@property (readonly, nonatomic) BOOL carPlay;
@property (readonly, nonatomic) double age;
@property (readonly, nonatomic) NSDate *date;

+ (id)createWithWiFiAccessPointMO:(id)a0;

- (void).cxx_destruct;
- (id)description;
- (id)initWithMac:(id)a0 ssid:(id)a1 rssi:(long long)a2 mode:(long long)a3 channel:(long long)a4 adHoc:(BOOL)a5 captiveNetwork:(BOOL)a6 applePersonalHotspot:(BOOL)a7 carPlay:(BOOL)a8 age:(double)a9 date:(id)a10;
- (id)initWithWiFiNetwork:(struct __WiFiNetwork { } *)a0;

@end
