@interface __MPUSkipLimitViewAccessibility_super : UIAccessibilitySafeCategory

@end
