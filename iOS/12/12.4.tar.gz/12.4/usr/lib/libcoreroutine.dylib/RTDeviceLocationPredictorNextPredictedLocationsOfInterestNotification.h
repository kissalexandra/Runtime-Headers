@class NSArray;

@interface RTDeviceLocationPredictorNextPredictedLocationsOfInterestNotification : RTNotification

@property (retain, nonatomic) NSArray *nextPredictedLocationsOfInterest;

- (id)initWithNextPredictedLocationsOfInterest:(id)a0;
- (void).cxx_destruct;

@end
