@class NSManagedObjectModel, RTPersistenceStore, NSPersistentStoreCoordinator;
@protocol RTPersistenceDelegate, RTPersistenceModelProvider;

@interface RTPersistenceMigrator : NSObject {
    NSPersistentStoreCoordinator *_cachedCoordinator;
}

@property (readonly, weak) RTPersistenceStore *store;
@property (readonly, weak) id<RTPersistenceModelProvider> modelProvider;
@property (readonly, weak) id<RTPersistenceDelegate> delegate;
@property unsigned long long state;
@property (retain, nonatomic) NSManagedObjectModel *nextModel;
@property (readonly) unsigned long long status;

- (id)init;
- (void).cxx_destruct;
- (unsigned long long)run;
- (id)initWithStore:(id)a0 modelProvider:(id)a1 delegate:(id)a2;
- (id)_coordinatorForModel:(id)a0;
- (void)_attemptMigration;
- (void)_executeSingleMigrationStep;
- (unsigned long long)_executeOpenStep;
- (unsigned long long)_executeVacuumStep;
- (unsigned long long)_executePrepareStep;
- (unsigned long long)_executeCacheStep;
- (unsigned long long)_executeMigrateStep;
- (unsigned long long)_executeDestroyStep;
- (unsigned long long)_executeRecreateStep;

@end
