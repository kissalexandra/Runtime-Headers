@class NSObject;
@protocol OS_dispatch_queue, _DKKnowledgeQuerying;

@interface RTPredictedContentManager : NSObject {
    NSObject<OS_dispatch_queue> *_queue;
    id<_DKKnowledgeQuerying> _knowledgeStore;
}

@property (readonly) id<_DKKnowledgeQuerying> knowledgeStore;

- (id)init;
- (void).cxx_destruct;
- (id)initWithKnowledgeStore:(id)a0;
- (id)_initWithKnowledgeStore:(id)a0;
- (void)fetchPredictedContentForBundleWithIdentifier:(id)a0 handler:(id /* block */)a1;
- (void)_fetchPredictedContentForBundleWithIdentifier:(id)a0 handler:(id /* block */)a1;

@end
