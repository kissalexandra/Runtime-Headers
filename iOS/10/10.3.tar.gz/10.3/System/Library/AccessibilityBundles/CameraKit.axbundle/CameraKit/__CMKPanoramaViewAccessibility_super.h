@interface __CMKPanoramaViewAccessibility_super : UIAccessibilitySafeCategory

@end
