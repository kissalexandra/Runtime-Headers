@class NSMutableArray, NSDate;

@interface RTLearnedLocationEngineTrainingMetrics : NSObject

@property (nonatomic) BOOL trainedVisits;
@property (readonly, nonatomic) NSDate *trainVisitsStart;
@property (readonly, nonatomic) NSDate *trainVisitsStop;
@property (nonatomic) double intervalSinceLastAttempt;
@property (nonatomic) unsigned long long locationsProcessed;
@property (nonatomic) double maxIntervalBetweenLocations;
@property (readonly, nonatomic) NSMutableArray *visits;
@property (readonly, nonatomic) NSMutableArray *places;
@property (nonatomic) unsigned long long visitCountDevice;
@property (nonatomic) unsigned long long visitCountTotal;
@property (nonatomic) unsigned long long placeCountDevice;
@property (nonatomic) unsigned long long placeCountTotal;

- (id)init;
- (id)description;
- (void).cxx_destruct;
- (double)latency;
- (void)submitVisit:(id)a0 possibleMapItems:(id)a1 selectedMapItem:(id)a2;
- (void)submitPlace:(id)a0 nearbyPlaces:(id)a1;
- (void)startTrainingVisits;
- (void)stopTrainingVisits;

@end
