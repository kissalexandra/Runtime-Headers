@interface RTEventDeviceFirstWakeup : RTEventDevice

@property (readonly, nonatomic) long long wakeupState;

+ (BOOL)supportsSecureCoding;

- (id)initWithDeviceWakeupState:(long long)a0 source:(long long)a1 startDate:(id)a2 endDate:(id)a3;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;

@end
