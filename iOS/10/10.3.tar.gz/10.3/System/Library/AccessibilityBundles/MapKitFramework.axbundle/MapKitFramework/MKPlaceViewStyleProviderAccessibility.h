@interface MKPlaceViewStyleProviderAccessibility : __MKPlaceViewStyleProviderAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (id)attributionStringWithTitle:(id)a0 displayName:(id)a1 logo:(id)a2 isSnippetLogo:(BOOL)a3;
+ (Class)safeCategoryBaseClass;

@end
