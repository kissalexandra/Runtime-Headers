@interface ABPersonTableViewAccessibility : __ABPersonTableViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (BOOL)_accessibilityHitTestShouldFallbackToNearestChild;
- (id)_accessibilitySupplementaryHeaderViews;

@end
