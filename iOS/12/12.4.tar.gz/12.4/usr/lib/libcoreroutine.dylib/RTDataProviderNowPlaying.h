@interface RTDataProviderNowPlaying : RTDataProviderDuet

- (id)supportedEventClasses;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithPurgeManager:(id)a0 locationTagger:(id)a1 defaultsManager:(id)a2;
- (void)populateDataProviderWithHandler:(id /* block */)a0;
- (id)supportedEventStreams;
- (id)init;

@end
