@interface MKMapAttributionAccessibility : __MKMapAttributionAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithStringAttributes:(id)a0 regionalAttributions:(id)a1 globalAttributions:(id)a2 scale:(double)a3 allowMultiLine:(BOOL)a4;

@end
