@class NSString, NSUUID, NSDate, GEORoute;

@interface RTGeoRoute : NSObject <RTCoreDataTransformable>

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;
@property (readonly, nonatomic) GEORoute *geoRoute;
@property (readonly, nonatomic) NSUUID *identifier;
@property (readonly, nonatomic) NSUUID *originLocationOfInterestIdentifier;
@property (readonly, nonatomic) NSUUID *destinationLocationOfInterestIdentifier;
@property (readonly, nonatomic) NSDate *creationDate;

- (id)managedObjectWithContext:(id)a0;
- (id)initWithGEORoute:(id)a0 identifier:(id)a1 originLocationOfInterestIdentifier:(id)a2 destinationLocationOfInterestIdentifier:(id)a3 creationDate:(id)a4;
- (id)initWithGEORoute:(id)a0 originLocationOfInterestIdentifier:(id)a1 destinationLocationOfInterestIdentifier:(id)a2;
- (id)initWithGeoRouteMO:(id)a0;
- (void).cxx_destruct;

@end
