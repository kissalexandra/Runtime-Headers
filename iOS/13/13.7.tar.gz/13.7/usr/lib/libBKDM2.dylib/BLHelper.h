@interface BLHelper : NSObject

+ (id)buildVersion;
+ (id)deviceSerialNumber;
+ (id)bootArgs;
+ (id)encryptData:(id)a0;
+ (id)stringFromSequenceType:(unsigned int)a0;
+ (id)stringFromFrameType:(unsigned int)a0;
+ (id)numberForBootArg:(id)a0;
+ (id)numberFromDouble:(double)a0;
+ (id)numberFromFloat:(float)a0;
+ (id)deviceBatteryLevel;
+ (void)writeTailspinToFile:(id)a0;
+ (void)displayUserPrompt:(unsigned long long)a0 strings:(id)a1 completion:(id /* block */)a2;
+ (id)objectOrNSNull:(id)a0;

@end
