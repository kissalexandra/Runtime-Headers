@interface CAMViewfinderViewAccessibility : __CAMViewfinderViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)shouldGroupAccessibilityChildren;

@end
