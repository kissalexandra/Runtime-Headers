@class NSArray, NSString, NSObject;
@protocol OS_dispatch_queue;

@interface RTEventStore : NSObject <RTEventStore, RTEventStoreAppLaunch, NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) NSArray *applicableEventClasses;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)setUnderlyingQueue:(id)a0;
- (void)invalidate;
- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (void)addEvent:(id)a0;
- (void)addEvents:(id)a0;
- (void)removeEvent:(id)a0;
- (void)removeEvents:(id)a0;
- (unsigned long long)countOfEvents;
- (void)clearAllEvents;
- (void)_processEventsWithGlobalAppLaunchCountedSet:(id)a0 handler:(id /* block */)a1;
- (void)fetchAllPredictionsWithHandler:(id /* block */)a0;
- (BOOL)storesEventOfClass:(Class)a0;
- (id)initWithApplicableEventClasses:(id)a0;
- (double)getConfidence;
- (void)addAppLaunchEvent:(id)a0;

@end
