@class NSString;

@interface RTContactPostalAddress : NSObject

@property (readonly, nonatomic) NSString *identifier;
@property (readonly, nonatomic) unsigned long long labelType;
@property (readonly, nonatomic) NSString *street;
@property (readonly, nonatomic) NSString *subLocality;
@property (readonly, nonatomic) NSString *city;
@property (readonly, nonatomic) NSString *subAdministrativeArea;
@property (readonly, nonatomic) NSString *state;
@property (readonly, nonatomic) NSString *postalCode;
@property (readonly, nonatomic) NSString *country;
@property (readonly, nonatomic) NSString *ISOCountryCode;

+ (id)labelTypeToString:(unsigned long long)a0;

- (id)init;
- (void).cxx_destruct;
- (id)description;
- (id)dictionaryRepresentation;
- (id)initWithIdentifier:(id)a0 lableType:(unsigned long long)a1 street:(id)a2 subLocality:(id)a3 city:(id)a4 subAdministrativeArea:(id)a5 state:(id)a6 postalCode:(id)a7 country:(id)a8 ISOCountryCode:(id)a9;
- (id)initWithIdentifier:(id)a0 lableType:(unsigned long long)a1 geoDictionary:(id)a2;
- (id)geoDictionaryRepresentation;

@end
