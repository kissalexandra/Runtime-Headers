@class CNContactStore, CNContact;

@interface RTContacts : NSObject

@property (retain, nonatomic) CNContact *meCard;
@property (retain, nonatomic) CNContactStore *contactStore;

+ (id)addressLabelTypeToString:(long long)a0;
+ (id)addressLabelTypeToLabel:(long long)a0;
+ (id)convertAddressDictionaryFromGeoServicesToContacts:(id)a0;
+ (id)addressDictionaryStructuredForGeoServicesFromMapItem:(id)a0;
+ (id)convertAddressDictionaryFromContactsToGeoServices:(id)a0;
+ (id)contactFetchKeys;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)updateMeCard;
- (id)postalAddressesFromContact:(id)a0 withAddressLabelType:(long long)a1;
- (id)geocodePostalAddress:(id)a0 error:(id *)a1;
- (id)mapItemsOfContact:(id)a0 withAddressLabelType:(long long)a1 error:(id *)a2;
- (id)addressIdentifierOfContact:(id)a0 withAddressFromMapItem:(id)a1 error:(id *)a2;
- (id)addressIdentifierOfMeCardWithAddressFromMapItem:(id)a0 error:(id *)a1;
- (BOOL)updateAddressOfContact:(id)a0 withAddressIdentifier:(id)a1 toAddressFromMapItem:(id)a2 error:(id *)a3;
- (BOOL)updateAddressOfMeCardWithAddressIdentifier:(id)a0 toAddressFromMapItem:(id)a1 error:(id *)a2;
- (BOOL)updateAddressLabelTypeOfContact:(id)a0 withAddressIdentifier:(id)a1 toAddressLabelType:(long long)a2 error:(id *)a3;
- (BOOL)updateAddressLabelTypeOfMeCardWithAddressIdentifier:(id)a0 toAddressLabelType:(long long)a1 error:(id *)a2;
- (id)addAddressToContact:(id)a0 addressLabelType:(long long)a1 addressFromMapItem:(id)a2 error:(id *)a3;
- (id)addAddressToMeCardWithAddressLabelType:(long long)a0 addressFromMapItem:(id)a1 error:(id *)a2;
- (BOOL)removeAddressOfContact:(id)a0 withAddressIdentifier:(id)a1 error:(id *)a2;
- (BOOL)removeAddressOfMeCardWithAddressIdentifier:(id)a0 error:(id *)a1;

@end
