@class NSString;

@interface RTEventAppLaunch : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly, nonatomic) NSString *bundleId;
@property (readonly, nonatomic) long long appLaunchState;

+ (id)stringFromAppLaunchState:(long long)a0;

- (id)initWithBundleId:(id)a0 appLaunchState:(long long)a1 source:(long long)a2 startDate:(id)a3 endDate:(id)a4;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (id)description;

@end
