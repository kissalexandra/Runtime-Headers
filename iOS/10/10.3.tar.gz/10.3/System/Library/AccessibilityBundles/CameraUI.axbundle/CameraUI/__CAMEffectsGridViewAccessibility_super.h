@interface __CAMEffectsGridViewAccessibility_super : UIAccessibilitySafeCategory

@end
