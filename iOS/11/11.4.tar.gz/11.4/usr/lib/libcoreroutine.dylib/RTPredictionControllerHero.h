@class RTDataProviderHeroApp, RTApplicationManager;

@interface RTPredictionControllerHero : RTNotifier

@property (retain, nonatomic) RTDataProviderHeroApp *dataProvider;
@property (retain, nonatomic) RTApplicationManager *applicationManager;

- (id)init;
- (void)invalidate;
- (void).cxx_destruct;
- (void)dealloc;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)_startMonitoringForPredictedApplications;
- (void)onHeroAppPrediction:(id)a0;
- (void)_onHeroAppPrediction:(id)a0;
- (void)_stopMonitoringForPredictedApplications;
- (void)fetchPredictedApplications:(id /* block */)a0;
- (void)fetchPredictedApplicationsAtLocation:(id)a0 handler:(id /* block */)a1;
- (void)fetchPredictedApplicationsWithPredicate:(id)a0 handler:(id /* block */)a1;
- (void)stopMonitoringForPredictedApplications;
- (id)initWithDataProvider:(id)a0 applicationManager:(id)a1;
- (void)startMonitoringForPredictedApplications;
- (void)onApplicationChange:(id)a0;
- (void)_onApplicationChange:(id)a0;
- (void)_refreshAllData;

@end
