@interface CAMApplicationDelegateAccessibility : __CAMApplicationDelegateAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_accessibilityLoadAccessibilityInformation;

@end
