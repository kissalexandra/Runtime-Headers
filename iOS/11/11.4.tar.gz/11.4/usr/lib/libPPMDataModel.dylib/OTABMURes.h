@interface OTABMURes : PBCodable <NSCopying> {
    struct { unsigned char rDownstream : 1; unsigned char rSystem : 1; unsigned char rTrace25c : 1; unsigned char rTraceTempco : 1; } _has;
}

@property (nonatomic) BOOL hasRTrace25c;
@property (nonatomic) float rTrace25c;
@property (nonatomic) BOOL hasRTraceTempco;
@property (nonatomic) float rTraceTempco;
@property (nonatomic) BOOL hasRDownstream;
@property (nonatomic) float rDownstream;
@property (nonatomic) BOOL hasRSystem;
@property (nonatomic) float rSystem;

- (BOOL)readFrom:(id)a0;
- (void)writeTo:(id)a0;
- (void)copyTo:(id)a0;
- (void)mergeFrom:(id)a0;
- (BOOL)isEqual:(id)a0;
- (unsigned long long)hash;
- (id)description;
- (id)copyWithZone:(struct _NSZone { } *)a0;
- (id)dictionaryRepresentation;

@end
