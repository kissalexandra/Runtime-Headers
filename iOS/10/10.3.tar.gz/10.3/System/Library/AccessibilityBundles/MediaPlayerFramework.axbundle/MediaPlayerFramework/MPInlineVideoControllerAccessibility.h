@interface MPInlineVideoControllerAccessibility : __MPInlineVideoControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_hideOverlayDidEnd;
- (void)_showOverlayDidEnd:(BOOL)a0;

@end
