@interface MPUEmphasizedTextAccessibility : __MPUEmphasizedTextAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;

@end
