@class NewMSPQuery, RTInvocationDispatcher;

@interface RTMapsSupportQueryState : NSObject

@property (readonly, nonatomic) unsigned long long type;
@property (readonly, nonatomic) RTInvocationDispatcher *dispatcher;
@property (nonatomic) BOOL loaded;
@property (retain, nonatomic) NewMSPQuery *query;

+ (id)queryTypeToString:(unsigned long long)a0;

- (id)init;
- (id)description;
- (void).cxx_destruct;
- (id)initWithType:(unsigned long long)a0 dispatcher:(id)a1;

@end
