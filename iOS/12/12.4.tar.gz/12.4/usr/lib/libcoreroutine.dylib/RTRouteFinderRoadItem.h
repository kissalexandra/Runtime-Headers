@class GEOMapFeatureRoad, NSString;

@interface RTRouteFinderRoadItem : NSObject

@property (retain, nonatomic) GEOMapFeatureRoad *road;
@property (retain, nonatomic) NSString *uniqueID;
@property (nonatomic) double distance;
@property (nonatomic) double cost;
@property (retain, nonatomic) RTRouteFinderRoadItem *prevRoadItem;

- (id)initWithRoad:(id)a0 distance:(double)a1 cost:(double)a2 prevRoadItem:(id)a3;
- (id)initWithRoad:(id)a0 distance:(double)a1 cost:(double)a2;
- (void).cxx_destruct;
- (id)description;
- (long long)compare:(id)a0;

@end
