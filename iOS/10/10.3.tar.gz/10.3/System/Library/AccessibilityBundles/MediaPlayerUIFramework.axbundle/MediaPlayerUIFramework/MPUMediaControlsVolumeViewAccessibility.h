@interface MPUMediaControlsVolumeViewAccessibility : __MPUMediaControlsVolumeViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithStyle:(long long)a0;
- (void)_accessibilityLoadAccessibilityInformation;

@end
