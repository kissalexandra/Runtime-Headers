@class NSDictionary, NSObject;
@protocol OS_dispatch_queue;

@interface RTPredictionExpertDataSource : NSObject

@property (readonly, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (readonly, nonatomic) NSDictionary *dataProviders;

- (id)dataProviderForName:(id)a0;
- (id)initWithDataProviders:(id)a0;
- (void)prefetch:(id /* block */)a0;
- (void).cxx_destruct;
- (void)reset;

@end
