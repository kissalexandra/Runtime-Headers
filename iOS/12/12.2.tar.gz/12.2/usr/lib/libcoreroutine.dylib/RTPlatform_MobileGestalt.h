@class NSUserDefaults;

@interface RTPlatform_MobileGestalt : RTPlatform {
    NSUserDefaults *_userDefaults;
}

- (id)deviceClass;
- (BOOL)internalInstall;
- (id)productType;
- (BOOL)supportsCoreRoutineCapability;
- (BOOL)supportsRoutes;
- (BOOL)supportsMagicalMomentsCapability;
- (BOOL)supportsMicroLocations;
- (id)userAssignedDeviceName;
- (id)systemModel;
- (BOOL)iPhonePlatform;
- (BOOL)watchPlatform;
- (BOOL)macOSPlatform;
- (BOOL)simulatorPlatform;
- (BOOL)lowEndHardware;
- (BOOL)supportsMultiUser;
- (BOOL)iPhoneDevice;
- (id)init;
- (void).cxx_destruct;
- (id)systemVersion;
- (id)initWithUserDefaults:(id)a0;

@end
