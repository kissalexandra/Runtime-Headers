@class NSString, NSURL, RTMapItem, NSDate;

@interface RTLOIDisplayInfo : NSObject

@property (readonly, nonatomic) int style;
@property (readonly, nonatomic) long long type;
@property (readonly, nonatomic) long long modeOfTransportation;
@property (readonly, nonatomic) NSURL *mapsURL;
@property (readonly, nonatomic) RTMapItem *mapItem;
@property (readonly, nonatomic) NSString *unknownTypeName;
@property (readonly, nonatomic) double eta;
@property (readonly, nonatomic) NSDate *arrival;
@property (readonly, nonatomic) NSDate *deparature;

+ (id)dateFormatter;
+ (id)durationFormatter;

- (id)localizedMessage;
- (id)initWithStyle:(int)a0 type:(long long)a1 mapItem:(id)a2 unknownTypeName:(id)a3 eta:(double)a4 arrival:(id)a5 departure:(id)a6 modeOfTransportation:(long long)a7;
- (BOOL)isEquivalentToDisplayInfo:(id)a0;
- (void).cxx_destruct;
- (id)description;
- (id)localizedTitle;
- (id)localizedDescription;

@end
