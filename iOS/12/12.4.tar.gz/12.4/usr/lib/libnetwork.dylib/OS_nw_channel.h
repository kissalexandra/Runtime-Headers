@interface OS_nw_channel : OS_object

- (void)_dispose;

@end
