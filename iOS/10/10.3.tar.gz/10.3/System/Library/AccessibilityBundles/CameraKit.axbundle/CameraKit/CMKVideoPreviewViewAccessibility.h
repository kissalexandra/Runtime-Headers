@interface CMKVideoPreviewViewAccessibility : __CMKVideoPreviewViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)destroyEffectsGridViewsRemoveFromSuperview:(BOOL)a0;

@end
