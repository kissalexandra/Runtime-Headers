@class NSArray, RTLocation;

@interface RTVisitLocationPoints : NSObject

@property (readonly, nonatomic) NSArray *locations;
@property (readonly, nonatomic) RTLocation *centroid;

- (id)init;
- (id)description;
- (void).cxx_destruct;
- (double)duration;
- (id)initWithLocations:(id)a0;
- (id)lastDate;
- (id)firstDate;
- (void)enumerateLowSpeedSegementsUsingBlock:(id)a0 block:(id /* block */)a1;

@end
