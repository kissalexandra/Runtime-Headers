@class NSMutableDictionary, NSString, RTActionManager, NSMutableArray, NSObject;
@protocol OS_dispatch_queue, RTDaemonClientRegistrarActionProtocol;

@interface RTDaemonClientRegistrarAction : RTDaemonClientRegistrar <NSSecureCoding, RTDaemonClientRegistrarProtocol>

@property (class, readonly) BOOL supportsSecureCoding;

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) NSMutableDictionary *pendingActionConditionInvocations;
@property (retain, nonatomic) NSMutableArray *monitoredActions;
@property (retain, nonatomic) RTActionManager *actionManager;
@property (weak, nonatomic) id<RTDaemonClientRegistrarActionProtocol> delegate;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (BOOL)invocationsPending;
- (long long)countOfPendingInvocations;
- (id)initWithActionManager:(id)a0 queue:(id)a1;
- (void)startMonitoringPredictedConditionsForAction:(id)a0;
- (void)stopMonitoringPredictedConditionsForAction:(id)a0;
- (void)addPendingAction:(id)a0 block:(id /* block */)a1 failBlock:(id /* block */)a2 description:(id)a3;
- (void)_startMonitoringPredictedConditionsForAction:(id)a0;
- (void)_onActionConditions:(id)a0 error:(id)a1;
- (void)_logMonitoredAction:(id)a0;
- (void)_stopMonitoringPredictedConditionsForAction:(id)a0;
- (id)init;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (BOOL)registered;

@end
