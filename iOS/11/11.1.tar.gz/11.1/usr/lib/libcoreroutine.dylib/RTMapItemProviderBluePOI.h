@class RTLocationStore, NSString, RTFingerprintManager, RTMapServiceManager;

@interface RTMapItemProviderBluePOI : RTMapItemProviderBase <RTMapItemProvider>

@property (retain, nonatomic) RTFingerprintManager *fingerprintManager;
@property (retain, nonatomic) RTLocationStore *locationStore;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (id)mapItemsWithinDistance:(double)a0 location:(id)a1 startDate:(id)a2 endDate:(id)a3 error:(id *)a4;
- (id)initWithDistanceCalculator:(id)a0 fingerprintManager:(id)a1 locationStore:(id)a2 mapServiceManager:(id)a3;
- (id)accessPointsForFingerprint:(id)a0 error:(id *)a1;
- (id)locationsForAccessPoints:(id)a0 error:(id *)a1;
- (id)mapItemsFromLocations:(id)a0 accessPoints:(id)a1 error:(id *)a2;
- (id)filterByDistance:(id)a0 location:(id)a1 thresholdForUnknownLabel:(double)a2 error:(id *)a3;

@end
