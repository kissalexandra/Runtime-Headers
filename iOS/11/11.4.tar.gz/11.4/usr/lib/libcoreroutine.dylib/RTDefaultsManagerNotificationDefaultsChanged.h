@class NSArray;

@interface RTDefaultsManagerNotificationDefaultsChanged : RTNotification

@property (retain, nonatomic) NSArray *updatedKeys;

- (void).cxx_destruct;
- (id)initWithUpdatedKeys:(id)a0;

@end
