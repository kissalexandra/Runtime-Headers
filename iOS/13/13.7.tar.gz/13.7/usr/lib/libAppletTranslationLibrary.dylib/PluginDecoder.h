@interface PluginDecoder : NSObject <ATLDecoder> {
    struct shared_ptr<const OVM::Script> { struct Script *__ptr_; struct __shared_weak_count *__cntrl_; } script;
}

+ (id)decoderWithData:(id)a0;
+ (id)persistentContext:(id)a0;

- (id)initWithData:(id)a0;
- (void).cxx_destruct;
- (id).cxx_construct;
- (const struct map<std::__1::basic_string<char>, OVM::Var, std::__1::less<std::__1::basic_string<char> >, std::__1::allocator<std::__1::pair<const std::__1::basic_string<char>, OVM::Var> > > { struct __tree<std::__1::__value_type<std::__1::basic_string<char>, OVM::Var>, std::__1::__map_value_compare<std::__1::basic_string<char>, std::__1::__value_type<std::__1::basic_string<char>, OVM::Var>, std::__1::less<std::__1::basic_string<char> >, true>, std::__1::allocator<std::__1::__value_type<std::__1::basic_string<char>, OVM::Var> > > { struct __tree_end_node<std::__1::__tree_node_base<void *> *> *x0; struct __compressed_pair<std::__1::__tree_end_node<std::__1::__tree_node_base<void *> *>, std::__1::allocator<std::__1::__tree_node<std::__1::__value_type<std::__1::basic_string<char>, OVM::Var>, void *> > > { struct __tree_end_node<std::__1::__tree_node_base<void *> *> { struct __tree_node_base<void *> *x0; } x0; } x1; struct __compressed_pair<unsigned long, std::__1::__map_value_compare<std::__1::basic_string<char>, std::__1::__value_type<std::__1::basic_string<char>, OVM::Var>, std::__1::less<std::__1::basic_string<char> >, true> > { unsigned long long x0; } x2; } x0; } *)globals;
- (id)getAppletStateAndHistory:(id)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 withError:(id *)a4;
- (id)parseHCIEvent:(id)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 withTransceiver:(id)a4 withError:(id *)a5;
- (id)GetAppletProperties:(id)a0 withPackage:(id)a1 withModule:(id)a2 withTransceiver:(id)a3 withError:(id *)a4;
- (id)processEndOfTransaction:(id)a0 withApplet:(id)a1 withPackage:(id)a2 withModule:(id)a3 withError:(id *)a4;
- (struct shared_ptr<const OVM::ObjCClassChecker> { struct ObjCClassChecker *x0; struct __shared_weak_count *x1; })classChecker;

@end
