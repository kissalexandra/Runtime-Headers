@interface NW_URL_ENDPOINT_CLS : NWConcrete_nw_endpoint {
    struct __CFURL { } *url_ref;
    unsigned short port;
    char *url;
    char *scheme;
    char *hostname;
    char *path;
    char *sanitized_url;
    char url_hash[9];
}

- (void)dealloc;
- (unsigned int)type;
- (id)copyDictionary;
- (id)initWithURL:(const char *)a0;
- (unsigned short)port;
- (const char *)hostname;
- (char *)createDescription:(BOOL)a0;
- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1 matchParent:(BOOL)a2;
- (id)copyEndpoint;
- (unsigned long long)getHash;
- (const char *)domainForPolicy;

@end
