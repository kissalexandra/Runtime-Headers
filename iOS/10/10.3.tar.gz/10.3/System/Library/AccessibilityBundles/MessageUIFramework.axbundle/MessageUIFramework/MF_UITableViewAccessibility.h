@interface MF_UITableViewAccessibility : __MF_UITableViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityViewIsModal;
- (id)_accessibilityObscuredScreenAllowedViews;

@end
