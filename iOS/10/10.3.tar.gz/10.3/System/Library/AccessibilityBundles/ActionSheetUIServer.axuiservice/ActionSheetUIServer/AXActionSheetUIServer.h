@class NSString, UIAlertController, UIViewController;

@interface AXActionSheetUIServer : NSObject <AXUIService, AXUIContentViewControllerDelegate> {
    UIAlertController *_alertController;
    UIViewController *_emptyViewController;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (double)desiredWindowLevelForContentViewController:(id)a0 userInteractionEnabled:(BOOL)a1;
- (id)processMessage:(id)a0 withIdentifier:(unsigned long long)a1 fromClientWithIdentifier:(id)a2 error:(id *)a3;

@end
