@interface RTRouteLocationPreprocessor : NSObject

+ (id)preprocessLocations:(id)a0 error:(id *)a1;
+ (id)selectBestSubSequenceFromLocations:(id)a0 error:(id *)a1;
+ (long long)findProperEndFromLocations:(id)a0;
+ (double)costOfLocation:(id)a0;
+ (unsigned long long)idealPreviousLocationIndex:(id)a0 from:(unsigned long long)a1;

@end
