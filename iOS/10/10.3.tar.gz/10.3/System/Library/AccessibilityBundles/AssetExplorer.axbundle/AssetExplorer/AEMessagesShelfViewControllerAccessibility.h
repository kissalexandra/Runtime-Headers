@interface AEMessagesShelfViewControllerAccessibility : __AEMessagesShelfViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_toggleIris:(id)a0;

@end
