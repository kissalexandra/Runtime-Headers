@interface RTPredictionExpertFeatureAddonEventTypeMO : RTPredictionExpertFeatureAddonMO

@property (retain, nonatomic) id eventClasses;

+ (id)managedObjectWithEventClasses:(id)a0 inManagedObjectContext:(id)a1;

@end
