@interface RTContactsManagerContactStoreDidChangeNotification : RTNotification

@end
