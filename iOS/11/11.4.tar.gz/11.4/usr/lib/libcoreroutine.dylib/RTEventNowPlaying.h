@class NSString;

@interface RTEventNowPlaying : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (retain, nonatomic) NSString *bundleId;
@property (nonatomic) double duration;
@property (nonatomic) long long playbackState;

+ (id)playbackStateToString:(long long)a0;

- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (id)description;
- (id)initWithBundleId:(id)a0 duration:(double)a1 playbackState:(long long)a2 source:(long long)a3 startDate:(id)a4 endDate:(id)a5;
- (id)appLaunchRepresentation;

@end
