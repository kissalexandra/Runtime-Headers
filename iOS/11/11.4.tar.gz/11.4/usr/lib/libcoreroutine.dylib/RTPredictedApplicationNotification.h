@class NSArray;

@interface RTPredictedApplicationNotification : RTNotification

@property (retain, nonatomic) NSArray *predictedApplications;

- (void).cxx_destruct;
- (id)initWithPredictedApplications:(id)a0;

@end
