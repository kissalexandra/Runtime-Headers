@class RTApplicationManager, NSString, CLLocation, RTLocationManager;

@interface RTDataProviderHeroApp : RTDataProvider <RTDataProviderProtocol>

@property (retain, nonatomic) CLLocation *mostRecentLocation;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTApplicationManager *applicationManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)allocWithZone:(struct _NSZone { } *)a0;
+ (BOOL)supportsNotificationName:(id)a0;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)fetchPredictedApplications:(id /* block */)a0;
- (void)fetchPredictedApplicationsAtLocation:(id)a0 handler:(id /* block */)a1;
- (void)_shutdown;
- (id)supportedEventClasses;
- (void)populateDataProviderWithHandler:(id /* block */)a0;
- (void)_fetchPredictedApplicationsAtLocation:(id)a0 handler:(id /* block */)a1;
- (id)initWithPurgeManager:(id)a0 locationManager:(id)a1 applicationManager:(id)a2;
- (void)onHeroAppNotification:(id)a0;
- (void)_onHeroAppNotification:(id)a0;
- (void)onLeechedLocation:(id)a0;
- (void)_onLeechedLocation:(id)a0;

@end
