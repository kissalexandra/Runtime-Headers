@protocol GEOMapServiceTicket;

@interface RTGeocoder : NSObject

@property (retain, nonatomic) id<GEOMapServiceTicket> ticket;

- (void).cxx_destruct;
- (void)cancel;
- (void)dealloc;
- (void)geocodeLatitude:(double)a0 longitude:(double)a1 handler:(id /* block */)a2;
- (id)geocodeLatitude:(double)a0 longitude:(double)a1 error:(id *)a2;
- (void)geocodeAddressDictionary:(id)a0 withHandler:(id /* block */)a1;
- (id)geocodeAddressDictionary:(id)a0 error:(id *)a1;
- (void)geocodeAddressString:(id)a0 withHandler:(id /* block */)a1;
- (id)geocodeAddressString:(id)a0 error:(id *)a1;
- (void)_cancelTicket:(id)a0;

@end
