@interface CMKModeDialAccessibility : __CMKModeDialAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityIdentifier;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;
- (void)accessibilityIncrement;
- (void)accessibilityDecrement;
- (void)setSelectedMode:(long long)a0 animated:(BOOL)a1;
- (long long)_axNextMode;
- (long long)_axPreviousMode;
- (unsigned long long)_axCurrentIndex;
- (unsigned long long)_axNumberOfItems;
- (long long)_axModeAtIndex:(unsigned long long)a0;

@end
