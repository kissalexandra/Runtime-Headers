@class NSString, NSObject;
@protocol OS_nw_path, OS_nw_connection, OS_nw_advertise_descriptor, OS_nw_parameters, OS_nw_array, OS_dispatch_queue, OS_nw_endpoint, OS_nw_path_evaluator, OS_xpc_object;

@interface NWConcrete_nw_listener : NSObject <nw_listener_inbox_delegate, OS_nw_listener> {
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } lock;
    NSObject<OS_nw_parameters> *parameters;
    unsigned short id_value;
    char id_str[6];
    NSObject<OS_nw_connection> *join_connection;
    NSObject<OS_dispatch_queue> *client_queue;
    id /* block */ event_handler;
    id /* block */ new_connection_handler;
    int state;
    NSObject<OS_nw_array> *inboxes;
    NSObject<OS_nw_path_evaluator> *evaluator;
    NSObject<OS_nw_path> *path;
    NSObject<OS_xpc_object> *inactive_agents;
    NSObject<OS_xpc_object> *inactive_agent_dictionaries;
    NSObject<OS_xpc_object> *triggered_agents;
    NSObject<OS_nw_parameters> *current_derived_parameters;
    NSObject<OS_nw_advertise_descriptor> *advertise_descriptor;
    void *dnssrc;
    struct _DNSServiceRef_t { } *dnsref;
    NSObject<OS_nw_endpoint> *local_endpoint;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)handleInbound:(id)a0 addProtocolInbox:(BOOL)a1;
- (void)handleInboxFailed:(id)a0 error:(struct __CFError { } *)a1;
- (void).cxx_destruct;
- (void)dealloc;
- (id)initWithParameters:(id)a0;

@end
