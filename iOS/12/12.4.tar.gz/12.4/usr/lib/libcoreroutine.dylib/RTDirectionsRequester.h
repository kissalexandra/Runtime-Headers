@interface RTDirectionsRequester : NSObject

+ (int)geoTransportTypeForRTTransportType:(int)a0;
+ (struct NSArray { Class x0; } *)routeForGEORoute:(id)a0;

- (void)routesFromSource:(id)a0 toDestination:(id)a1 transportType:(int)a2 maxRouteCount:(unsigned int)a3 handler:(id /* block */)a4;

@end
