@class CLLocation;

@interface RTPhotoLibraryManagerNotificationLibraryInsertion : RTNotification

@property (readonly, nonatomic) CLLocation *photoLocation;

- (id)initWithLocation:(id)a0;
- (id)init;
- (void).cxx_destruct;

@end
