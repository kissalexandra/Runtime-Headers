@interface MPAVRoutingViewControllerAccessibility : __MPAVRoutingViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)viewDidAppear:(BOOL)a0;

@end
