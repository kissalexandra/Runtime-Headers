@class NSString, RTIONotificationPort;
@protocol RTIOServiceStrategy;

@interface RTBatteryManager : RTNotifier <RTIORegistryEntryMatchObserver, RTIOServiceChangeObserver> {
    unsigned int _battery;
    unsigned int _batteryInterestNotification;
}

@property (nonatomic) unsigned int battery;
@property (retain, nonatomic) RTIONotificationPort *port;
@property (nonatomic) unsigned int batteryInterestNotification;
@property (nonatomic) BOOL monitorBatteryStatusChanges;
@property (nonatomic) long long externalConnectionState;
@property (readonly, nonatomic) id<RTIOServiceStrategy> ioServiceStrategy;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)RTBatteryManagerExternalConnectionStateToString:(long long)a0;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)_unregisterForNotifications;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)onServiceChanged:(unsigned int)a0 messageType:(unsigned int)a1;
- (void)onRegistryEntriesMatched:(unsigned int)a0;
- (id)initWithStrategy:(id)a0;
- (void)startMonitoringBatteryStatusChanges;
- (void)stopMonitoringBatteryStatusChanges;
- (void)matchedBattery:(unsigned int)a0;
- (void)updateBatteryStatus:(unsigned int)a0;
- (void)batteryStatusChange:(unsigned int)a0 messageType:(unsigned int)a1;

@end
