@class RTMapItem, NSDate;

@interface RTHistoryEntryRoute : NSObject

@property (readonly, nonatomic) NSDate *usageDate;
@property (readonly, nonatomic) RTMapItem *originMapItem;
@property (readonly, nonatomic) RTMapItem *destinationMapItem;
@property (readonly, nonatomic) BOOL navigationWasInterrupted;

- (id)init;
- (void).cxx_destruct;
- (id)description;
- (id)initWithUsageDate:(id)a0 originMapItem:(id)a1 destinationMapItem:(id)a2 navigationWasInterrupted:(BOOL)a3;

@end
