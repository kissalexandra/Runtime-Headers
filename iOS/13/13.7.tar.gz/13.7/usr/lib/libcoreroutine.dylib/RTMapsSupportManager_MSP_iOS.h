@interface RTMapsSupportManager_MSP_iOS : RTMapsSupportManager_MSP

- (id)favoritesContainer;
- (id)historyContainer;
- (id)pinnedPlacesContainer;
- (void)_showParkedCarBulletinForEvent:(id)a0;
- (void)_showParkedCarReplacementBulletinForEvent:(id)a0 replacingEvent:(id)a1;
- (void)_clearParkedCarBulletin;

@end
