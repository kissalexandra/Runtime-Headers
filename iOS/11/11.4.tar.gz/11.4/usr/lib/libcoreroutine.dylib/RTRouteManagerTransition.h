@class NSUUID, NSDictionary, NSArray, NSDate;

@interface RTRouteManagerTransition : NSObject

@property (retain, nonatomic) NSDictionary *locationTypeDistribution;
@property (nonatomic) double majorGapLength;
@property (readonly, copy, nonatomic) NSDate *startDate;
@property (readonly, copy, nonatomic) NSDate *endDate;
@property (readonly, copy, nonatomic) NSUUID *originLoiIdentifier;
@property (readonly, copy, nonatomic) NSUUID *destinationLoiIdentifier;
@property (readonly, copy, nonatomic) NSUUID *originVisitIdentifier;
@property (readonly, copy, nonatomic) NSUUID *destinationVisitIdentifier;
@property (copy, nonatomic) NSArray *locations;
@property (nonatomic) double motionAutomotiveRatio;

- (void).cxx_destruct;
- (id)description;
- (id)initWithStartDate:(id)a0 endDate:(id)a1 originLoiIdentifier:(id)a2 destinationLoiIdentifier:(id)a3 originVisitIdentifier:(id)a4 destinationVisitIdentifier:(id)a5;

@end
