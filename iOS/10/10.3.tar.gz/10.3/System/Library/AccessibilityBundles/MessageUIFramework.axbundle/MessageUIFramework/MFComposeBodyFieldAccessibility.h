@interface MFComposeBodyFieldAccessibility : __MFComposeBodyFieldAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)changeQuoteLevel:(long long)a0;
- (id)_mailComposeEditingInputAssistantGroup;
- (void)_replaceImages;
- (void)_axAdornAttachmentsWithLabels;
- (id)_accessibilitySuperHitTest:(struct CGPoint { double x0; double x1; })a0 withEvent:(id)a1;
- (id)_accessibilityHitTest:(struct CGPoint { double x0; double x1; })a0 withEvent:(id)a1;
- (void)_accessibilityLoadAccessibilityInformation;

@end
