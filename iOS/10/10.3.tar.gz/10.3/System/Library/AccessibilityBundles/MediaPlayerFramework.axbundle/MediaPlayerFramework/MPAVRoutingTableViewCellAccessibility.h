@interface MPAVRoutingTableViewCellAccessibility : __MPAVRoutingTableViewCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;
- (void)setMirroringSwitchVisible:(BOOL)a0 animated:(BOOL)a1;

@end
