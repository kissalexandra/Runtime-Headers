@interface MKTransitInfoLabelViewAccessibility : __MKTransitInfoLabelViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (BOOL)isAccessibilityElement;
- (id)_axLabelFromLabelItems:(id)a0;
- (id)_axLabelFromMapItem;

@end
