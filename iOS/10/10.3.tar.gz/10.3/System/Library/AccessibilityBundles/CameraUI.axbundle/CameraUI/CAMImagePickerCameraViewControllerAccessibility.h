@interface CAMImagePickerCameraViewControllerAccessibility : __CAMImagePickerCameraViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)cropOverlayWasCancelled:(id)a0;

@end
