@interface RTPredictionTableControllerMagicalMoments : RTPredictionTableController

- (void)predictionWithEvent:(id)a0 handler:(id /* block */)a1;
- (void)predictionWithEvent:(id)a0 limit:(unsigned long long)a1 confidence:(double)a2 handler:(id /* block */)a3;
- (void)_predictionWithEvent:(id)a0 limit:(unsigned long long)a1 confidence:(double)a2 predictionTable:(id)a3 handler:(id /* block */)a4;

@end
