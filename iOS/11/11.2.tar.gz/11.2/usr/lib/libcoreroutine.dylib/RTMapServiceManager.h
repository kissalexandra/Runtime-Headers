@class RTDefaultsManager, NSObject;
@protocol OS_dispatch_queue;

@interface RTMapServiceManager : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;

- (void)setup;
- (id)init;
- (void).cxx_destruct;
- (void)_setup;
- (void)shutdown;
- (void)_shutdown;
- (id)initWithDefaultsManager:(id)a0;
- (void)_fetchMapItemFromHandle:(id)a0 handler:(id /* block */)a1;
- (void)fetchMapItemFromHandle:(id)a0 handler:(id /* block */)a1;
- (void)_hydrateMapItem:(id)a0 handler:(id /* block */)a1;
- (void)hydrateMapItem:(id)a0 handler:(id /* block */)a1;
- (void)_fetchMapItemsFromNaturalLanguageQuery:(id)a0 location:(id)a1 handler:(id /* block */)a2;
- (id)_mapItemsFromMKMapItems:(id)a0 mapItemSource:(unsigned long long)a1;
- (id)_mapItemsFromGEOMapItems:(id)a0 mapItemSource:(unsigned long long)a1;
- (void)fetchMapItemsFromNaturalLanguageQuery:(id)a0 location:(id)a1 handler:(id /* block */)a2;
- (void)_fetchMapItemsFromLocation:(id)a0 handler:(id /* block */)a1;
- (void)fetchMapItemsFromLocation:(id)a0 handler:(id /* block */)a1;
- (void)_fetchMapItemsFromLocations:(id)a0 accessPoints:(id)a1 handler:(id /* block */)a2;
- (void)fetchMapItemsFromLocations:(id)a0 accessPoints:(id)a1 handler:(id /* block */)a2;
- (void)_fetchMapItemsFromAddressString:(id)a0 handler:(id /* block */)a1;
- (void)fetchMapItemsFromAddressString:(id)a0 handler:(id /* block */)a1;
- (void)_fetchMapItemsFromAddressDictionary:(id)a0 handler:(id /* block */)a1;
- (void)fetchMapItemsFromAddressDictionary:(id)a0 handler:(id /* block */)a1;
- (void)_fetchMapItemsFromMapItemURL:(id)a0 handler:(id /* block */)a1;
- (void)fetchMapItemsFromMapItemURL:(id)a0 handler:(id /* block */)a1;

@end
