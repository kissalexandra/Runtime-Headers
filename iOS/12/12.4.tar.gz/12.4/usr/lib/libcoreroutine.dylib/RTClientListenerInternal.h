@class RTPersistenceManager, RTEventAgentManager, RTDeviceLocationPredictor, RTLocationStore, RTVisitManager, RTFingerprintManager, RTAssetManager, RTLocationManager, RTAuthorizationManager, RTLearnedLocationManager, RTAccountManager, RTWiFiManager, NSString, RTScenarioTriggerManager, RTPlatform, RTActionManager, RTRouteManager, RTDiagnostics, RTMotionActivityManager, RTPredictedApplicationManager, RTEventModelProvider, RTVehicleLocationProvider, RTPurgeManager;

@interface RTClientListenerInternal : RTXPCListener <NSXPCListenerDelegate>

@property (retain, nonatomic) RTAccountManager *accountManager;
@property (retain, nonatomic) RTActionManager *actionManager;
@property (retain, nonatomic) RTAssetManager *assetManager;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTDeviceLocationPredictor *deviceLocationPredictor;
@property (retain, nonatomic) RTDiagnostics *diagnostics;
@property (retain, nonatomic) RTEventAgentManager *eventAgentManager;
@property (retain, nonatomic) RTEventModelProvider *eventModelProvider;
@property (retain, nonatomic) RTFingerprintManager *fingerprintManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTLocationStore *locationStore;
@property (retain, nonatomic) RTMotionActivityManager *motionActivityManager;
@property (retain, nonatomic) RTPersistenceManager *persistenceManager;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain, nonatomic) RTPredictedApplicationManager *predictedApplicationManager;
@property (retain, nonatomic) RTPurgeManager *purgeManager;
@property (retain, nonatomic) RTRouteManager *routeManager;
@property (retain, nonatomic) RTScenarioTriggerManager *scenarioTriggerManager;
@property (retain, nonatomic) RTVehicleLocationProvider *vehicleLocationProvider;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) RTWiFiManager *wifiManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)handleClientConnection:(id)a0;
- (id)initWithAccountManager:(id)a0 actionManager:(id)a1 assetManager:(id)a2 authorizationManager:(id)a3 deviceLocationPredictor:(id)a4 diagnostics:(id)a5 eventAgentManager:(id)a6 eventModelProvider:(id)a7 fingerprintManager:(id)a8 learnedLocationManager:(id)a9 locationManager:(id)a10 locationStore:(id)a11 motionActivityManager:(id)a12 persistenceManager:(id)a13 platform:(id)a14 predictedApplicationManager:(id)a15 purgeManager:(id)a16 routeManager:(id)a17 scenarioTriggerManager:(id)a18 vehicleLocationProvider:(id)a19 visitManager:(id)a20;
- (id)init;
- (void).cxx_destruct;
- (BOOL)listener:(id)a0 shouldAcceptNewConnection:(id)a1;

@end
