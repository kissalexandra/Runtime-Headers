@class NSObject;
@protocol OS_os_transaction;

@interface RTMemoryTransaction : RTTransaction

@property (retain, nonatomic) NSObject<OS_os_transaction> *transaction;

- (void).cxx_destruct;
- (void)dealloc;
- (id)initForObject:(id)a0 description:(id)a1;

@end
