@class RTDataProtectionManager, CNContactStore, CNContact;

@interface RTContactsManager : RTNotifier

@property (retain, nonatomic) RTDataProtectionManager *dataProtectionManager;
@property (retain, nonatomic) CNContactStore *contactStore;
@property (retain, nonatomic) CNContact *meCard;
@property (nonatomic) BOOL available;

+ (unsigned long long)labelStringToPostalAddressLabelType:(id)a0;

- (void)setup;
- (id)init;
- (void).cxx_destruct;
- (void)_setup;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithDataProtectionManager:(id)a0;
- (void)onDataProtectionNotification:(id)a0;
- (void)_shutdown;
- (id)_getMeCardWithError:(id *)a0;
- (void)onContactStoreNotification:(id)a0;
- (void)_onContactStoreNotification:(id)a0;
- (void)_fetchMeCardWithHandler:(id /* block */)a0;
- (void)fetchMeCardWithHandler:(id /* block */)a0;
- (void)_donatePostalAddress:(id)a0 handler:(id /* block */)a1;
- (void)donatePostalAddress:(id)a0 handler:(id /* block */)a1;

@end
