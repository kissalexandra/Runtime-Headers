@class NSObject;
@protocol OS_nw_parameters;

@interface nw_listener_inbox_socket : nw_listener_inbox {
    NSObject<OS_nw_parameters> *_parameters;
    void *_source;
    int _sockfd_for_logging_only_do_not_close_or_use;
}

- (id)initWithSocket:(int)a0 parameters:(id)a1 delegate:(id)a2;
- (void).cxx_destruct;
- (void)cancel;
- (id)description;
- (id)initWithParameters:(id)a0 delegate:(id)a1;

@end
