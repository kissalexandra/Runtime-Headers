@class RTMapAccess, NSArray, RTPriorityQueue, NSMutableDictionary, NSString, NSMutableArray, NSObject;
@protocol OS_dispatch_queue;

@interface RTRouteFinderShortestPath : NSObject <RTRouteFinderProtocol>

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (copy, nonatomic) id /* block */ handler;
@property (retain, nonatomic) NSMutableArray *destIDs;
@property (copy, nonatomic) NSArray *rolloverCosts;
@property (retain, nonatomic) RTMapAccess *mapAccess;
@property (retain, nonatomic) RTPriorityQueue *activeRoads;
@property (retain, nonatomic) NSMutableDictionary *uniqueRoadIDToRoadMap;
@property (nonatomic) long long totalProcessedRoadCount;
@property (nonatomic) double maxPathCost;
@property (nonatomic) BOOL allowEarlyTermination;
@property (nonatomic) BOOL flipped;
@property (nonatomic) BOOL busy;
@property (nonatomic) double maxPathLength;
@property (copy, nonatomic) id /* block */ costFunction;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void).cxx_destruct;
- (void)findRouteForWaypoints:(id)a0 routeHandler:(id /* block */)a1;
- (id)initWithQueue:(id)a0 mapAccess:(id)a1;
- (void)findRouteForWaypoints:(id)a0 routeExtHandler:(id /* block */)a1;
- (void)findRouteFromOrigin:(id)a0 toDestination:(id)a1 routeExtHandler:(id /* block */)a2;
- (void)findRoutesFromOrigin:(id)a0 toDestinations:(id)a1 routesExtHandler:(id /* block */)a2;
- (void)findRoutesFromOrigins:(id)a0 toDestination:(id)a1 routesExtHandler:(id /* block */)a2;
- (void)findLowestCostRouteFromAnyOfOrigins:(id)a0 toDestination:(id)a1 rolloverCosts:(id)a2 routeExtHandler:(id /* block */)a3;
- (void)_findRoutesFromOrigins:(id)a0 toDestinations:(id)a1 routesHandler:(id /* block */)a2;
- (void)_findRoutesFromOrigin:(id)a0 toDestinations:(id)a1 rolloverCosts:(id)a2 flipped:(BOOL)a3 routesHandler:(id /* block */)a4;
- (id)_pathTo:(id)a0;
- (id)_pathFromRoads:(id)a0;
- (void)_lookForward;
- (void)_processNextRoad:(id)a0 prevRoad:(id)a1;
- (void)_findRoadsFromNextIntersection:(id)a0 roadHandler:(id /* block */)a1 completionHandler:(id /* block */)a2;
- (BOOL)_checkSearchCompletionWithCurrentCost:(double)a0;
- (void)_completeSearch;
- (void)_callHandlerWithRoutes:(id)a0 costs:(id)a1 error:(id)a2;

@end
