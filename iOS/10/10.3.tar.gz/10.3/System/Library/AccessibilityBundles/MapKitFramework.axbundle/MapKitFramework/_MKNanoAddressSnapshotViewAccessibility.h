@interface _MKNanoAddressSnapshotViewAccessibility : ___MKNanoAddressSnapshotViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;

@end
