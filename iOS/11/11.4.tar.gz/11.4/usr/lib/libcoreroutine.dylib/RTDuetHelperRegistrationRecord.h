@class NSString, _CDContextualChangeRegistration;

@interface RTDuetHelperRegistrationRecord : NSObject

@property (retain, nonatomic) NSString *registrationIdentifier;
@property (retain, nonatomic) _CDContextualChangeRegistration *registration;
@property (copy, nonatomic) id /* block */ eventReceivedBlock;
@property (copy, nonatomic) id /* block */ contextChangeBlock;

+ (id)contextStoreRegistrationIdentifierForNotificationName:(id)a0;

- (void).cxx_destruct;
- (id)initWithRegistrationIdentifier:(id)a0 contextStoreRegistration:(id)a1 contextChangeBlock:(id /* block */)a2 eventReceivedBlock:(id /* block */)a3;

@end
