@class NSObject;
@protocol OS_dispatch_data;

@interface NWConcrete_nw_custom_endpoint : NWConcrete_nw_endpoint {
    NSObject<OS_dispatch_data> *data;
    id /* block */ resolver_block;
    unsigned int type;
}

- (unsigned int)type;
- (id)copyDictionary;
- (void).cxx_destruct;
- (char *)createDescription:(BOOL)a0;
- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1 matchParent:(BOOL)a2;
- (id)copyEndpoint;
- (unsigned long long)getHash;
- (id)initWithType:(unsigned int)a0 resolver:(id /* block */)a1 data:(id)a2;

@end
