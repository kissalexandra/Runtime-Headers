@interface CAMButtonLabelAccessibility : __CAMButtonLabelAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (BOOL)isAccessibilityElement;

@end
