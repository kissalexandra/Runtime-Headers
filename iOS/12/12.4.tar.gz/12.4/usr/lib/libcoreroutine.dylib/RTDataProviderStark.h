@interface RTDataProviderStark : RTDataProviderDuet

- (id)supportedEventClasses;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)populateDataProviderWithHandler:(id /* block */)a0;
- (BOOL)supportsEventClass:(Class)a0;
- (id)supportedEventStreams;

@end
