@class NSString;

@interface OS_xpc_endpoint : OS_xpc_object <OS_xpc_endpoint>

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (void)load;


@end
