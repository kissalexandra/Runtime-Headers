@interface __MiroUITableViewCellAccessibility_super : UIAccessibilitySafeCategory

@end
