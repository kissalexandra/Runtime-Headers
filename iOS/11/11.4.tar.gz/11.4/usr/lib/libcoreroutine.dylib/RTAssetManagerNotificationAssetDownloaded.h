@class NSString, NSDictionary, NSURL;

@interface RTAssetManagerNotificationAssetDownloaded : RTNotification

@property (readonly, nonatomic) NSString *assetType;
@property (readonly, nonatomic) NSDictionary *attributes;
@property (readonly, nonatomic) long long assetState;
@property (readonly, nonatomic) NSURL *assetURL;

- (void).cxx_destruct;
- (id)initWithAssetType:(id)a0 attributes:(id)a1 assetState:(long long)a2 assetURL:(id)a3;

@end
