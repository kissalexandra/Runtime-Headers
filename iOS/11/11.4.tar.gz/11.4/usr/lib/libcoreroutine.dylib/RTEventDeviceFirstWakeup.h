@interface RTEventDeviceFirstWakeup : RTEventDevice

@property (readonly, nonatomic) long long wakeupState;

+ (BOOL)supportsSecureCoding;

- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (id)initWithDeviceWakeupState:(long long)a0 source:(long long)a1 startDate:(id)a2 endDate:(id)a3;

@end
