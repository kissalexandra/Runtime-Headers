@interface MiroUICollectionViewAccessibility : __MiroUICollectionViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (long long)accessibilityElementCount;
- (id)accessibilityElementAtIndex:(long long)a0;
- (long long)indexOfAccessibilityElement:(id)a0;
- (id)accessibilityElements;
- (BOOL)isAccessibilityOpaqueElementProvider;
- (double)_accessibilityScrollWidthDistance;
- (BOOL)accessibilityCollectionViewBehavesLikeUIViewAccessibility;

@end
