@interface RTPersistenceExpirationEnforcer : NSObject

- (BOOL)removeRecordsOwnedByOtherDevicesExpiredBeforeDate:(id)a0 allowPropagation:(BOOL)a1 withContext:(id)a2 error:(id *)a3;
- (id)entitiesWithDeviceAndExpirationProperty:(id)a0;

@end
