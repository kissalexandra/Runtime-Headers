@class NSArray;

@interface RTPredictedApplicationNotification : RTNotification

@property (retain, nonatomic) NSArray *predictedApplications;

- (id)initWithPredictedApplications:(id)a0;
- (void).cxx_destruct;

@end
