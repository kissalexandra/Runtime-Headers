@class NSObject;
@protocol OS_dispatch_source, OS_dispatch_queue;

@interface ATLTimer : NSObject {
    NSObject<OS_dispatch_source> *_src;
    id /* block */ _block;
    double _delay;
    NSObject<OS_dispatch_queue> *_queue;
}

- (void)dealloc;
- (void).cxx_destruct;
- (void)stopTimer;
- (void)onExpire;
- (void)startTimerWithDelay:(double)a0 leeway:(double)a1;
- (void)startTimerWithDelay:(double)a0;
- (id)initOnQueue:(id)a0 withTimerBlock:(id /* block */)a1;
- (void)addDelay:(double)a0;

@end
