@interface __MPUITableViewCellAccessibility_super : UIAccessibilitySafeCategory

@end
