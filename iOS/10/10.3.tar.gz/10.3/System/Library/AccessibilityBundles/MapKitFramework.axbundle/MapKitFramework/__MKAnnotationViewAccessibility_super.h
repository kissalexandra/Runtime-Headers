@interface __MKAnnotationViewAccessibility_super : UIAccessibilitySafeCategory

@end
