@interface MKNewAnnotationContainerViewAccessibility : __MKNewAnnotationContainerViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityElementsHidden;

@end
