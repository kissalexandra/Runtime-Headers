@class RTMotionActivity;

@interface RTMotionActivityManagerNotificationDominantActivity : RTNotification

@property (readonly, nonatomic) RTMotionActivity *dominantActivity;

- (void).cxx_destruct;
- (id)initWithDominantActivity:(id)a0;

@end
