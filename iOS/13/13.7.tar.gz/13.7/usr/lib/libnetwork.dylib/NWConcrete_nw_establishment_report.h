@class NSString, NSObject;
@protocol OS_nw_array, OS_nw_endpoint;

@interface NWConcrete_nw_establishment_report : NSObject <OS_nw_establishment_report> {
    unsigned long long attempt_started_after_milliseconds;
    unsigned long long duration_milliseconds;
    unsigned long long resolution_started_after_milliseconds;
    unsigned long long flow_started_after_milliseconds;
    NSObject<OS_nw_endpoint> *proxy_endpoint;
    NSObject<OS_nw_array> *protocol_reports;
    struct nw_establishment_resolution_report { unsigned long long x0; id x1; id x2; unsigned int x3; int x4; } *resolution_reports;
    unsigned int resolution_report_count;
    unsigned int previous_attempt_count;
    unsigned char proxy_configured : 1;
    unsigned char used_proxy : 1;
    unsigned char __pad_bits : 7;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

@end
