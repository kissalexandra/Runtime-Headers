@class RTMapServiceManager, NSObject;
@protocol OS_dispatch_queue;

@interface RTMapsSupportManager : NSObject

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;

+ (id)locationFromHistoryEntry:(id)a0;

- (void)fetchNextPredictedLocationsOfInterestFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 withHandler:(id /* block */)a3;
- (id)initWithMapServiceManager:(id)a0;
- (id)_getNextPredictedLocationsOfInterestBackedByHistortyEntryRouteFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 historyEntries:(id)a3;
- (id)_getNextPredictedLocationsOfInterestBackedByHistortyEntryPlaceDisplayFromLocation:(id)a0 startDate:(id)a1 timeInterval:(double)a2 historyEntries:(id)a3;
- (void)fetchHistoryEntriesWithHandler:(id /* block */)a0;
- (id)_historyEntryRouteFromMapsHistoryEntryRoute:(id)a0 error:(id *)a1;
- (id)_historyEntryPlaceDisplayFromMapsHistoryEntryPlaceDisplay:(id)a0 error:(id *)a1;
- (id)favoritesContainer;
- (void)_fetchFavoritesWithHandler:(id /* block */)a0;
- (id)historyContainer;
- (void)_fetchHistoryEntriesWithHandler:(id /* block */)a0;
- (void)showTrafficConditionsBulletinWithTitle:(id)a0 message:(id)a1 actionURL:(id)a2;
- (void)clearTrafficConditionsBulletin;
- (void)showParkedCarBulletinForEvent:(id)a0;
- (void)showParkedCarReplacementBulletinForEvent:(id)a0 replacingEvent:(id)a1;
- (void)clearParkedCarBulletin;
- (void)_fetchFavoritePlacesWithHandler:(id /* block */)a0;
- (void)fetchFavoritesWithHandler:(id /* block */)a0;
- (void)_fetchFavoritePlaceMapItemsWithHandler:(id /* block */)a0;
- (void)fetchFavoritePlacesWithHandler:(id /* block */)a0;
- (void)fetchHistoryEntryPlaceDisplaysWithHandler:(id /* block */)a0;
- (void)fetchHistoryEntryRoutesWithHandler:(id /* block */)a0;
- (id)init;
- (void).cxx_destruct;

@end
