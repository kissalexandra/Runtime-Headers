@class BiometricKitXPCServerMesa, NSMutableArray, BLTimeBox;

@interface SBBase : NSObject {
    struct tag_tsSBCtx { } *_sbContext;
    BiometricKitXPCServerMesa *_server;
    unsigned int _fingerTouchCounter;
    BOOL _buttonDown;
    BOOL _wakeOnMenuPin;
    BOOL _fingerOnInLockout;
    BOOL _chargerConnected;
    BOOL _operationModePause;
    NSMutableArray *_bioOperationQueue;
    NSMutableArray *_fingerTouchQueue;
    struct IONotificationPort { } *_notificationPort;
    unsigned int _powerSourceNotification;
    struct { int source; unsigned int s; unsigned int ns; } _fingerOnSensor;
    struct __tag_tsSBButtonEvent { struct { int x0; unsigned int x1; unsigned int x2; } x0; BOOL x1; int x2; struct __tag_tsSBButtonEvent *x3; } *_buttonEventCache;
    unsigned int _nButtonCacheEvents;
    BLTimeBox *_timeBox;
}

- (void)dealloc;
- (void)timeZoneChanged;
- (id)initWithServerObject:(id)a0 identities:(id)a1;
- (void)currentStatus:(id)a0;
- (void)removeIdentity:(id)a0 withTimestamp:(unsigned long long)a1;
- (void)homeButtonState:(BOOL)a0 withTimestamp:(unsigned long long)a1;
- (void)enrollResultIdentity:(id)a0 withTimestamp:(unsigned long long)a1;
- (void)matchResultIdentity:(id)a0 withDetails:(id)a1 timestamp:(unsigned long long)a2;
- (void)statusMessage:(int)a0 withData:(id)a1 timestamp:(unsigned long long)a2;
- (void)sensorStatus:(id)a0;
- (void)kernelMessage:(id)a0;
- (void)sensorRecoveryReason:(unsigned int)a0 withTimestamp:(unsigned long long)a1;
- (void)sksLockState:(unsigned short)a0 forUser:(unsigned int)a1 withTimestamp:(unsigned long long)a2;
- (void)displayState:(BOOL)a0 withTimestamp:(unsigned long long)a1;
- (void)uninitializeEventSystem;
- (void)initializeEventSystem;
- (BOOL)chargerConnected:(BOOL *)a0;
- (unsigned int)teSBLockFlagsFromSKSLockState:(unsigned long long)a0;
- (void)sbSystemInfo:(struct { char x0[32]; unsigned short x1; int x2; BOOL x3; BOOL x4; BOOL x5; BOOL x6; unsigned int x7; struct *x8; struct __tag_tsSBMemoryManager { void /* function */ *x0; void /* function */ *x1; } x9; } *)a0 fromIdentities:(id)a1;
- (void)sbTimestamp:(struct { int x0; unsigned int x1; unsigned int x2; } *)a0 fromAbsoluteTime:(unsigned long long)a1;
- (void)sbTemplateInfo:(struct { unsigned int x0[5]; unsigned char x1[5][5][16]; unsigned int x2[5]; } *)a0 fromIdentities:(id)a1;
- (void)freeSBSystemInfo:(struct { char x0[32]; unsigned short x1; int x2; BOOL x3; BOOL x4; BOOL x5; BOOL x6; unsigned int x7; struct *x8; struct __tag_tsSBMemoryManager { void /* function */ *x0; void /* function */ *x1; } x9; } *)a0;
- (void)processEventList:(struct { unsigned int x0; unsigned int x1; struct *x2; unsigned int x3; struct *x4; unsigned int x5; struct *x6; struct __tag_tsSBMemoryManager { void /* function */ *x0; void /* function */ *x1; } x7; } *)a0 withResult:(int)a1 forSBFunction:(id)a2;
- (void)processFingerTouch:(id)a0;
- (void)stopBioOperationWithReason:(int)a0 withTimestamp:(unsigned long long)a1;
- (BOOL)isYesOrSet:(id)a0;
- (void)startBioOperation:(id)a0 withTimestamp:(unsigned long long)a1;
- (void)powerEventChargerState:(BOOL)a0 willHibernate:(BOOL)a1 withTimestamp:(unsigned long long)a2;
- (void)powerEventChargerStateAsync:(BOOL)a0 willHibernate:(BOOL)a1 withTimestamp:(unsigned long long)a2;
- (void)powerSourceStateChanged;
- (void)timeZoneChangedWithTimestamp:(unsigned long long)a0;
- (void)powerState:(BOOL)a0 withTimestamp:(unsigned long long)a1;

@end
