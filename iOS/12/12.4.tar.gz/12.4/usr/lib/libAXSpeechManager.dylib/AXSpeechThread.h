@class NSPort, NSRunLoop;

@interface AXSpeechThread : NSThread {
    NSPort *_machPort;
    NSRunLoop *_threadRunLoop;
}

- (id)init;
- (void).cxx_destruct;
- (void)stop;
- (void)cancel;
- (void)main;

@end
