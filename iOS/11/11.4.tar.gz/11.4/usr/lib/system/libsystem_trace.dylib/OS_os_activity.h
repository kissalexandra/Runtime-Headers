@interface OS_os_activity : OS_object

+ (void)load;

- (void)_dispose;

@end
