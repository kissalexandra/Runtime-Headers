@interface __CMKZoomSliderAccessibility_super : UIAccessibilitySafeCategory

@end
