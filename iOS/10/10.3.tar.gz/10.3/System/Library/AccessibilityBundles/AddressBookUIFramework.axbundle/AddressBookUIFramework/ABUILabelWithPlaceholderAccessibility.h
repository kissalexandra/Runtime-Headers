@interface ABUILabelWithPlaceholderAccessibility : __ABUILabelWithPlaceholderAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (BOOL)isAccessibilityElement;

@end
