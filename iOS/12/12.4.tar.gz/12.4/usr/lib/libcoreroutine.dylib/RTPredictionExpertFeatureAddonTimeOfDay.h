@class NSDateComponents;

@interface RTPredictionExpertFeatureAddonTimeOfDay : RTPredictionExpertFeatureAddon

@property (readonly, nonatomic) NSDateComponents *startDateComponents;
@property (readonly, nonatomic) NSDateComponents *endDateComponents;

+ (id)timeOfDayFeatureAddonsWithRequestedDuration:(double)a0 offsetFromMidnight:(double)a1;

- (id)initWithStartDateComponents:(id)a0 endDateComponents:(id)a1;
- (long long)addonType;
- (void).cxx_destruct;
- (id)description;

@end
