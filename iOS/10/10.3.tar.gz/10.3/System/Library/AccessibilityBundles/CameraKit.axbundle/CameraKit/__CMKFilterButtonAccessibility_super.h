@interface __CMKFilterButtonAccessibility_super : UIAccessibilitySafeCategory

@end
