@interface __ABStyleProviderAccessibility_super : UIAccessibilitySafeCategory

@end
