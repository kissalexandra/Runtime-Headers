@class NSString, NSArray, NSPersistentStoreCoordinator, NSObject;
@protocol OS_dispatch_queue;

@interface RTPersistenceContainer : NSObject {
    NSArray *_configurations;
    NSPersistentStoreCoordinator *_coordinator;
}

@property (retain) NSObject<OS_dispatch_queue> *contextRequestsQueue;
@property BOOL serveContexts;
@property BOOL setupFailed;
@property (readonly) NSString *name;
@property (readonly) BOOL storesNeedSetup;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (id)initWithName:(id)a0 model:(id)a1 configurations:(id)a2;
- (BOOL)_validateConfigurations:(id)a0;
- (void)suspendPersistenceStores;
- (void)resumePersistenceStores;
- (void)setupPersistenceStores;
- (BOOL)updateContainerConfigurations:(id)a0;
- (void)persistenceContextWithHandler:(id /* block */)a0;
- (id)persistenceContext;
- (id)waitForPersistenceContext;
- (id)_persistenceContext;

@end
