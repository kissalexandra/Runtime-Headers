@interface __CMKPreviewViewAccessibility_super : UIAccessibilitySafeCategory

@end
