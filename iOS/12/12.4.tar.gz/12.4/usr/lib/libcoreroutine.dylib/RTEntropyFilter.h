@class NSCountedSet;

@interface RTEntropyFilter : NSObject

@property (nonatomic) double maximumEntropy;
@property (retain, nonatomic) NSCountedSet *globalEvents;
@property (retain, nonatomic) NSCountedSet *relevantEvents;

- (id)initWithGlobalEvents:(id)a0 relevantEvents:(id)a1 maximumEntropy:(double)a2;
- (id)initWithMaximumEntropy:(double)a0;
- (void)addReleventEvent:(id)a0;
- (void)addGlobalEvents:(id)a0;
- (double)weightForBundleIdentifier:(id)a0;
- (id)init;
- (void).cxx_destruct;
- (void)removeAllEvents;

@end
