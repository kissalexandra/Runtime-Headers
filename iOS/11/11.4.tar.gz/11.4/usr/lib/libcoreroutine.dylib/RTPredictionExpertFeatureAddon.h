@class NSPredicate;

@interface RTPredictionExpertFeatureAddon : NSObject

@property (readonly, nonatomic) NSPredicate *eventFilterPredicate;

- (void).cxx_destruct;
- (id)initWithPredicate:(id)a0;
- (long long)addonType;

@end
