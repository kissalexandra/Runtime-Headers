@interface __MKStarRatingViewAccessibility_super : UIAccessibilitySafeCategory

@end
