@class NSUUID, NSDate, GEORoute;

@interface RTGeoRouteMO : NSManagedObject

@property (retain, nonatomic) GEORoute *geoRoute;
@property (retain, nonatomic) NSUUID *identifier;
@property (retain, nonatomic) NSUUID *originLocationOfInterestIdentifier;
@property (retain, nonatomic) NSUUID *destinationLocationOfInterestIdentifier;
@property (copy, nonatomic) NSDate *creationDate;

+ (id)fetchRequest;
+ (id)managedObjectWithGeoRoute:(id)a0 inManagedObjectContext:(id)a1;

@end
