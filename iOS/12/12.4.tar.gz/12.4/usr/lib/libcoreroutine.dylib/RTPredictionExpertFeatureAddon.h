@class NSPredicate;

@interface RTPredictionExpertFeatureAddon : NSObject

@property (readonly, nonatomic) NSPredicate *eventFilterPredicate;

- (id)initWithPredicate:(id)a0;
- (long long)addonType;
- (void).cxx_destruct;

@end
