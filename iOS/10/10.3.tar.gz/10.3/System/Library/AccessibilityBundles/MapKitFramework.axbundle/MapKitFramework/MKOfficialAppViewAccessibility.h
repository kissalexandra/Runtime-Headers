@interface MKOfficialAppViewAccessibility : __MKOfficialAppViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (BOOL)isAccessibilityElement;
- (id)_accessibilitySupplementaryFooterViews;

@end
