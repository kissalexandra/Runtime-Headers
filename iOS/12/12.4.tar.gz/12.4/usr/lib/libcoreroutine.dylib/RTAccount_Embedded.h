@interface RTAccount_Embedded : RTAccount

- (id)initWithACAccount:(id)a0;

@end
