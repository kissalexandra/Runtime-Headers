@class NSString, NSObject, NWConcrete_nw_protocol_definition;
@protocol OS_nw_parameters, OS_nw_endpoint, OS_nw_path_flow_registration, OS_nw_array;

@interface NWConcrete_nw_protocol_instance : NSObject <OS_nw_protocol_instance> {
    NWConcrete_nw_protocol_definition *parent_definition;
    struct nw_protocol_callbacks { void /* function */ *add_input_handler; void /* function */ *remove_input_handler; void /* function */ *replace_input_handler; void /* function */ *connect; void /* function */ *disconnect; void /* function */ *connected; void /* function */ *disconnected; void /* function */ *error; void /* function */ *input_available; void /* function */ *output_available; void /* function */ *get_input_frames; void /* function */ *get_output_frames; void /* function */ *finalize_output_frames; void /* function */ *link_state; void /* function */ *get_parameters; void /* function */ *get_path; void /* function */ *get_local_endpoint; void /* function */ *get_remote_endpoint; void /* function */ *register_notification; void /* function */ *unregister_notification; void /* function */ *notify; void /* function */ *updated_path; void /* function */ *supports_external_data; void /* function */ *input_finished; void /* function */ *output_finished; void /* function */ *get_output_local_endpoint; void /* function */ *get_output_interface; void /* function */ *waiting_for_output; void /* function */ *copy_info; void /* function */ *add_listen_handler; void /* function */ *remove_listen_handler; void /* function */ *get_message_properties; void /* function */ *reset; void /* function */ *input_flush; } callbacks;
    struct nw_protocol { unsigned char flow_id[16]; struct nw_protocol_identifier *identifier; struct nw_protocol_callbacks *callbacks; struct nw_protocol *output_handler; void *handle; struct nw_protocol *default_input_handler; void *output_handler_context; } protocol;
    struct nw_listen_protocol { struct nw_listen_protocol_callbacks *x0; struct nw_protocol *x1; void *x2; void *x3; } *listen_handler;
    void *destroy_timer;
    NSObject<OS_nw_endpoint> *endpoint;
    NSObject<OS_nw_parameters> *parameters;
    unsigned long long reserve_header_size;
    unsigned long long reserve_footer_size;
    unsigned long long maximum_content_size;
    unsigned int protocol_outbound_data_limit;
    void *handle;
    struct nw_frame_array_s { struct nw_frame *tqh_first; struct nw_frame **tqh_last; } inbound_frames;
    struct nw_frame_array_s { struct nw_frame *tqh_first; struct nw_frame **tqh_last; } outbound_frames;
    struct nw_frame_array_s { struct nw_frame *tqh_first; struct nw_frame **tqh_last; } pending_inbound_frames;
    unsigned int pending_inbound_frame_count;
    unsigned int pending_inbound_frame_bytes;
    struct nw_frame_array_s { struct nw_frame *tqh_first; struct nw_frame **tqh_last; } pending_outbound_frames;
    NSObject<OS_nw_array> *outbound_data_requests;
    struct nw_hash_table { } *flows_table;
    struct nw_hash_table { } *custom_flow_mapping_table;
    unsigned long long last_accepted_flow;
    id /* block */ wakeup;
    NSObject<OS_nw_path_flow_registration> *flow_registration;
    unsigned char initialized : 1;
    unsigned char started : 1;
    unsigned char ready : 1;
    unsigned char output_connected : 1;
    unsigned char allow_buffering : 1;
    unsigned char limit_outbound_data : 1;
    unsigned char datagram : 1;
    unsigned char supports_external_data : 1;
    unsigned char link_flow_controlled : 1;
    unsigned char waiting_for_link_flow_control : 1;
    unsigned char processing_input : 1;
    unsigned char processing_output : 1;
    unsigned char waiting_for_listener_accept : 1;
    unsigned char new_flow_is_control : 1;
    unsigned char should_destroy : 1;
    unsigned char input_acknowledged : 1;
    unsigned char needs_output_available : 1;
    unsigned char needs_finalize_output : 1;
    char log_str[84];
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

@end
