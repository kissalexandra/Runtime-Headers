@interface OTABMUResistance : PBCodable <NSCopying> {
    struct { unsigned char traceResistance25C : 1; unsigned char traceResistanceTemperatureCoeff : 1; } _has;
}

@property (nonatomic) BOOL hasTraceResistance25C;
@property (nonatomic) float traceResistance25C;
@property (nonatomic) BOOL hasTraceResistanceTemperatureCoeff;
@property (nonatomic) float traceResistanceTemperatureCoeff;

- (BOOL)readFrom:(id)a0;
- (void)writeTo:(id)a0;
- (void)mergeFrom:(id)a0;
- (BOOL)isEqual:(id)a0;
- (unsigned long long)hash;
- (id)description;
- (id)copyWithZone:(struct _NSZone { } *)a0;
- (id)dictionaryRepresentation;
- (void)copyTo:(id)a0;

@end
