@interface RTIOKitIOServiceStrategy : NSObject <RTIOServiceStrategy>

- (id)propertiesForService:(unsigned int)a0;

@end
