@interface CMKPanoramaViewAccessibility : __CMKPanoramaViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_updateInstructionalText:(id)a0;
- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0 centerYOffset:(double)a1 panoramaPreviewScale:(float)a2;

@end
