@interface __ABSwellTextViewAccessibility_super : UIAccessibilitySafeCategory

@end
