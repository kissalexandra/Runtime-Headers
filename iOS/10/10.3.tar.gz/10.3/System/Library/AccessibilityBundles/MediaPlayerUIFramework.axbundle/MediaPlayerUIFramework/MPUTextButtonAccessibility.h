@interface MPUTextButtonAccessibility : __MPUTextButtonAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;

@end
