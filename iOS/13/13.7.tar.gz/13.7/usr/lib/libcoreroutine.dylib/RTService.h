@interface RTService : RTNotifier

- (void)_setup;
- (void)shutdown;
- (void)setup;
- (void)_shutdown;

@end
