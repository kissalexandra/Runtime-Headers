@interface MFAttachmentAccessibility : __MFAttachmentAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)markupStringForDisplayWithData:(id)a0 displayStyle:(int)a1 printableWidth:(double)a2 allowAttachmentElement:(BOOL)a3;

@end
