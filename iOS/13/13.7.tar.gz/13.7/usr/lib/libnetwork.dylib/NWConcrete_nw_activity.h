@class NSString;

@interface NWConcrete_nw_activity : NSObject <OS_nw_activity> {
    unsigned char token[16];
    unsigned long long investigation_identifier;
    unsigned long long start_time;
    unsigned long long end_time;
    NWConcrete_nw_activity *parent;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } lock;
    unsigned int label;
    unsigned int domain;
    int reporting_strategy;
    int completion_reason;
    unsigned char is_retry : 1;
    unsigned char is_lightweight : 1;
    unsigned char activated : 1;
    unsigned char completed : 1;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)dealloc;
- (id)redactedDescription;
- (void).cxx_destruct;
- (id)initWithDomain:(unsigned int)a0 label:(unsigned int)a1;
- (id)initWithToken:(unsigned char[16])a0;
- (id)initWithOriginal:(id)a0;

@end
