@interface RTReachabilityMonitorNotificationReachabilityChanged : RTNotification

@property (readonly, nonatomic) long long reachability;

- (id)initWithReachability:(long long)a0;

@end
