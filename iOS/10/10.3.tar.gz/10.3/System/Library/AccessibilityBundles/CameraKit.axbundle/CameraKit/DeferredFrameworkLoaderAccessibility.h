@interface DeferredFrameworkLoaderAccessibility : __DeferredFrameworkLoaderAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (Class)classFromString:(id)a0;

@end
