@interface OS_nw_nexus : OS_object

- (void)_dispose;

@end
