@class RTDefaultsManager, NSArray, NSUUID, RTEventStoreHistogram, RTPredictionExpertDataSource, NSObject, NSString;
@protocol OS_dispatch_queue;

@interface RTPredictionExpert : NSObject <RTPredictionExpertProtocol> {
    RTDefaultsManager *_defaultsManager;
}

@property (retain, nonatomic) RTEventStoreHistogram *histogram;
@property (retain, nonatomic) NSArray *featureAddons;
@property (nonatomic) long long category;
@property (retain, nonatomic) NSUUID *identifier;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain, nonatomic) NSArray *dataProviders;
@property (readonly, nonatomic) RTPredictionExpertDataSource *dataSource;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)processData:(id /* block */)a0;
- (id)dataProviderForName:(id)a0;
- (id)_createEventStoreWithClasses:(id)a0;
- (void)createExpertMetricWithHandler:(id /* block */)a0;
- (id)initWithQueue:(id)a0 category:(long long)a1 dataSource:(id)a2 defaultsManager:(id)a3;
- (id)_combinedFilterPredicate;
- (id)_combinedFilterPredicateForAddonType:(long long)a0;

@end
