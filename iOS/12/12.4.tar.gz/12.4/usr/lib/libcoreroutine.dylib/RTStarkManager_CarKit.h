@interface RTStarkManager_CarKit : RTStarkManager

@property (nonatomic) BOOL trustedConnectionEstablished;

- (void)setup;
- (void)_setup;
- (void)_shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithDefaultsManager:(id)a0;
- (void)onPairedVehiclesDidChange:(id)a0;
- (void)_updateTrustedConnectionEstablished;
- (void)_fetchConnectionStateWithHandler:(id /* block */)a0;

@end
