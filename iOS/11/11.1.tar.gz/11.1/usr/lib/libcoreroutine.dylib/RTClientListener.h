@class RTEventAgentManager, RTDeviceLocationPredictor, RTLocationStore, RTAssetManager, RTLocationManager, NSString, RTAccountManager, RTAuthorizationManager, RTLearnedLocationManager, RTVisitManager, NSMutableDictionary, RTScenarioTriggerManager, RTActionManager, RTMetricManager, RTRouteManager, RTDiagnostics, RTPredictedContentManager, RTPredictedApplicationManager, RTEventModelProvider, RTVehicleLocationProvider, RTPurgeManager;

@interface RTClientListener : RTXPCListener <RTClientListenerProtocol, NSXPCListenerDelegate>

@property (retain, nonatomic) NSMutableDictionary *persistedClients;
@property (retain, nonatomic) RTPredictedApplicationManager *predictedApplicationManager;
@property (retain, nonatomic) RTScenarioTriggerManager *scenarioTriggerManager;
@property (retain, nonatomic) RTVehicleLocationProvider *vehicleLocationProvider;
@property (retain, nonatomic) RTAuthorizationManager *authorizationManager;
@property (retain, nonatomic) RTDeviceLocationPredictor *deviceLocationPredictor;
@property (retain, nonatomic) RTPurgeManager *purgeManager;
@property (retain, nonatomic) RTActionManager *actionManager;
@property (retain, nonatomic) RTEventModelProvider *eventModelProvider;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) RTAssetManager *assetManager;
@property (retain, nonatomic) RTLocationStore *locationStore;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTEventAgentManager *eventAgentManager;
@property (retain, nonatomic) RTDiagnostics *diagnostics;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTRouteManager *routeManager;
@property (retain, nonatomic) RTPredictedContentManager *predictedContentManager;
@property (retain, nonatomic) RTAccountManager *accountManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)persistedClientsPath;

- (id)init;
- (void).cxx_destruct;
- (BOOL)listener:(id)a0 shouldAcceptNewConnection:(id)a1;
- (void)_setup;
- (id)handleClientConnection:(id)a0;
- (id)handleRestorationForDaemonClient:(id)a0;
- (void)handleDisconnectionForDaemonClient:(id)a0;
- (void)saveDaemonClient:(id)a0;
- (id)initWithDeviceLocationPredictor:(id)a0 scenarioTriggerManager:(id)a1 vehicleLocationProvider:(id)a2 predictedApplicationManager:(id)a3 actionManager:(id)a4 eventModelProvider:(id)a5 visitManager:(id)a6 authorizationManager:(id)a7 purgeManager:(id)a8 assetManager:(id)a9 locationStore:(id)a10 locationManager:(id)a11 eventAgentManager:(id)a12 diagnostics:(id)a13 learnedLocationManager:(id)a14 routeManager:(id)a15 predictedContentManager:(id)a16 accountManager:(id)a17 metricManager:(id)a18;

@end
