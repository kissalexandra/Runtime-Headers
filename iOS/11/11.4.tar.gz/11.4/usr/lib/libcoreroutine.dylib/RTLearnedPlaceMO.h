@class NSString, NSUUID, NSData, NSDate, NSNumber, NSSet;
@protocol GEOMapItem;

@interface RTLearnedPlaceMO : RTCloudManagedObject

@property (copy, nonatomic) NSString *customLabel;
@property (copy, nonatomic) NSDate *mapItemCreationDate;
@property (retain, nonatomic) id<GEOMapItem> mapItemGeoMapItem;
@property (retain, nonatomic) NSData *mapItemGeoMapItemHandle;
@property (retain, nonatomic) NSUUID *mapItemIdentifier;
@property (copy, nonatomic) NSNumber *mapItemSource;
@property (copy, nonatomic) NSNumber *type;
@property (copy, nonatomic) NSNumber *typeSource;
@property (retain, nonatomic) NSSet *visits;

+ (id)fetchRequest;
+ (id)managedObjectWithPlace:(id)a0 inManagedObjectContext:(id)a1;
+ (id)managedObjectWithPlace:(id)a0 managedObject:(id)a1 inManagedObjectContext:(id)a2;

- (void)willSave;

@end
