@interface OS_nw_frame : OS_object

- (void)_dispose;

@end
