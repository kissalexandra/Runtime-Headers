@interface NWConcrete_nw_bonjour_service_endpoint : NWConcrete_nw_endpoint {
    char *service_name;
    char *service_type;
    char *service_domain;
    char *service_composite;
}

- (BOOL)isEqualToEndpoint:(id)a0 matchInterface:(BOOL)a1;
- (unsigned long long)getHash;
- (const char *)domainForPolicy;
- (id)copyDictionary;
- (id)initWithName:(const char *)a0 type:(const char *)a1 domain:(const char *)a2;
- (void)dealloc;
- (unsigned int)type;
- (const char *)getDescription;

@end
