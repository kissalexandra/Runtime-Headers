@interface MKPlaceHoursViewControllerAccessibility : __MKPlaceHoursViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_toggleShowAllHours;

@end
