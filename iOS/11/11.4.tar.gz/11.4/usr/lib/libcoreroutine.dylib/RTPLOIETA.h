@class NSString, RTLOIDisplayInfo, RTPredictedLocationOfInterest;
@protocol GEOMapItem;

@interface RTPLOIETA : NSObject {
    id<GEOMapItem> _origin;
    unsigned int _responseETASeconds;
    unsigned int _baselineETASeconds;
    NSString *_responseRouteDescription;
    RTLOIDisplayInfo *_displayInfo;
}

@property (readonly, nonatomic) RTPredictedLocationOfInterest *ploi;

- (unsigned long long)trafficDensity;
- (id)mapsURL;
- (void).cxx_destruct;
- (id)description;
- (id)localizedDescription;
- (id)localizedTitle;
- (id)localizedMessage;
- (id)initWithPLOI:(id)a0 origin:(id)a1 responseETASeconds:(unsigned int)a2 baselineETASeconds:(unsigned int)a3 responseRouteDescription:(id)a4;
- (id)_displayInfoForDate:(id)a0;
- (id)displayInfo;
- (BOOL)etaExceedsMinimumETA:(unsigned int)a0;
- (BOOL)hasEquivalentDisplayTo:(id)a0;

@end
