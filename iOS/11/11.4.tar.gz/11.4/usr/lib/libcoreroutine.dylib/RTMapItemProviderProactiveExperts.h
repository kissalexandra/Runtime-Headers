@class RTConnectionsLocationManager, RTMapServiceManager, NSString;

@interface RTMapItemProviderProactiveExperts : RTMapItemProviderBase <RTMapItemProvider>

@property (retain, nonatomic) RTConnectionsLocationManager *connectionsLocationManager;
@property (retain, nonatomic) RTMapServiceManager *mapServiceManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (id)mapItemsWithinDistance:(double)a0 location:(id)a1 startDate:(id)a2 endDate:(id)a3 error:(id *)a4;
- (id)initWithConnectionsLocationManager:(id)a0 distanceCalculator:(id)a1 mapServiceManager:(id)a2;
- (id)_recentLocationsFrom:(id)a0 error:(id *)a1;
- (id)_filterConnectionLocations:(id)a0 location:(id)a1 distance:(double)a2 error:(id *)a3;
- (id)_mapItemsWithConnectionsLocations:(id)a0;

@end
