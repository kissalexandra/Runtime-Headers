@class NSCountedSet;

@interface RTEntropyFilter : NSObject

@property (nonatomic) double maximumEntropy;
@property (retain, nonatomic) NSCountedSet *globalEvents;
@property (retain, nonatomic) NSCountedSet *relevantEvents;

- (id)init;
- (void).cxx_destruct;
- (id)initWithMaximumEntropy:(double)a0;
- (id)initWithGlobalEvents:(id)a0 relevantEvents:(id)a1 maximumEntropy:(double)a2;
- (void)addReleventEvent:(id)a0;
- (void)addGlobalEvents:(id)a0;
- (void)removeAllEvents;
- (double)weightForBundleIdentifier:(id)a0;

@end
