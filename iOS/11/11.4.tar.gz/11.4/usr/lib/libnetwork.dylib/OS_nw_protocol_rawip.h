@interface OS_nw_protocol_rawip : OS_object

- (void)_dispose;

@end
