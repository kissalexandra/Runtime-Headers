@class RTMapItem;

@interface RTInferredMapItem : NSObject

@property (readonly, nonatomic) RTMapItem *mapItem;
@property (readonly, nonatomic) double confidence;
@property (readonly, nonatomic) unsigned long long source;

+ (BOOL)hasKnownTypeItem:(id)a0;
+ (id)dedupeInferredMapItems:(id)a0;
+ (id)heaviestMapItemFrom:(id)a0 closestToLocation:(id)a1 distanceCalculator:(id)a2 error:(id *)a3;
+ (double)consolidatedConfidenceFromConfidences:(id)a0;
+ (unsigned long long)consolidatedSourceFromInferredMapItems:(id)a0;

- (id)initWithMapItem:(id)a0 confidence:(double)a1 source:(unsigned long long)a2;
- (id)init;
- (void).cxx_destruct;
- (id)description;

@end
