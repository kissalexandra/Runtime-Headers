@interface CMKFlashButtonAccessibility : __CMKFlashButtonAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)layoutSubviews;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;
- (BOOL)accessibilityActivate;
- (BOOL)_accessibilitySupportsActivateAction;

@end
