@class NSArray, NSObject;
@protocol OS_dispatch_source;

@interface RTPurgeManager : RTNotifier

@property (retain, nonatomic) NSObject<OS_dispatch_source> *memoryWarningDispatchSource;
@property (nonatomic) long long pressureState;
@property (retain, nonatomic) NSArray *purgers;

+ (id)earliestRawLocationDate;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)shutdown;
- (void)purge:(id /* block */)a0;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithDefaultsManager:(id)a0 platform:(id)a1 purgers:(id)a2;
- (void)_registerForMemoryPressureWarnings;
- (void)_unregisterForMemoryPressureWarnings;
- (void)_purge:(id /* block */)a0;
- (void)clearRoutineWithHandler:(id /* block */)a0;
- (void)onCoreLocationPrivacyReset;
- (void)_purgeWithType:(long long)a0 handler:(id /* block */)a1;

@end
