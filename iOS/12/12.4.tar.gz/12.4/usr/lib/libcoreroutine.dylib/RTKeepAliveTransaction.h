@interface RTKeepAliveTransaction : RTTransaction

- (id)initForObject:(id)a0 description:(id)a1;
- (void)dealloc;

@end
