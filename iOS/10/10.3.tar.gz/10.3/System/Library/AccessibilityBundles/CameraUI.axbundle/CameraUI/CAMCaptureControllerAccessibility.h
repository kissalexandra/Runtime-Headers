@interface CAMCaptureControllerAccessibility : __CAMCaptureControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_accessibilityLoadAccessibilityInformation;
- (id)initWithCaptureConfiguration:(id)a0 engineOptions:(long long)a1 locationController:(id)a2 motionController:(id)a3 burstController:(id)a4 protectionController:(id)a5 powerController:(id)a6 remoteShutterController:(id)a7;

@end
