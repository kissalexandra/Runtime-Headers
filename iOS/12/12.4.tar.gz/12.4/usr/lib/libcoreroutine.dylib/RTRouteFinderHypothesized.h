@class NSArray, NSString, NSObject, RTMapAccess;
@protocol OS_dispatch_queue;

@interface RTRouteFinderHypothesized : NSObject <RTRouteFinderProtocol>

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (copy, nonatomic) id /* block */ handler;
@property (retain, nonatomic) RTMapAccess *mapAccess;
@property (retain, nonatomic) NSArray *routeBeforeHypothesis;
@property (retain, nonatomic) NSArray *routeFromHypothesis;
@property (retain, nonatomic) NSArray *routeAfterHypothesis;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)initWithQueue:(id)a0 mapAccess:(id)a1;
- (void)findRouteForWaypoints:(id)a0 routeHandler:(id /* block */)a1;
- (void)_fallbackToDefaultRouteFinderForWaypoints:(id)a0 routeHandler:(id /* block */)a1;
- (double)_verifyHypothesisRoute:(id)a0 locations:(id)a1 outStartLocationIndex:(long long *)a2 outEndLocationIndex:(long long *)a3;
- (void)_findSubRouteForLocations:(id)a0 originRoad:(id)a1 destinationRoad:(id)a2 handler:(id /* block */)a3;
- (void)_findRoadsOnHypothesisRoute:(id)a0 startSegmentIndex:(unsigned int)a1 endSegmentIndex:(unsigned int)a2 handler:(id /* block */)a3;
- (void)_findRouteForWaypoints:(id)a0 hypothesisRoutes:(id)a1 routeHandler:(id /* block */)a2;
- (void)findRouteForWaypoints:(id)a0 hypothesisRoutes:(id)a1 routeHandler:(id /* block */)a2;
- (void).cxx_destruct;

@end
