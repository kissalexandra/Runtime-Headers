@interface RTService : RTNotifier

- (void)setup;
- (void)_setup;
- (void)shutdown;
- (void)_shutdown;

@end
