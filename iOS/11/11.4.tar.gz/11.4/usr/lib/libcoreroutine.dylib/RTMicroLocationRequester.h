@class PKHost, RTDarwinNotificationHelper, NSUUID, NSString, RTPlatform, RTVisitManager, RTDefaultsManager, RTLocationManager, FBSDisplayLayoutMonitor, NSObject;
@protocol OS_dispatch_queue;

@interface RTMicroLocationRequester : NSObject <FBSDisplayLayoutObserver>

@property (retain, nonatomic) id driver;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (nonatomic) BOOL monitoringForMicroLocations;
@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTVisitManager *visitManager;
@property (retain, nonatomic) FBSDisplayLayoutMonitor *frontBoardLayoutMonitor;
@property (retain, nonatomic) RTDefaultsManager *defaultsManager;
@property (retain, nonatomic) PKHost *pluginKitHost;
@property (retain, nonatomic) RTDarwinNotificationHelper *darwinNotificationHelper;
@property (retain, nonatomic) RTPlatform *platform;
@property (nonatomic) BOOL platformSupportsMicroLocations;
@property (nonatomic) BOOL displayBacklit;
@property (nonatomic) BOOL applicationPredictionExtensionEnabled;
@property (nonatomic) BOOL zeroKeywordEnabled;
@property (retain, nonatomic) NSUUID *lastLocationOfInterestIdentifier;
@property (nonatomic) BOOL locationEligibleForMicroLocations;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (void)layoutMonitor:(id)a0 didUpdateDisplayLayout:(id)a1 withContext:(id)a2;
- (void)_unregisterForNotifications;
- (void)shutdown;
- (void)_fetchLowConfidenceVisitIncident:(id /* block */)a0;
- (void)onVisitManagerAvailable:(id)a0;
- (void)onLowConfidenceVisitNotification:(id)a0;
- (id)initWithLocationManager:(id)a0 visitManager:(id)a1 defaultsManager:(id)a2 darwinNotificationHelper:(id)a3 platform:(id)a4;
- (id)initWithLocationManager:(id)a0 visitManager:(id)a1 frontBoardLayoutMonitor:(id)a2 defaultsManager:(id)a3 pluginKitHost:(id)a4 darwinNotificationHelper:(id)a5 platform:(id)a6;
- (void)_registerForPredictedApplicationExtensionStatusChangeNotifications;
- (void)_unregisterForPredictedApplicationExtensionStatusChangeNotifications;
- (void)_updatePredictedApplicationExtensions:(id)a0 error:(id)a1;
- (void)_resumeNotifications;
- (void)_suspendNotifications;
- (BOOL)_determineZeroKeywordEnabled;
- (void)_registerForZeroKeywordStatusChangeNotifications;
- (void)_onLowConfidenceVisitIncident:(id)a0;
- (void)_handleMicroLocationRequestEligibilityUpdate:(id)a0;
- (BOOL)_allowMonitoringForMicroLocations;
- (BOOL)_allowRequestingForMicroLocations;
- (void)_requestMonitorForMicroLocations:(BOOL)a0 atLocationOfInterestWithIdentifier:(id)a1;
- (void)_onBacklightChange:(BOOL)a0;

@end
