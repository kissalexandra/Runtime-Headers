@interface CAMPreviewViewAccessibility : __CAMPreviewViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0;
- (void)dealloc;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;
- (struct CGPoint { double x0; double x1; })accessibilityActivationPoint;
- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;
- (id)accessibilityElements;
- (void)_showFocusAtPoint:(struct CGPoint { double x0; double x1; })a0 startAnimating:(BOOL)a1;
- (id)_accessibilityFaceElements;
- (BOOL)_axShowingEffects;
- (BOOL)_axIsFocusLocked;
- (void)_accessibilityZoomIn:(BOOL)a0;
- (BOOL)_axIsBackFacing;
- (BOOL)_axIsPortraitMode;
- (void)_accessibilityLoadAccessibilityInformation;
- (BOOL)_accessibilityAllowsSiblingsWhenOvergrown;
- (void)accessibilityZoomInAtPoint:(struct CGPoint { double x0; double x1; })a0;
- (void)accessibilityZoomOutAtPoint:(struct CGPoint { double x0; double x1; })a0;

@end
