@class NSString;

@interface RTXPCActivityTask : NSObject

@property (readonly, copy, nonatomic) NSString *identifier;
@property (readonly, copy, nonatomic) id /* block */ handler;

- (id)initWithIdentifier:(id)a0 handler:(id /* block */)a1;
- (id)init;
- (void).cxx_destruct;

@end
