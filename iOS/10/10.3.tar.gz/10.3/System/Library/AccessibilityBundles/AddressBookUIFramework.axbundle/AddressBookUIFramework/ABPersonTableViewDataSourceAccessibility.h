@interface ABPersonTableViewDataSourceAccessibility : __ABPersonTableViewDataSourceAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)setTableView:(id)a0;

@end
