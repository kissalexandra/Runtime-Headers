@interface RTManagedConfiguration_Embedded : RTManagedConfiguration

- (void)dealloc;
- (void)setDelegate:(id)a0;
- (BOOL)effectiveBoolValueForSetting:(id)a0;
- (void)profileConnectionDidReceiveEffectiveSettingsChangedNotification:(id)a0 userInfo:(id)a1;
- (BOOL)isFindMyCarAllowed;
- (BOOL)isDiagnosticsAndUsageAllowed;
- (id)stringToManagedConfigurationKey:(id)a0;

@end
