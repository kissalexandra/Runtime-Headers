@interface MKPlaceInfoEmailRowViewAccessibility : __MKPlaceInfoEmailRowViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)_icon;

@end
