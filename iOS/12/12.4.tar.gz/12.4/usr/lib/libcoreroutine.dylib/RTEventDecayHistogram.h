@class NSString, NSDate;

@interface RTEventDecayHistogram : RTEventWeightedHistogram <RTEventHistogram>

@property (readonly, nonatomic) double decayRate;
@property (readonly, nonatomic) double unitDecayTimeInterval;
@property (retain, nonatomic) NSDate *referenceDate;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (BOOL)supportsSecureCoding;

- (void)addEvent:(id)a0 weight:(double)a1;
- (id)initWithDecayRate:(double)a0 date:(id)a1 unitDecayTimeInterval:(double)a2;
- (id)initWithDecayRate:(double)a0 date:(id)a1;
- (double)decayTimeExponent:(id)a0;
- (id)init;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (void)reset;

@end
