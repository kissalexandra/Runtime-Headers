@interface ABMultiCellContentView_RowsAccessibility : __ABMultiCellContentView_RowsAccessibility_super

+ (struct CGSize { double x0; double x1; })layoutSubviewsForView:(id)a0 usingSize:(struct CGSize { double x0; double x1; })a1 propertyGroup:(id)a2 info:(id)a3 styleProvider:(id)a4 whenEditing:(BOOL)a5;
+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)updateSubviewsForNewStateAnimated:(BOOL)a0;

@end
