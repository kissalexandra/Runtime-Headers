@interface MPTransportControlsAccessibility : __MPTransportControlsAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityViewIsModal;
- (void)_playbackStateChangedNotification:(id)a0;
- (void)_reloadViewWithAnimation:(BOOL)a0;
- (void)_accessibilityApplyIDsToTransformButtons;
- (void)_accessibilityLoadAccessibilityInformation;

@end
