@interface OS_os_eventlog : OS_object

@end
