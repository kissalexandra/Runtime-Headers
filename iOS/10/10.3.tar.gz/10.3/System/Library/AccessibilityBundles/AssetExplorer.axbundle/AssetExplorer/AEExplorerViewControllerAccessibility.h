@interface AEExplorerViewControllerAccessibility : __AEExplorerViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_accessibilityLoadAccessibilityInformation;
- (void)_handleAttemptedSelectionToggleOfAssetReference:(id)a0 cancelIfAlreadySelected:(BOOL)a1 suppressLivePhotoContent:(BOOL)a2;

@end
