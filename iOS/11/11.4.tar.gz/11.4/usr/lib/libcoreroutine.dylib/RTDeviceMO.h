@class NSString, NSSet, NSDate;

@interface RTDeviceMO : RTCloudManagedObject

@property (copy, nonatomic) NSString *deviceName;
@property (copy, nonatomic) NSString *deviceClass;
@property (copy, nonatomic) NSString *deviceModel;
@property (retain, nonatomic) NSSet *places;
@property (retain, nonatomic) NSSet *visits;
@property (retain, nonatomic) NSSet *transitions;
@property (readonly, nonatomic) RTDeviceMO *device;
@property (copy, nonatomic) NSDate *creationDate;
@property (copy, nonatomic) NSDate *expirationDate;

+ (id)fetchRequest;
+ (id)managedObjectWithIdentifier:(id)a0 deviceName:(id)a1 deviceClass:(id)a2 deviceModel:(id)a3 inManagedObjectContext:(id)a4;

- (void)setDevice:(id)a0;

@end
