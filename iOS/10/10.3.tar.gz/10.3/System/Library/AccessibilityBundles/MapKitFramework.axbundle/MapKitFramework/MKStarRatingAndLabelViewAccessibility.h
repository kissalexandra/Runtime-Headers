@interface MKStarRatingAndLabelViewAccessibility : __MKStarRatingAndLabelViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (id)ratingAndReviewsAsAttributedString:(double)a0 style:(long long)a1 font:(id)a2 numberOfReviews:(unsigned long long)a3 textColor:(id)a4;
+ (id)starRatingAndProviderAsAttributedStringForMapItem:(id)a0 textColor:(id)a1 font:(id)a2 showReviewsOrTips:(BOOL)a3 theme:(id)a4;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (BOOL)isAccessibilityElement;

@end
