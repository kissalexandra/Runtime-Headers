@class RTKeepAliveTransaction, RTDataProtectionManager, RTDeviceMO, NSObject, RTDefaultsManager, RTMemoryTransaction, RTPlatform, RTMetricManager, NSManagedObjectContext, NSString, RTKeychainManager, RTPersistenceManager, RTLifeCycleManager, RTAccount, RTAccountManager;
@protocol OS_dispatch_queue;

@interface RTPersistenceDriver : NSObject <RTPersistenceDelegate> {
    RTDeviceMO *_resetSyncCurrentDevice;
    NSManagedObjectContext *_resetSyncContext;
}

@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (retain) RTKeepAliveTransaction *keepAliveTransaction;
@property (retain) RTMemoryTransaction *memoryTransaction;
@property BOOL requiresDirtyTransaction;
@property BOOL requiresSetupTransaction;
@property long long cloudSyncAuthorization;
@property long long encryptedDataAvailability;
@property (retain) RTAccount *currentAccount;
@property (readonly) RTPersistenceManager *persistenceManager;
@property (readonly) RTDataProtectionManager *dataProtectionManager;
@property (readonly) RTAccountManager *accountManager;
@property (readonly) RTPlatform *currentPlatform;
@property (readonly) RTMetricManager *metricManager;
@property (readonly) RTKeychainManager *keychainManager;
@property (retain) RTDefaultsManager *defaultsManager;
@property (retain) RTLifeCycleManager *lifecycleManager;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)shutdown;
- (id)initWithPersistenceManager:(id)a0 dataProtectionManager:(id)a1 accountManager:(id)a2 platform:(id)a3 metricManager:(id)a4 keychainManager:(id)a5 defaultsManager:(id)a6 lifecycleManager:(id)a7;
- (void)onDataProtectionChange:(id)a0;
- (void)persistenceStore:(id)a0 failedWithError:(id)a1;
- (id)appleIDsForStore:(id)a0;
- (BOOL)store:(id)a0 validateAppleIDs:(id)a1;
- (BOOL)prepareStore:(id)a0 withContext:(id)a1 error:(id *)a2;
- (BOOL)backupPersistenceStore:(id)a0 error:(id *)a1;
- (void)onCloudSyncAuthorizationChange:(id)a0;
- (void)onAccountChange:(id)a0;
- (void)_onDataProtectionChange:(id)a0;
- (void)_evaluteDirtyTransactionAfterConfigurationChange:(long long)a0;
- (void)_setupPersistenceAfterConfigurationChange:(long long)a0 cloudSyncAuthorization:(long long)a1 account:(id)a2;
- (void)_onCloudSyncAuthorizationChange:(id)a0;
- (void)_onAccountChange:(id)a0;
- (void)evaluateTransactions;
- (unsigned long long)persistenceDeviceClassForPlatform;
- (void)cleanupOlderPersistentStores;
- (BOOL)purgeExpiredRecordsFromPersistenceStore:(id)a0 withContext:(id)a1 error:(id *)a2;
- (void)persistenceManagerWillStartResetSync:(id)a0;
- (void)persistenceManagerDidFinishResetSync:(id)a0;
- (id)optionsForStoreWithType:(unsigned long long)a0 error:(id *)a1;
- (id)mirroringOptionsForStoreWithType:(unsigned long long)a0;
- (void)persistenceStore:(id)a0 encounteredCriticalError:(id)a1;
- (id)init;
- (void)dealloc;
- (void).cxx_destruct;
- (void)start;

@end
