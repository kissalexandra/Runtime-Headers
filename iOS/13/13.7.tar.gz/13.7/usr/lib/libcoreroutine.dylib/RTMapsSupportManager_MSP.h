@class RTTimerManager, NSMutableDictionary, RTTimer, NSString, MSPFavoritesContainer, MSPHistoryContainer, MSPPinnedPlacesContainer;

@interface RTMapsSupportManager_MSP : RTMapsSupportManager <MSPQueryDelegate> {
    MSPFavoritesContainer *_favoritesContainer;
    MSPHistoryContainer *_historyContainer;
    MSPPinnedPlacesContainer *_pinnedPlacesContainer;
    RTTimerManager *_timerManager;
}

@property (retain, nonatomic) RTTimer *queryTimer;
@property (readonly, nonatomic) NSMutableDictionary *queryMap;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)createQueryWithContainer:(id)a0 delegate:(id)a1 filteredWithBlock:(id /* block */)a2;

- (void)dealloc;
- (void).cxx_destruct;
- (void)_setup;
- (void)setup;
- (void)queryContentsDidLoad:(id)a0 contentsVersion:(unsigned long long)a1;
- (void)queryContentsDidChange:(id)a0 contentsVersion:(unsigned long long)a1;
- (id)favoritesContainer;
- (id)historyContainer;
- (id)pinnedPlacesContainer;
- (void)_showParkedCarBulletinForEvent:(id)a0;
- (void)_showParkedCarReplacementBulletinForEvent:(id)a0 replacingEvent:(id)a1;
- (void)_clearParkedCarBulletin;
- (id)initWithMapServiceManager:(id)a0 timerManager:(id)a1;
- (void)_fetchFavoritePlacesWithHandler:(id /* block */)a0;
- (void)_fetchPinnedPlacesWithHandler:(id /* block */)a0;
- (void)_fetchHistoryEntryPlaceDisplaysWithHandler:(id /* block */)a0;
- (void)_fetchHistoryEntryRoutesWithHandler:(id /* block */)a0;
- (void)_createContainers;
- (void)_createQueries;
- (void)_createFavoritesQuery:(id)a0;
- (void)_createHistoryPlaceDisplaysQuery:(id)a0;
- (void)_createHistoryRoutesQuery:(id)a0;
- (void)_createPinnedPlacesQuery:(id)a0;
- (void)_startQueryTimer;
- (void)_handleQueryTimerExpiry;
- (void)_queryContentsDidLoad:(id)a0 contentsVersion:(unsigned long long)a1;
- (void)_invalidateQueryTimer;

@end
