@class RTPlatform, RTInvocationDispatcher, RTUserSessionMonitor, RTMetricManager;

@interface RTAuthorizationManager : RTNotifier {
    RTMetricManager *_metricManager;
}

@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (nonatomic, getter=isSupported) BOOL supported;
@property (nonatomic, getter=isEnabled) BOOL enabled;
@property (nonatomic, getter=isReady) BOOL ready;
@property (retain, nonatomic) RTPlatform *platform;
@property (retain) RTUserSessionMonitor *userSessionMonitor;

+ (id)allocWithZone:(struct _NSZone { } *)a0;
+ (BOOL)supportsNotificationName:(id)a0;

- (void)setup;
- (id)init;
- (void).cxx_destruct;
- (void)dealloc;
- (BOOL)isLocationServicesEnabled;
- (void)fetchRoutineEnabledWithHandler:(id /* block */)a0;
- (void)_setup;
- (void)shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (id)initWithMetricManager:(id)a0 platform:(id)a1 userSessionMonitor:(id)a2;
- (void)_shutdown;
- (BOOL)isCoreRoutineLocationClientEnabled;
- (void)fetchBBPluginSupportedWithHandler:(id /* block */)a0;
- (void)fetchRoutineSupportedWithHandler:(id /* block */)a0;
- (BOOL)shouldPersistLocations;
- (void)setRoutineEnabled:(BOOL)a0 withHandler:(id /* block */)a1;
- (void)updateRoutineEnabled:(BOOL)a0;
- (void)handleAppResetChangeNotification;
- (void)fetchMagicalMomentsLocationUsageEnabled:(id /* block */)a0;
- (void)_fetchMagicalMomentsLocationUsageEnabled:(id /* block */)a0;
- (void)_logRoutineEnabled:(BOOL)a0;
- (void)onUserSessionChangeNotification:(id)a0;

@end
