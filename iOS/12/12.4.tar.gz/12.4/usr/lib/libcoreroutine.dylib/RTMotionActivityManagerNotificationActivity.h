@class RTMotionActivity;

@interface RTMotionActivityManagerNotificationActivity : RTNotification

@property (readonly, nonatomic) RTMotionActivity *activity;

- (id)initWithActivity:(id)a0;
- (void).cxx_destruct;

@end
