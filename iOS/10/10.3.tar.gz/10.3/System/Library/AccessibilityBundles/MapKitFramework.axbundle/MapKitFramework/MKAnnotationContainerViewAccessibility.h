@interface MKAnnotationContainerViewAccessibility : __MKAnnotationContainerViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)isAccessibilityElement;
- (BOOL)accessibilityPerformEscape;
- (void)deselectAnnotationView:(id)a0 animated:(BOOL)a1;
- (void)selectAnnotationView:(id)a0 animated:(BOOL)a1 avoid:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a2;
- (BOOL)accessibilityIsShowingAnnotationCallout;
- (id)_accessibilityAnnotationCalloutView;
- (id)_accessibilityAnnotationViews;
- (id)_accessibilityFilterVisibleElements:(id)a0;
- (void)_accessibilityZoom:(BOOL)a0 point:(struct CGPoint { double x0; double x1; })a1;
- (id)_accessibilityHitTest:(struct CGPoint { double x0; double x1; })a0 withEvent:(id)a1;
- (id)accessibilityContainerElements;
- (void)accessibilityZoomInAtPoint:(struct CGPoint { double x0; double x1; })a0;
- (void)accessibilityZoomOutAtPoint:(struct CGPoint { double x0; double x1; })a0;

@end
