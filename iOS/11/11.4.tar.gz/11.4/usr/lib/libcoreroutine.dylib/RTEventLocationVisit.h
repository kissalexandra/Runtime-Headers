@class RTLocationOfInterest;

@interface RTEventLocationVisit : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly, nonatomic) RTLocationOfInterest *locationOfInterest;

- (void).cxx_destruct;
- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (id)description;
- (id)initWithLocationOfInterest:(id)a0 source:(long long)a1;

@end
