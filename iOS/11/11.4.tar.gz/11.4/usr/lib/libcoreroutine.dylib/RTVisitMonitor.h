@class RTHintManager, RTLocationAwarenessManager, RTLearnedLocationManager, RTVisitMonitorState, NSObject, RTLocationManager, RTMetricManager;
@protocol OS_dispatch_queue, RTVisitMonitorDelegate;

@interface RTVisitMonitor : NSObject

@property (retain, nonatomic) RTLocationManager *locationManager;
@property (retain, nonatomic) RTLearnedLocationManager *learnedLocationManager;
@property (retain, nonatomic) RTHintManager *hintManager;
@property (retain, nonatomic) RTMetricManager *metricManager;
@property (retain, nonatomic) RTLocationAwarenessManager *locationAwarenessManager;
@property (retain, nonatomic) RTVisitMonitorState *state;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (nonatomic) BOOL monitoringVisitIncidents;
@property (nonatomic) BOOL monitoringLeechedVisitIncidents;
@property (nonatomic) BOOL monitoringLowConfidenceVisitIncidents;
@property (nonatomic) unsigned long long engineDependentCount;
@property (weak, nonatomic) id<RTVisitMonitorDelegate> delegate;

+ (double)evalMaxUncFromMotionDevMotionInducedDev:(double)a0 andMeasInducedDev:(double)a1;
+ (double)evaluateMotionInducedDeviationFromDataPtCnt:(long long)a0 sumLat_deg:(double)a1 sumLat2_deg:(double)a2 sumLon_deg:(double)a3 sumLon2_deg:(double)a4;
+ (double)LocationHeartbeatWhileAwake;
+ (double)convertLongitudeInto180Format:(double)a0;
+ (double)MinStaticIntervalForSLVArrival;
+ (double)MinStaticIntervalForSLVArrivalWithHint;
+ (double)convertLongitudeAtDateLineFromSum:(double)a0 fromLongitude:(double)a1;
+ (double)evaluateClustThresFromClustThresSlv:(double)a0 motionInducedDev:(double)a1 adaptionBasis:(double)a2 adaptionSampleCnt:(long long)a3 adaptionRate:(double)a4;

- (id)init;
- (void).cxx_destruct;
- (void)shutdown;
- (id)initWithQueue:(id)a0 state:(id)a1 locationManager:(id)a2 learnedLocationManager:(id)a3 hintManager:(id)a4 metricManager:(id)a5 locationAwarenessManager:(id)a6;
- (void)resetForCurrentSampleAsHypothesis:(id)a0;
- (id)resetWithTempBufferAsHypothesis;
- (void)_fetchVisitIncidentsFromLocations:(id)a0 handler:(id /* block */)a1;
- (void)fetchVisitIncidentsFromLocations:(id)a0 handler:(id /* block */)a1;
- (id)visitsFromLocation:(id)a0;
- (id)recursiveVisitsFromLocation:(id)a0;
- (void)fetchNumberOfSamplesForAdaptationWithHandler:(id /* block */)a0;
- (void)startMonitoringVisitIncidents;
- (void)stopMonitoringVisitIncidents;
- (void)startMonitoringLeechedVisitIncidents;
- (void)stopMonitoringLeechedVisitIncidents;
- (void)startMonitoringLowConfidenceVisitIncidents;
- (void)stopMonitoringLowConfidenceVisitIncidents;
- (void)startEngine;
- (void)stopEngine;
- (void)onLeechedLocationsNotification:(id)a0;
- (void)processLeechedLocations:(id)a0;
- (void)considerLowConfidenceVisitIncidentEntryAtLocation:(id)a0;
- (void)considerLowConfidenceVisitIncidentExitAtLocation:(id)a0;
- (double)horizontalUncertaintyFromSampleSize:(long long)a0 sumLat_deg:(double)a1 sumLat2_deg:(double)a2 sumLon_deg:(double)a3 sumLon2_deg:(double)a4;
- (void)fetchVisitMonitorStatusWithHandler:(id /* block */)a0;
- (void)fetchLowConfidenceVisitMonitorStatusWithHandler:(id /* block */)a0;
- (void)fetchLastVisitIncidentWithHandler:(id /* block */)a0;
- (void)fetchLastLowConfidenceVisitIncidentWithHandler:(id /* block */)a0;
- (void)fetchVisitMonitorState:(id /* block */)a0;
- (void)handleVisitIncident:(id)a0;
- (void)handleLeechedVisitIncident:(id)a0;
- (void)handleVisitMonitorStateChange;
- (void)handleLowConfidenceVisitIncident:(id)a0;
- (void)logHintSourceUsageWithLocation:(id)a0;

@end
