@interface RTEventStark : RTEvent <NSSecureCoding>

@property (class, readonly) BOOL supportsSecureCoding;

@property (readonly, nonatomic) long long starkState;

+ (id)stringFromStarkState:(long long)a0;

- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (id)description;
- (id)initWithDeviceStarkState:(long long)a0 source:(long long)a1 startDate:(id)a2 endDate:(id)a3;

@end
