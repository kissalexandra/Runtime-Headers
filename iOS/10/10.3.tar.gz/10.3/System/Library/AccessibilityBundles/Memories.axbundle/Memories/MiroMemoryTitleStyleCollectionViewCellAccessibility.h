@interface MiroMemoryTitleStyleCollectionViewCellAccessibility : __MiroMemoryTitleStyleCollectionViewCellAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (BOOL)isAccessibilityElement;
- (void)_setAXMoodName:(id)a0;
- (id)_axMoodName;
- (void)_axSetTitleMoodName:(id)a0;

@end
