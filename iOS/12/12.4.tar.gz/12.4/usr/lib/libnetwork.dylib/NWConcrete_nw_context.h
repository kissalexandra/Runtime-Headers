@class NSString, NSObject;
@protocol OS_dispatch_workloop;

@interface NWConcrete_nw_context : NSObject <OS_nw_context> {
    NSObject<OS_dispatch_workloop> *workloop;
    char *identifier;
    struct nw_hash_table { } *address_endpoints;
    struct nw_hash_table { } *host_endpoints;
    struct nw_hash_table { } *other_endpoints;
    void *purge_timer;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } channel_lock;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } path_lock;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } globals_lock;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } activate_lock;
    struct nw_hash_table { } *globals;
    void *channel_globals;
    void *path_globals;
    struct nw_mem_buffer_manager { } *buffer_manager_128;
    struct nw_mem_buffer_manager { } *buffer_manager_64;
    struct nw_mem_buffer_manager { } *buffer_manager_16;
    struct nw_mem_buffer_manager { } *buffer_manager_8;
    struct nw_mem_buffer_manager { } *buffer_manager_2;
    int scheduling_mode;
    int privacy_level;
    unsigned char isolate_protocol_stack : 1;
    unsigned char isolate_protocol_cache : 1;
    unsigned char is_implicit : 1;
    unsigned char activated : 1;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

@end
