@interface AXFaceAccessibilityElement_CAMERA_UI : UIAccessibilityElement

@property (nonatomic) struct CGRect { struct CGPoint { double x; double y; } origin; struct CGSize { double width; double height; } size; } faceBounds;

@end
