@class NSString, NSObject;
@protocol OS_nw_array, OS_nw_error;

@interface NWConcrete_nw_content_context : NSObject <OS_nw_content_context> {
    char identifier[32];
    NWConcrete_nw_content_context *antecedent;
    unsigned long long expiration_milliseconds;
    unsigned long long enqueue_time;
    double relative_priority;
    NSObject<OS_nw_array> *protocol_metadatas;
    NSObject<OS_nw_error> *error;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } lock;
    unsigned char is_final : 1;
    unsigned char expiration_checked : 1;
    unsigned char completed_send : 1;
    unsigned char __pad_bits : 5;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

@end
