@interface CAMFlashButtonAccessibility : __CAMFlashButtonAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;
- (BOOL)accessibilityActivate;
- (BOOL)_accessibilitySupportsActivateAction;

@end
