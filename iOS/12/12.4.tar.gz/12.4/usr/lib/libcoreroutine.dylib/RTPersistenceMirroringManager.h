@class RTPersistenceMirroringPolicy, NSString, RTPersistenceManager, RTPowerAssertion, RTKeepAliveTransaction, RTXPCActivityManager, RTDefaultsManager, NSObject, RTInvocationDispatcher, RTMemoryTransaction;
@protocol OS_dispatch_queue;

@interface RTPersistenceMirroringManager : NSObject <RTPersistenceMirroringDelegate> {
    NSObject<OS_dispatch_queue> *_queue;
    RTPersistenceManager *_persistenceManager;
    RTDefaultsManager *_defaultsManager;
    RTPowerAssertion *_powerAssertion;
    RTMemoryTransaction *_memoryTransaction;
    RTKeepAliveTransaction *_keepAliveTransaction;
    RTInvocationDispatcher *_dispatcher;
    RTPersistenceMirroringPolicy *_mirroringPolicy;
    RTXPCActivityManager *_xpcActivityManager;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)shutdown;
- (id)initWithPersistenceManager:(id)a0 defaultsManager:(id)a1 xpcActivityManager:(id)a2;
- (void)persistenceAvailabilityDidChange:(id)a0;
- (void)_performMirroringRequestWithType:(long long)a0 affectedStore:(id)a1 qualityOfService:(long long)a2 managedObjectContext:(id)a3 handler:(id /* block */)a4;
- (void)_persistenceAvailabilityDidChange:(id)a0;
- (void)performMirroringRequestWithType:(long long)a0 affectedStore:(id)a1 qualityOfService:(long long)a2 handler:(id /* block */)a3;
- (void)performMirroringRequestWithType:(long long)a0 affectedStore:(id)a1 qualityOfService:(long long)a2 managedObjectContext:(id)a3 handler:(id /* block */)a4;
- (id)init;
- (void)dealloc;
- (void).cxx_destruct;

@end
