@protocol AXHearingAidStatusBarDelegate;

@interface AXHearingAidStatusBar : UIStatusBar

@property (nonatomic) id<AXHearingAidStatusBarDelegate> delegate;

- (void)setSize:(struct CGSize { double x0; double x1; })a0;
- (void)statusBarServer:(id)a0 didReceiveStatusBarData:(const struct { BOOL x0[34]; char x1[64]; int x2; int x3; char x4[100]; char x5[100]; char x6[2][100]; char x7[1024]; unsigned int x8; int x9; int x10; unsigned int x11; int x12; unsigned int x13; char x14[150]; int x15; int x16; unsigned char x17 : 1; unsigned char x18 : 1; unsigned char x19 : 1; char x20[256]; unsigned char x21 : 1; unsigned char x22 : 1; unsigned char x23 : 1; unsigned char x24 : 1; unsigned char x25 : 1; unsigned int x26; unsigned char x27 : 1; unsigned char x28 : 1; unsigned char x29 : 1; char x30[256]; char x31[256]; char x32[100]; char x33[100]; unsigned char x34 : 1; unsigned char x35 : 1; } *)a1 withActions:(int)a2;
- (void)statusBarServer:(id)a0 didReceiveStyleOverrides:(int)a1;
- (void)statusBarServer:(id)a0 didReceiveGlowAnimationState:(BOOL)a1 forStyle:(long long)a2;
- (void)statusBarServer:(id)a0 didReceiveDoubleHeightStatusString:(id)a1 forStyle:(long long)a2;
- (id)initWithFrame:(struct CGRect { struct CGPoint { double x0; double x1; } x0; struct CGSize { double x0; double x1; } x1; })a0 overrides:(int)a1 andDelegate:(id)a2;

@end
