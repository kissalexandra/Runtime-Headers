@class UILabel, AXDispatchTimer, NSDate;

@interface AXHearingBatteryStatusCell : AXHearingBlurCell {
    UILabel *_leftLabel;
    UILabel *_rightLabel;
    AXDispatchTimer *_updateTimer;
}

@property (retain, nonatomic) NSDate *leftBatteryDate;
@property (retain, nonatomic) NSDate *rightBatteryDate;

+ (id)batteryStatusCellWithLeftDate:(id)a0 andRightDate:(id)a1;

- (void)layoutSubviews;
- (void)dealloc;
- (id)initWithLeftDate:(id)a0 andRightDate:(id)a1;
- (void)updateBatteryLabels;
- (id)durationStringFromTimeInterval:(double)a0;

@end
