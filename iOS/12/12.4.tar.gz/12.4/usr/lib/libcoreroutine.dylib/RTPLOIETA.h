@class NSString, RTPredictedLocationOfInterest, RTMapItem, RTLOIDisplayInfo;

@interface RTPLOIETA : NSObject {
    RTMapItem *_origin;
    unsigned int _responseETASeconds;
    unsigned int _baselineETASeconds;
    NSString *_responseRouteDescription;
    RTLOIDisplayInfo *_displayInfo;
}

@property (readonly, nonatomic) RTPredictedLocationOfInterest *ploi;

- (unsigned long long)trafficDensity;
- (id)mapsURL;
- (id)displayInfo;
- (id)localizedMessage;
- (BOOL)hasEquivalentDisplayTo:(id)a0;
- (BOOL)etaExceedsMinimumETA:(unsigned int)a0;
- (id)initWithPLOI:(id)a0 origin:(id)a1 responseETASeconds:(unsigned int)a2 baselineETASeconds:(unsigned int)a3 responseRouteDescription:(id)a4;
- (id)_displayInfoForDate:(id)a0;
- (void).cxx_destruct;
- (id)description;
- (id)localizedTitle;
- (id)localizedDescription;

@end
