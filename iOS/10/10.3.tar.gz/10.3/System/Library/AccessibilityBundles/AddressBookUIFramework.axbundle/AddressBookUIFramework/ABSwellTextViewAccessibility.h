@interface ABSwellTextViewAccessibility : __ABSwellTextViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityValue;

@end
