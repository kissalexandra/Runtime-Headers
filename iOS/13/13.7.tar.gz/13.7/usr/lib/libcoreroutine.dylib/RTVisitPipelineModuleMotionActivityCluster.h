@class NSString, RTMotionActivityManager, NSDate;

@interface RTVisitPipelineModuleMotionActivityCluster : NSObject <RTVisitPipelineModule> {
    RTMotionActivityManager *_motionActivityManager;
}

@property (retain, nonatomic) NSDate *lastProcessedDate;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)init;
- (void).cxx_destruct;
- (id)process:(id)a0;
- (id)initWithMotionActivityManager:(id)a0;
- (id)activitiesWithinDateInterval:(id)a0 error:(id *)a1;
- (id)automotiveDateIntervalsWithinDateInterval:(id)a0 activities:(id)a1;
- (id)motionActivityVisitClustersFromVisitCluster:(id)a0 automotiveDateIntervals:(id)a1;
- (id)motionActivityVisitClustersFromVisitCluster:(id)a0 error:(id *)a1;

@end
