@class RTInvocationDispatcher, NSString, NSPredicate, RTPredictedApplicationManager, NSObject;
@protocol OS_dispatch_queue, RTDaemonClientRegistrarApplicationPredictionProtocol;

@interface RTDaemonClientRegistrarApplicationPrediction : RTDaemonClientRegistrar <NSSecureCoding, RTDaemonClientRegistrarProtocol> {
    BOOL _registered;
}

@property (class, readonly) BOOL supportsSecureCoding;

@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (retain, nonatomic) RTPredictedApplicationManager *predictedApplicationManager;
@property (retain, nonatomic) NSPredicate *applicationPredicate;
@property (retain, nonatomic) NSObject<OS_dispatch_queue> *queue;
@property (weak, nonatomic) id<RTDaemonClientRegistrarApplicationPredictionProtocol> delegate;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (BOOL)invocationsPending;
- (long long)countOfPendingInvocations;
- (id)initWithPredictedApplicationManager:(id)a0 queue:(id)a1;
- (void)startMonitoringForPredictedApplicationsUsingPredicate:(id)a0;
- (void)stopMonitoringForPredictedApplications;
- (void)addPendingApplicationPredictionBlock:(id /* block */)a0 failBlock:(id /* block */)a1 description:(id)a2;
- (void)onPredictedApplicationNotification:(id)a0;
- (BOOL)evaluatePredicateKeyPath;
- (void)encodeWithCoder:(id)a0;
- (id)initWithCoder:(id)a0;
- (void).cxx_destruct;
- (BOOL)registered;

@end
