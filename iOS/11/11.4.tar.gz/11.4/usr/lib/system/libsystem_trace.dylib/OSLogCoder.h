@interface OSLogCoder : NSObject <OSLogCoder> {
    struct { unsigned char x0 : 4; unsigned char x1 : 4; unsigned char x2; unsigned char x3[0]; } *_fmt_cmd;
    struct os_trace_blob_s { union { char *x0; void *x1; char *x2; char *x3; } x0; unsigned int x1; unsigned int x2; unsigned int x3; unsigned short x4; BOOL x5; } *_ob;
    struct os_trace_blob_s { union { char *x0; void *x1; char *x2; char *x3; } x0; unsigned int x1; unsigned int x2; unsigned int x3; unsigned short x4; BOOL x5; } *_ob_pub;
    struct os_trace_blob_s { union { char *x0; void *x1; char *x2; char *x3; } x0; unsigned int x1; unsigned int x2; unsigned int x3; unsigned short x4; BOOL x5; } *_ob_priv;
    unsigned long long _maxsz;
    unsigned short _written;
    unsigned short _offset;
    BOOL _truncated;
}

- (void)appendBytes:(const void *)a0 length:(unsigned long long)a1;
- (void)setTruncated;
- (void)setPublic;
- (void)_setFlags:(unsigned char)a0;

@end
