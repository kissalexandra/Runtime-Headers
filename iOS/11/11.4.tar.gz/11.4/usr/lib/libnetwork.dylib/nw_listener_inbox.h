@class NSObject;
@protocol OS_nw_interface, nw_listener_inbox_delegate, OS_nw_endpoint;

@interface nw_listener_inbox : NSObject {
    NSObject<nw_listener_inbox_delegate> *_delegate;
}

@property (readonly, nonatomic) NSObject<OS_nw_endpoint> *local_endpoint;
@property (readonly, nonatomic) NSObject<OS_nw_interface> *interface;

- (void).cxx_destruct;
- (void)cancel;
- (id)initWithDelegate:(id)a0;

@end
