@interface __CMKButtonLabelAccessibility_super : UIAccessibilitySafeCategory

@end
