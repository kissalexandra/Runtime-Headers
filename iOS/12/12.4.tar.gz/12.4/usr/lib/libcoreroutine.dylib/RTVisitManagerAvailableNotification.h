@interface RTVisitManagerAvailableNotification : RTNotification

@end
