@class NSMutableDictionary;

@interface RTMicroLocationCache : NSObject

@property (retain, nonatomic) NSMutableDictionary *cache;

- (id)init;
- (void).cxx_destruct;
- (void)clear;
- (id)microLocationForResult:(id)a0;
- (id)addMicroLocationForIdentifier:(id)a0;

@end
