@interface RTAuthorizationManagerNotificationConsoleUserDidChange : RTNotification

@property (readonly, nonatomic, getter=activeUser) BOOL activeUser;

- (id)initWithactiveUser:(BOOL)a0;
- (id)init;

@end
