@interface RTPredictionExpertApplicationLocation : RTPredictionExpertApplication

@property (nonatomic) double maxLocationEventAge;

- (id)initWithQueue:(id)a0 category:(long long)a1 dataSource:(id)a2 defaultsManager:(id)a3 mediaRemote:(id)a4 featureAddons:(id)a5;
- (id)supportedEventClasses;
- (void)_processEventsWithAppLaunchEvents:(id)a0 handler:(id /* block */)a1;
- (id)dateIntervalForAppLaunchEvent:(id)a0;

@end
