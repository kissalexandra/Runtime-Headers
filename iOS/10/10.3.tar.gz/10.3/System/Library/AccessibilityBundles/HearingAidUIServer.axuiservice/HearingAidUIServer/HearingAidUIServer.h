@class UIViewController, NSString, UIAlertController, AXAssertion, AXHearingAidDisplayController;

@interface HearingAidUIServer : NSObject <AXUIService, AXUIContentViewControllerDelegate> {
    UIAlertController *_handoffAlertController;
    UIViewController *_emptyViewController;
}

@property (retain, nonatomic) AXAssertion *disableSystemGestureAssertion;
@property (retain, nonatomic) AXHearingAidDisplayController *displayController;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

@end
