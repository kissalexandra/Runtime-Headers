@interface OS_nw_dictionary : OS_object

- (void)_dispose;

@end
