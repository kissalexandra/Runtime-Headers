@interface LPLinkViewAccessibility : __LPLinkViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)accessibilityLabel;
- (id)accessibilityValue;
- (id)accessibilityHint;
- (unsigned long long)accessibilityTraits;
- (BOOL)isAccessibilityElement;
- (BOOL)accessibilityActivate;
- (id)accessibilityCustomActions;
- (void)_axFollowLink;
- (id)_axITunesPlayButton;
- (BOOL)_axPlayPause:(id)a0;

@end
