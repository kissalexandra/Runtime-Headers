@interface CAMEffectsGridViewAccessibility : __CAMEffectsGridViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)isAccessibilityElement;
- (id)accessibilityElements;

@end
