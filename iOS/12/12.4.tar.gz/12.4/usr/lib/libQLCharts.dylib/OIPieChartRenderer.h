@protocol OIPieSliceRenderer;

@interface OIPieChartRenderer : NSObject

@property (retain) id<OIPieSliceRenderer> sliceRenderer;
@property struct __OIChart { } *chart;

- (void)renderThreeDimensional:(BOOL)a0 pieFromSeriesArray:(struct __CFArray { } *)a1;
- (id)initWithChart:(struct __OIChart { } *)a0 sliceRenderer:(id)a1;
- (id)initWithChart:(struct __OIChart { } *)a0;
- (void)dealloc;
- (void).cxx_destruct;

@end
