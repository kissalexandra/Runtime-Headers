@interface CAMPreviewViewControllerAccessibility : __CAMPreviewViewControllerAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)didChangeToMode:(long long)a0 device:(long long)a1 animated:(BOOL)a2;
- (void)captureControllerWillResetFocusAndExposure:(id)a0;
- (void)_setUserLockedFocusAndExposure:(BOOL)a0 shouldAnimate:(BOOL)a1;

@end
