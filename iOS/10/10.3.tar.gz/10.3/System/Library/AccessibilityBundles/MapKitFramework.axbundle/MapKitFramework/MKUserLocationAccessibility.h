@interface MKUserLocationAccessibility : __MKUserLocationAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (Class)safeCategoryBaseClass;

- (void)setLocation:(id)a0;
- (id)accessibilityLocality;

@end
