@class RTInvocationDispatcher, NSString, NSSet, NSMutableSet, NSDate;

@interface RTMediaRemote : RTService

@property (retain, nonatomic) NSDate *dateOfLastNowPlayingTransition;
@property (nonatomic) long long lastNowPlayingState;
@property (copy, nonatomic) NSString *lastNowPlayingBundleId;
@property (copy, nonatomic) NSSet *blacklistedBundleIds;
@property (copy, nonatomic) NSSet *whitelistedBundleIds;
@property (retain, nonatomic) NSMutableSet *bundleIdsSupportingPriming;
@property (retain, nonatomic) RTInvocationDispatcher *dispatcher;
@property (nonatomic) BOOL ready;

+ (id)defaultApplicationWhitelist;

- (void)_setup;
- (void)handleNowPlayingApplicationIsPlayingDidChange;
- (void)_shutdown;
- (void)internalAddObserver:(id)a0 name:(id)a1;
- (void)internalRemoveObserver:(id)a0 name:(id)a1;
- (void)primingSupportedForBundleIdentifier:(id)a0 handler:(id /* block */)a1;
- (void)updateBundleIdsSupportingPrimingCapability:(id /* block */)a0;
- (void)_registerForMediaRemoteNotifications;
- (void)fetchNowPlayingApplicationPlaybackState:(id /* block */)a0;
- (void)_updateBundleIdsSupportingPrimingCapability:(id /* block */)a0;
- (void)fetchNowPlayingApplicationBundleIdentifier:(id /* block */)a0;
- (void)_unregisterForMediaRemoteNotifications;
- (void)_handleNowPlayingApplicationIsPlayingDidChange;
- (void)__handleNowPlayingApplication:(id)a0 didChangeState:(unsigned int)a1;
- (void)_primingSupportedForBundleIdentifier:(id)a0 handler:(id /* block */)a1;
- (void)_bundleIdentifiersKnownToSupportPriming:(id /* block */)a0;
- (void)bundleIdentifiersKnownToSupportPriming:(id /* block */)a0;
- (id)init;
- (void).cxx_destruct;

@end
