@interface MFComposeTextContentViewAccessibility : __MFComposeTextContentViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)_accessibilitySetValue:(id)a0;
- (id)accessibilityLabel;
- (id)accessibilityValue;
- (struct CGPoint { double x0; double x1; })accessibilityActivationPoint;
- (BOOL)_accessibilityTextOperationAction:(id)a0;
- (BOOL)_accessibilityHasTextOperations;
- (id)_axAttachmentNames;
- (id)_accessibilityCustomTextOperations;
- (id)_accessibilityHitTest:(struct CGPoint { double x0; double x1; })a0 withEvent:(id)a1;
- (id)_accessibilityTextOperations;
- (id)_accessibilityRoleDescription;

@end
