@interface MPUNowPlayingIndicatorViewAccessibility : __MPUNowPlayingIndicatorViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (void)setPlaybackState:(long long)a0;

@end
