@class NSArray, NSNumberFormatter;

@interface AXLiveListenMeterCell : AXHearingBlurCell {
    NSNumberFormatter *_numberFormatter;
    BOOL _isListening;
}

@property (retain, nonatomic) NSArray *dotImageViews;

- (id)init;
- (void)layoutSubviews;
- (void)dealloc;
- (void)setListening:(BOOL)a0;
- (void)audioLevelDidChange:(float)a0;
- (void)toggleLiveListen;

@end
