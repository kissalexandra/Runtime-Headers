@interface RTVisitStore : RTStore

- (void)_fetchVisitsWithOptions:(id)a0 handler:(id /* block */)a1;
- (void)_storeVisit:(id)a0 handler:(id /* block */)a1;
- (void)_purgeVisitsPredating:(id)a0 handler:(id /* block */)a1;
- (void)fetchVisitsWithOptions:(id)a0 handler:(id /* block */)a1;
- (void)storeVisit:(id)a0 handler:(id /* block */)a1;
- (void)purgeVisitsPredating:(id)a0 handler:(id /* block */)a1;

@end
