@class RTVisitMonitorState;

@interface RTVisitMonitorStateMO : NSManagedObject

@property (retain, nonatomic) RTVisitMonitorState *visitMonitorState;

+ (id)managedObjectWithVisitMonitorState:(id)a0 inManagedObjectContext:(id)a1;

@end
