@interface MPUCompletionFooterViewAccessibility : __MPUCompletionFooterViewAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (id)_accessibilityRetrieveIvarText;

@end
