@class NSString, NSObject;
@protocol OS_nw_object, OS_nw_path, NWConcrete_nw_endpoint_mode_handler, OS_dispatch_queue, OS_nw_parameters, OS_nw_endpoint, OS_nw_path_evaluator, OS_xpc_object;

@interface NWConcrete_nw_endpoint_handler : NSObject <OS_nw_endpoint_handler> {
    void /* function */ *report_callback;
    NSObject<OS_nw_object> *callback_context;
    NSObject<OS_nw_endpoint> *endpoint;
    NSObject<OS_nw_parameters> *parameters;
    NSObject<OS_nw_path_evaluator> *path_evaluator;
    NSObject<OS_nw_path> *current_path;
    NWConcrete_nw_endpoint_handler *parent_handler;
    NSObject<OS_xpc_object> *inactive_agent_uuids;
    NSObject<OS_xpc_object> *inactive_agent_dictionaries;
    NSObject<OS_xpc_object> *triggered_agent_uuids;
    struct os_unfair_lock_s { unsigned int _os_unfair_lock_opaque; } lock;
    int mode;
    int state;
    NSObject<OS_dispatch_queue> *tls_client_queue;
    id /* block */ tls_prepare_block;
    id /* block */ tls_message_block;
    unsigned short id_chain[16];
    int last_child_id;
    char id_str[96];
    NSObject<NWConcrete_nw_endpoint_mode_handler> *mode_handler;
    unsigned char dry_run : 1;
    unsigned char triggering_voluntary_agents : 1;
    unsigned char reuse_path_evaluator : 1;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (id)initWithEndpoint:(id)a0 parameters:(id)a1 reportCallback:(void /* function */ *)a2 context:(id)a3 parent:(id)a4;
- (void).cxx_destruct;
- (void)dealloc;

@end
