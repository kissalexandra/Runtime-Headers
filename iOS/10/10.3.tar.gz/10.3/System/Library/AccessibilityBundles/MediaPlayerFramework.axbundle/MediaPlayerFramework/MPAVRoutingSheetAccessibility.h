@interface MPAVRoutingSheetAccessibility : __MPAVRoutingSheetAccessibility_super

+ (id)safeCategoryTargetClassName;
+ (void)_accessibilityPerformValidations:(id)a0;
+ (Class)safeCategoryBaseClass;

- (BOOL)accessibilityPerformEscape;
- (id)initWithAVItemType:(long long)a0;
- (void)_accessibilityLoadAccessibilityInformation;

@end
