@interface RTRouteLocationPreprocessor : NSObject

+ (id)preprocessLocations:(id)a0 error:(id *)a1;
+ (long long)findProperEndFromLocations:(id)a0;
+ (id)selectBestSubSequenceFromLocations:(id)a0 error:(id *)a1;
+ (unsigned long long)idealPreviousLocationIndex:(id)a0 from:(unsigned long long)a1;
+ (double)costOfLocation:(id)a0;

@end
